一、使用说明:
        1)用当前预期切词程序更新预期(程序在预期目录下)：
          ./split_word_regression/split_word_main.py -e 1
        2)用新的切词程序更新预期(程序在dbfw/bin目录下)：
          ./split_word_regression/split_word_main.py -e 2
        3)预期结果与实际结果对比：
          ./split_word_regression/split_word_main.py
        4)程序使用方法介绍：
          ./split_word_regression/split_word_main.py -h(或-help)

二、各目录及程序介绍:
        ./split_word_regression/split_word_main.py:切词回归主程序
        ./split_word_regression/sqlfile_dir：此目录放预切词的sql语句文件
        ./split_word_regression/spfile_expect：此目录放预期结果
        ./split_word_regression/spfile_expect/histray：此目录放曾经的预期历史(最多保留10次)
        ./split_word_regression/spfile_fact/日期：此目录放实际切词结果(历史最多保留20次)
        ./split_word_regression/shell_script：此目录shell脚本程序
        ./split_word_regression/html_template：此目录放的html模板文件
        ./split_word_regression/tools：此目录回归程序用到的相关工具
        注：所有目录的名称不可以更改

三、sql文件使用说明:
        sqlfile_oracle：为oracle的预切词sql语句,其它数据库类同
        after_masker_sqlfile_oracle：为oracle的实际执行过脱敏的sql语句,其它数据库类同
        注：1)sql文件的名称不可以更改;
            2)sql文件内的sql可以往后追加，每条sql';'分隔，追加后用生成当前预期的切词程序更新预期
              如果某条sql经过实际脱敏操作，需要添加进执行过脱敏的sql文件，以';'分隔
