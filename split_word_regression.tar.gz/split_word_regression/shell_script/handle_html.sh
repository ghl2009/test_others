#!/bin/bash
###################################
## auther:liuguanghui
## date:20180920
## work:handle_html
###################################

##按特定格式处理diff_html文件
format_diff_html()
{
	sqlfile=$1
	sql_Num=$2
	after_masker_flag=$3
	diffhtml_filename=$4
	rownum=`wc -l $diffhtml_filename|awk '{print $1}'`
	Legends_rownum_top=`grep -rn '<table class="diff" summary="Legends">' $diffhtml_filename|awk -F: '{print $1}'`
	((Legends_rownum_end=$Legends_rownum_top+14))
	sed -i "$Legends_rownum_top,$Legends_rownum_end d" $diffhtml_filename

	sed -i '20 a\<table class="diff" summary="Legends">' $diffhtml_filename
	sed -i '21 a\        <tr> <th align="left" colspan="2"> 图例： </th> </tr>' $diffhtml_filename
	sed -i '22 a\        <tr> <td> <table border="" summary="Colors">' $diffhtml_filename
	sed -i '23 a\                      <tr><th> 差异颜色 </th> </tr>' $diffhtml_filename
	sed -i '24 a\                      <tr><td class="diff_add">被填加</td></tr>' $diffhtml_filename
	sed -i '25 a\                      <tr><td class="diff_chg">被更改</td> </tr>' $diffhtml_filename
	sed -i '26 a\                      <tr><td class="diff_sub">被删除</td> </tr>' $diffhtml_filename
	sed -i '27 a\                  </table></td>' $diffhtml_filename
	sed -i '28 a\             <td> <table border="" summary="Links">' $diffhtml_filename
	sed -i '29 a\                      <tr><th colspan="2"> 可点击链接 </th> </tr>' $diffhtml_filename
	sed -i '30 a\                      <tr><td>(first):第一处差异</td> </tr>' $diffhtml_filename
	sed -i '31 a\                      <tr><td>(next)&nbsp;:下一处差异</td> </tr>' $diffhtml_filename
	sed -i '32 a\                      <tr><td>(top)&nbsp;&nbsp;:回到首部</td> </tr>' $diffhtml_filename
	sed -i '33 a\                      </table></td>'  $diffhtml_filename
	sed -i '34 a\                          <td> <table>'  $diffhtml_filename

	if [[ $after_masker_flag -eq 1 ]];then
		sed -i '35 a\                          <td ><br><br>&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp<font size="5">注：此sql为('$sqlfile')文件第'$sql_Num'条sql;实际脱敏测试与否:是</font></td>'  $diffhtml_filename
	else
		sed -i '35 a\                          <td ><br><br>&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp<font size="5">注：此sql为('$sqlfile')文件第'$sql_Num'条sql;实际脱敏测试与否:否</font></td>'  $diffhtml_filename
	fi

	sed -i '36 a\                   </table></td></tr>'  $diffhtml_filename
	sed -i '37 a\                   </table>'  $diffhtml_filename

	sed -i 's/>f<\/a>/>first<\/a>/g' $diffhtml_filename
	sed -i 's/>n<\/a>/>next<\/a>/g' $diffhtml_filename
	sed -i 's/>t<\/a>/>top<\/a>/g' $diffhtml_filename

	sed -i 's/&lt;br&gt;/<br>/g' $diffhtml_filename
}

##对sqllist html文件按特定格式填充数据
function datamation_list_html()
{
	order_num=$1
	sqlfile=$2
	sql_Num=$3
	sql_row_Num=$4
	after_masker_flag=$5
	sql_statement="$6"
	sqllist_html_filename=$7
	diff_sql_url=$8
	sed -i '/<\/table>/i\  <tr align="center">' $sqllist_html_filename
	sed -i '/<\/table>/i\    <td>'$order_num'</td>' $sqllist_html_filename
	sed -i '/<\/table>/i\    <td>&nbsp'$sqlfile'&nbsp</td>' $sqllist_html_filename
	sed -i '/<\/table>/i\    <td>'$sql_Num'</td>' $sqllist_html_filename
	sed -i '/<\/table>/i\    <td>'$sql_row_Num'</td>' $sqllist_html_filename
	if [[ $after_masker_flag -eq 1 ]];then
		sed -i '/<\/table>/i\    <td>是</td>' $sqllist_html_filename
	else
		sed -i '/<\/table>/i\    <td>否</td>' $sqllist_html_filename
	fi
	sed -i "/<\/table>/i\    <td align=\"left\"><a href=\"$diff_sql_url\">$sql_statement<\/a><\/td>" $sqllist_html_filename
	sed -i '/<\/table>/i\  </tr>' $sqllist_html_filename
	sed -i 's/teshuzifu_xinghao/*/g' $sqllist_html_filename
	sed -i 's/teshuzifu_huanhang/<br \/>/g' $sqllist_html_filename
	sed -i "s/teshuzifu_banjiaodanyinhao/'/g" $sqllist_html_filename
}

##main
if [[ $# -eq 4 ]];then
	format_diff_html $1 $2 $3 $4
elif [[ $# -eq 8 ]];then
	#echo $#
	datamation_list_html $1 $2 $3 $4 $5 "$6" $7 $8
	#echo $1 ,$2 ,$3 ,$4 ,$5 ,$6 ,$7
else
	exit 1
fi
