#!/usr/bin/python
#_*_coding: UTF-8_*_
###################################
## auther:liuguanghui
## date:20180919
## work:split_word_regression
###################################
import os
import difflib
import sys
import re
import shutil
import time
import datetime
import stat
##python2.6默认没有此包
#import netifaces
import socket
import fcntl
import struct

##读文件到列表
def readlines_file(filename):
        file = open(filename,"r")
        lines = file.readlines()
        file.close
        return lines

##把列表写入文件
def write_file(filename,write_list):
        file = open(filename,'w')
        for i in write_list:
                file.write(i)
        file.close
	return filename

##得到文件的行数
def file_linesnum(filename):
	file = open(filename)
	linesnum = len(file.readlines())
        file.close
	return linesnum

##读取文件并进行分割
def readfile_splines(filename): 
    try:
        df=open(filename,"rb")
        text=df.read().splitlines()
        df.close()
        return text
    except IOError,e:
        print "ERROR: %s"%str(e)
        sys.exit()

##把html列表写入文件
def wirtefile_html(filename,html_content):
        diffmkfile = open(filename,'w')
	#设置导出的文件的编码格式
        diffmkfile.write("<meta charset='UTF-8'>")
        diffmkfile.write(html_content)
        diffmkfile.close()
	return filename

##把文件行列表中按行中的某一标识切成块，如：切词的文件按sql切成块
def sp_block(lines_list,rownum,flag):	
	block_list = []
	#print lines_list
	block_list.append(lines_list[rownum-1])
	l_list = lines_list[rownum:]
	#print l_list
	for l in l_list:
		rownum = rownum+1
		if l.find(flag)==-1:
			block_list.append(l)
		else:
			break
	return block_list,rownum

##字符串每行定长
def str_fixlong(str,long):
	if len(str) <= long:
		str = str.ljust(long, " ")
	else:
		str = re.sub(r"(.{%d})"%long,"\\1<br>",str)		
	return str

##得到本机ip
def get_ip_address(ifname):
    s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    return socket.inet_ntoa(fcntl.ioctl(
        s.fileno(),
        0x8915,  # SIOCGIFADDR
        struct.pack('256s', ifname[:15])
    )[20:24])

##比较一个列表是否为另一列表子集（且列表顺序一样）
##其中会存在格式化列表头和列表尾的
##返回结果为：A在B中是否顺序出现，及在B中所在的起始行号
def is_subset(A,B):
        for i in range(0,len(B)-len(A)+1):
                B_tmp1 = B[i]
                B_tmp2 = B[i+len(A)-1]
		##查看列表字符串内有没有分号
		if B[i].find(";") != -1:
			while len(B[i][B[i].index(";")+1:].strip()) != 0:
				##去除首空格
				B[i] = B[i].lstrip()
				fh_index = B[i].index(";")
				if len(A) != 1:
					B[i] = B[i][fh_index+1:]
					##找不到分号后退出循环
					if B[i].find(";") == -1:
						break
					else:
						continue
				B_tmp3 = B[i][fh_index+1:]
				B[i] = B[i][:fh_index+1]
				if cmp(A,B[i:i+len(A)]) == 0:
					return 1,i+1
				else:
					B[i] = B_tmp3
					if B_tmp3.find(";") == -1:
						break

                B[i] = B[i].lstrip()
		if B[i+len(A)-1].find(";") != -1:
			fh_index = B[i+len(A)-1].index(";")
			B[i+len(A)-1] = B[i+len(A)-1][:fh_index+1]
		##比较两个列表是否相同
                #if A==B[i:i+len(A)]:
                if cmp(A,B[i:i+len(A)]) == 0:
                        return 1,i+1
		##对列表内容有改变进行恢复
                B[i] = B_tmp1
                B[i+len(A)-1] = B_tmp2

        return 0,0



##get homepath
def GetCwdPath():
        return os.path.split(os.path.realpath(sys.argv[0]))[0]

##目录下保留一定数量的文件或文件夹
def rm_file(rm_path,filenum):
        files_list = os.listdir(rm_path)
        list = []
        dict = {}
        for i in files_list:
                all_path = os.path.join(rm_path, i)
                ctime = os.path.getctime(all_path)
                dict[all_path] = ctime
        ##sorted方法可按照字典的key和value进行排序，这里的key是一个lambda函数，表示按照选取元组dict.items()中的第二个元素进行排序
        AllPathCtimeList = sorted(dict.items(), key=lambda item: item[1])
        if len(AllPathCtimeList) <= filenum:
                pass
        else:
                for i in range(len(AllPathCtimeList) - filenum):
                        ##取AllPathCtimeList中的第i的元素，然后取第i个元素中的第0个元素
                        if os.path.isdir(AllPathCtimeList[i][0]):
                                shutil.rmtree(AllPathCtimeList[i][0])
                        else:
                                os.remove(AllPathCtimeList[i][0])
##帮助
def help():
	py_main = os.path.realpath(sys.argv[0]) 
	if len(sys.argv) > 1:
		param1 = sys.argv[1]
		if param1 == "-h" or param1 == "-help":
			print "\n一、使用说明:"
			print "\t1)用当前预期切词程序更新预期(程序在预期目录下)：\n\t  %s -e 1"%py_main
			print "\t2)用新的切词程序更新预期(程序在dbfw/bin目录下)：\n\t  %s -e 2"%py_main
			print "\t3)预期结果与实际结果对比：\n\t  %s"%py_main
			print "\t4)程序使用方法介绍：\n\t  %s -h(或-help)"%py_main
			print "\n二、各目录及程序介绍:"
			print "\t%s:切词回归主程序"%py_main
			print "\t%s/sqlfile_dir：此目录放预切词的sql语句文件"%SPWordHome
			print "\t%s/spfile_expect：此目录放预期结果"%SPWordHome
			print "\t%s/spfile_expect/histray：此目录放曾经的预期历史(最多保留10次)"%SPWordHome
			print "\t%s/spfile_fact/日期：此目录放实际切词结果(历史最多保留20次)"%SPWordHome
			print "\t%s/shell_script：此目录shell脚本程序"%SPWordHome
			print "\t%s/html_template：此目录放的html模板文件"%SPWordHome
			print "\t%s/tools：此目录回归程序用到的相关工具"%SPWordHome
			print "\t注：所有目录的名称不可以更改"
			print "\n三、sql文件使用说明:"
			print "\tsqlfile_oracle：为oracle的预切词sql语句,其它数据库类同"
			print "\tafter_masker_sqlfile_oracle：为oracle的实际执行过脱敏的sql语句,其它数据库类同"
			print "\t注：1)sql文件的名称不可以更改;"
			print "\t    2)sql文件内的sql可以往后追加，每条sql';'分隔，追加后用生成当前预期的切词程序更新预期"
			print "\t      如果某条sql经过实际脱敏操作，需要添加进执行过脱敏的sql文件，以';'分隔\n"
			exit()
	else:
		return

##制作预期
def make_expect():
	if len(sys.argv) > 2:
		param1 = sys.argv[1]
		param2 = sys.argv[2]
		filelist = os.listdir("%s/spfile_expect"%SPWordHome)
		filelist.remove("histry")
		##用当前已存在的预期程序更新预期
		if param1 == "-e" and param2 == "1":
                        if os.path.exists("%s/spfile_expect/test_split_word"%SPWordHome):
                                t = os.path.getctime("%s/spfile_expect/test_split_word"%SPWordHome)
                                t = datetime.datetime.fromtimestamp(t)
                                t = t.strftime('%Y%m%d%H%M%S')
                                if not os.path.exists("%s/spfile_expect/histry/%s"%(SPWordHome,t)):
                                        os.makedirs("%s/spfile_expect/histry/%s"%(SPWordHome,t))
                                for filename in filelist:
                                        shutil.move("%s/spfile_expect/%s"%(SPWordHome,filename),"%s/spfile_expect/histry/%s"%(SPWordHome,t))
				shutil.copyfile("%s/spfile_expect/histry/%s/test_split_word"%(SPWordHome,t),"%s/spfile_expect/test_split_word"%(SPWordHome))
			else:
                                print "\n没有预期历史，请先制作预期"
                                print "********************************************\n"
				exit()
			for dbvalue in sorted(db_dict.keys()):
				dbname = db_dict[dbvalue]
				sqlfile = "sqlfile_%s"%(dbname)
				os.chmod("%s/spfile_expect/test_split_word"%(SPWordHome),stat.S_IRWXU|stat.S_IRWXG|stat.S_IRWXO)
				os.system("%s/spfile_expect/test_split_word -d %d -i %s/sqlfile_dir/%s -o %s/spfile_expect/spfile_expect_%s >> %s/spfile_expect/test_split_word.log"
					%(SPWordHome,dbvalue,SPWordHome,sqlfile,SPWordHome,dbname,SPWordHome))
			shutil.copytree("%s/sqlfile_dir"%(SPWordHome),"%s/spfile_expect/sqlfile"%(SPWordHome))	
			rm_file("%s/spfile_expect/histry"%SPWordHome,10)
			print "\n(用旧版本切词程序)更新预期完成"
			print "******************************\n"
			exit()
		##用最新的切词程序更新预期
		elif param1 == "-e" and param2 == "2":
			if not os.path.exists("%s/test_split_word"%DBFWHome_bin):
				print "\n此版本的产品不支持切词,请检查产品类型及版本"
                                print "********************************************\n"
				exit()
			if os.path.exists("%s/spfile_expect/test_split_word"%SPWordHome):
				t = os.path.getctime("%s/spfile_expect/test_split_word"%SPWordHome)
				t = datetime.datetime.fromtimestamp(t)
				t = t.strftime('%Y%m%d%H%M%S') 
				if not os.path.exists("%s/spfile_expect/histry/%s"%(SPWordHome,t)):
					os.makedirs("%s/spfile_expect/histry/%s"%(SPWordHome,t))
				for filename in filelist:
					shutil.move("%s/spfile_expect/%s"%(SPWordHome,filename),"%s/spfile_expect/histry/%s"%(SPWordHome,t))
			else:
				for filename in filelist:
					os.remove("%s/spfile_expect/%s"%(SPWordHome,filename))
			shutil.copyfile("%s/test_split_word"%(DBFWHome_bin),"%s/spfile_expect/test_split_word"%(SPWordHome))
			os.chmod("%s/spfile_expect/test_split_word"%(SPWordHome),stat.S_IRWXU|stat.S_IRWXG|stat.S_IRWXO)
			for dbvalue in sorted(db_dict.keys()):
                                dbname = db_dict[dbvalue]
                                sqlfile = "sqlfile_%s"%(dbname)
				ver_flag = os.system("%s/test_split_word -d %d -i %s/sqlfile_dir/%s -o %s/spfile_expect/spfile_expect_%s >> %s/spfile_expect/test_split_word.log"
				     	 		%(DBFWHome_bin,dbvalue,SPWordHome,sqlfile,SPWordHome,dbname,SPWordHome))
				if ver_flag != 0:
					print "\n此版本的产品不支持切词,请检查产品类型及版本"
					print "********************************************\n"
					exit()
			shutil.copytree("%s/sqlfile_dir"%(SPWordHome),"%s/spfile_expect/sqlfile"%(SPWordHome))	
			rm_file("%s/spfile_expect/histry"%SPWordHome,10)
			print "\n(用新版本切词程序)制作预期完成"
			print "******************************\n"
			exit()


##主函数
def main(dbvalue):
	##用以记录差异sql所处的sql文件
	dbname = db_dict[dbvalue]
	sqlfile = "sqlfile_%s"%(dbname)
	##用以记录已经经过实际脱敏的sql文件名
	after_masker_sqlfile = "after_masker_%s"%sqlfile
	##本次执行切词文件名
	spfilename = "spfile_fact_%s%s"%(dbname,nowdate)
	##根据sql文件，执行切词，并生成切词文件
	#os.system("mv ./spfile_fact/* ./fact_histry")
	
	ver_flag = os.system("%s/test_split_word -d %d -i %s/sqlfile_dir/%s -o %s/spfile_fact/%s/%s >> %s/spfile_fact/%s/test_split_word.log"
				%(DBFWHome_bin,dbvalue,SPWordHome,sqlfile,SPWordHome,nowdate,spfilename,SPWordHome,nowdate))
	if ver_flag != 0:
		print "\n此版本的产品不支持切词,请检查产品类型及版本"
		print "********************************************\n"	
		exit()
	##分别读取预期和本次执行的切词文件,所有行 
	try:
		os.system("%s %s/spfile_expect/spfile_exp/ect_%s>/dev/null 2>&1" %(dos2unix,SPWordHome,dbname))	
		sp_expect_lines = readlines_file("%s/spfile_expect/spfile_expect_%s" %(SPWordHome,dbname))
	except IOError:
		print "\n##%s没有切词预期，请做完预期重试##"%(dbname) 
		print "*****************************************"	
		return	
	os.system("%s %s/spfile_fact/%s/%s>/dev/null 2>&1" %(dos2unix,SPWordHome,nowdate,spfilename))
	sp_fact_lines =  readlines_file("%s/spfile_fact/%s/%s" %(SPWordHome,nowdate,spfilename))

	##初始化行号
	numrow_e = 1
	numrow_f = 1
	##初始化
	sqlsm_e = []
	sqlsm_f = []
	##得到sql文件中的sql数量
	sqlnum = os.popen("grep -o ';' %s/sqlfile_dir/%s|wc -l" %(SPWordHome,sqlfile))
	sqlnum = sqlnum.read()
	sqlnum = "".join(sqlnum.split())
	sqlnum = int(sqlnum)
	i = 1
	for sql_Num in range(1,sqlnum+1):
		##一条sql被分词后的所有行,及下一条sql的起始行
		sqlblock_expect,numrow_e = sp_block(sp_expect_lines,numrow_e,"=====sql[")
		#print  "expect_rownum:%s" %numrow_e
		sqlblock_fact,numrow_f = sp_block(sp_fact_lines,numrow_f,"=====sql[")
		#print "fact_rownum:%s" %numrow_f
		##把"第几条sql数"：变量由数值型转为字符串
		sql_Num2str = str(sql_Num)
		##预期切词文件与实际切词文件是否相同
		ret = cmp(sqlblock_expect,sqlblock_fact)
		if ret != 0:
			##差异sql列表（预期）
			sql_statement_e = sp_block(sqlblock_expect,1,"word_index     :1")[0][1:]
			##差异sql列表（实际）
			sql_statement_f = sp_block(sqlblock_fact,1,"word_index     :1")[0][1:]
			##初始化sql行列表头，把多余字符去掉
			if len(sql_statement_e) != 0:
				sql_statement_e[0] = sql_statement_e[0][16:]
				sql_statement_e[-1] = sql_statement_e[-1][:-1] + ";"
			sql_statement_f[0] = sql_statement_f[0][16:]
			##初始化sql行列表尾，把尾换行符换为分号
			sql_statement_f[-1] = sql_statement_f[-1][:-1] + ";"
			#print sql_statement_f
			##打开已经脱敏sql文件,放入行列表变量
			after_masker_sql_lines = readlines_file("%s/sqlfile_dir/%s" %(SPWordHome,after_masker_sqlfile))
			##通过列表比对的方法查看此sql在"已经经过实际脱敏操作的sql文件中查看是否存在
			##存在标记为1,不存在标记为0
			after_masker_flag = is_subset(sql_statement_e,after_masker_sql_lines)[0]

			##打开要切词sql文件,放入行列表变量
			sql_lines = readlines_file("%s/sqlfile_dir/%s" %(SPWordHome,sqlfile))
			sql_row_Num = is_subset(sql_statement_f,sql_lines)[1]
			##第几条差异sql
			global order_num
			order_num = order_num + 1
			#print order_num
			#after_masker_flag = any([A==B[i:i+len(A)] for i in range(0,len(B)-len(A)+1)])
			if i == 1:
				print "\n%s数据库切词差异\n--------------------------\n"%(dbname)
				print "==sql_%d==:实际结果、预期结果不一致"%(sql_Num)
			else:
				print "==sql_%d==:实际结果、预期结果不一致"%(sql_Num)
			i = i + 1
			#file1 = write_file("%s/spfile_fact/%s/spfile_expect_%s"%(SPWordHome,nowdate,dbname) + "_" + after_masker_flag + "_" + sql_Num2str,sqlblock_expect)
			#file2 = write_file("%s/spfile_fact/%s/%s"%(SPWordHome,nowdate,spfilename) + "_" + after_masker_flag + "_" + sql_Num2str,sqlblock_fact)	
			file1 = write_file("%s/spfile_fact/%s/spfile_expect_%s"%(SPWordHome,nowdate,dbname) + "_" + sql_Num2str,sqlblock_expect)
			file2 = write_file("%s/spfile_fact/%s/%s"%(SPWordHome,nowdate,spfilename) + "_" + sql_Num2str,sqlblock_fact)	
			file1_lines = readfile_splines(file1)
			if len(sql_statement_e) != 0:	
				file1_lines[1] = str_fixlong(file1_lines[1],85)
			else:
				file1_lines[0] = "========预期中无此sql切词信息，请核准后（按生成当前预期的切词程序）更新预期========"
				file1_lines[0] = str_fixlong(file1_lines[0],120)
			file2_lines = readfile_splines(file2)
			file2_lines[1] = str_fixlong(file2_lines[1],85)
			#file2_lines[1] = re.sub(r"(.{80})","\\1\n",file2_lines[1])
			##比较两个文件开成差异html
			diff=difflib.HtmlDiff()
			#print time.strftime("%Y-%m-%d %H:%M:%S", time.localtime())
			diff_html = diff.make_file(file1_lines,file2_lines)
			#print time.strftime("%Y-%m-%d %H:%M:%S", time.localtime())
			diffhtmlfile = "%s/spfile_fact/%s/diff%s-%d-%s-%s.html"%(SPWordHome,nowdate,nowdate,dbvalue,after_masker_flag,sql_Num2str)
			wirtefile_html(diffhtmlfile,diff_html)
			os.system("sed -i 's/&lt;br&gt;/<br>/g' %s" %diffhtmlfile)
			os.chmod("%s/shell_script/handle_html.sh"%(SPWordHome),stat.S_IRWXU|stat.S_IRWXG|stat.S_IRWXO)
			os.system("/bin/bash %s/shell_script/handle_html.sh '%s' '%s' '%s' '%s'" %(SPWordHome,sqlfile,sql_Num2str,after_masker_flag,diffhtmlfile))
			sql_statement_f_str = "".join(sql_statement_f)
			##把语句中的特殊字符先替换成特定自符串
			##因为此变量会做为参数传入shell脚本，特殊字体对于shell参数有特定含义
			sql_statement_f_str = sql_statement_f_str.replace("*","teshuzifu_xinghao")
			sql_statement_f_str = sql_statement_f_str.replace("'","teshuzifu_banjiaodanyinhao")
			sql_statement_f_str = sql_statement_f_str.replace("\n","teshuzifu_huanhang")
			if not os.path.exists("%s/spword_regression/%s"%(tomcat_webdir,nowdate)):
				os.makedirs("%s/spword_regression/%s"%(tomcat_webdir,nowdate))
			os.system("cp %s %s/spword_regression/%s"  %(diffhtmlfile,tomcat_webdir,nowdate))
			#localhost_ip = netifaces.ifaddresses('eth0')[2][0]['addr']
			diff_sql_url = "https://%s/spword_regression/%s/diff%s-%d-%s-%s.html" %(localhost_ip,nowdate,nowdate,dbvalue,after_masker_flag,sql_Num2str)
			os.system("/bin/bash %s/shell_script/handle_html.sh '%s' '%s' '%s' '%s' '%s' '%s' '%s' '%s'"
				  %(SPWordHome,order_num,sqlfile,sql_Num2str,sql_row_Num,after_masker_flag,sql_statement_f_str,sqllist_html_filename,diff_sql_url))
			print "差异可通过web查看：\n%s" %(diff_sql_url)
			print "==========================================================================================\n"
		else:
			#print "==sql_%s==:实际结果、预期结果一致\n"%sql_Num2str
			continue

##DBFW bin目录,即:切词后台程序所处的目录
DBFWHome_bin="/home/dbfw/dbfw/bin"
##切词回归程序所处主目录
SPWordHome=GetCwdPath()
##数据库类型与名称装进字典
db_dict = {1: 'oracle', 2: 'sqlserver', 32: 'mysql', 8: 'db2', 64: 'postgres', 1024: 'informix'}
##帮助函数
help()
##制作预期函数
make_expect()
##tomcat_webapps路径
tomcat_webdir = "/usr/local/tomcat/webapps"
##得到当前时间串
nowdate = os.popen("date +%Y%m%d%H%M%S")
nowdate = nowdate.read()
nowdate = "".join(nowdate.split())
##获取本机ip
localhost_ip = get_ip_address('eth0')
##初始化差异sql列表序号
order_num = 0
if not os.path.exists("%s/spfile_fact/%s" %(SPWordHome,nowdate)):
	os.makedirs("%s/spfile_fact/%s" %(SPWordHome,nowdate))
sqllist_html_filename = "%s/spfile_fact/%s/diff-sqllist-%s.html"%(SPWordHome,nowdate,nowdate)
##用以记录产生了多少条差异sql
os.system("cp %s/html_template/sqllist_template.html %s" %(SPWordHome,sqllist_html_filename))
dos2unix = "%s/tools/dos2unix"%SPWordHome
os.chmod("%s/tools/dos2unix"%(SPWordHome),stat.S_IRWXU|stat.S_IRWXG|stat.S_IRWXO)
os.system("for sqlfile in `ls %s/sqlfile_dir|grep 'sqlfile_'`;do %s %s/sqlfile_dir/$sqlfile>/dev/null 2>&1;done"
										%(SPWordHome,dos2unix,SPWordHome))
##脱敏支持的数据库(oracle、sqlserver、mysql、db2、postgres、informix)
##预期与实际结果进行比较，差异sql生成html文件
for dbvalue in sorted(db_dict.keys()):
	main(dbvalue)

##差异sql列表生成html文件
if order_num > 0:
	os.system("cp %s %s/spword_regression/%s" %(sqllist_html_filename,tomcat_webdir,nowdate))
	print "\n##########################################################################################"
	print "所有差异sql列表可查看：\nhttps://%s/spword_regression/%s/diff-sqllist-%s.html"%(localhost_ip,nowdate,nowdate)
	print "##########################################################################################\n"
else:
	print "\n##########################################################################################"
	print "本次执行实际结果、预期结果完全一致,符合预期！"
	print "##########################################################################################\n"	

rm_file("%s/spfile_fact"%SPWordHome,20)
