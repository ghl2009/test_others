#!/bin/bash

if [ $# -ne 2 ];then
total_time=3600
else
total_time=$1
fi

begin=`date "+%s"`

while [ 1 ]
do
/home/dbfw/meter/meter_broadcast --session 10 --loop 10 --pps 200 eth3 loadrunner.pcap
curr=`date "+%s"`
((inter = $curr - $begin))
if [ $inter -ge $total_time ];
then
break
fi
sleep 1
done