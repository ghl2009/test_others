#ifndef _DBFW_COMMON_H_
#define _DBFW_COMMON_H_

#ifdef WIN32
#include <Windows.h>
#else
#include <unistd.h>
#include <stdlib.h>
#include <string.h>
#include <signal.h>
#include <stdio.h>
#include <stdint.h>
#endif
//#include <stdio.h>
#include <fcntl.h>
#include "dbfw_ipc.h"
#include "dbfw_global.h"

#ifdef WIN32
#define inline __inline
#endif

#define DOB2S 			1
#define UNDOB2S 		2

/*
 *	功能:	把一个字符串，转换为u_int的key
 *	参数：
 *			key：欲转换的字符串。
 *	返回值:	unint的值
 */
inline u_int Dbfw_hash_xor_key16(void *key)
{
	uint64_t seed=131;
	uint64_t k[2] = {0};
	uint64_t xor0 = 0;

	memcpy(k, key, sizeof(k));
	xor0 = (k[0] ^ seed) ^ k[1] ;

	return (xor0 >> 32) ^ (xor0&0xffffffff);
}

//功能说明：ipv6的数组转字符串功能，传入参数是ipv6的数组和存储ipv6字符串的数组
inline int Dwbf_common_ipv6_array_2_string(u_char *ipv6, char *ipv6_string)
{
	unsigned long long int ip1 = 0,ip2 = 0, iph = 0, ipl = 0;
	int i = 0;
	
	if(NULL == ipv6_string)
	{
		return -1;
	}
	//必须是32个字符的字符串转换成16字节的ip，所以字符串数组必须超过32个才能存下

	memcpy(&ip1, ipv6, 8);
	memcpy(&ip2, ipv6 + 8, 8);
	for(i = 0; i < 4; i++)
	{
		iph |= (ip1&(255llu<<(i*8)))<<((7-i*2)*8);
		ipl |= (ip2&(255llu<<(i*8)))<<((7-i*2)*8);
		iph |= (ip1&(255llu<<((7-i)*8)))>>((7-i*2)*8);
		ipl |= (ip2&(255llu<<((7-i)*8)))>>((7-i*2)*8);		
	}
	sprintf(ipv6_string, "%016llx%016llx", iph,ipl );
	ipv6_string[32] = '\0';
	
	return 0;
}

//功能说明：ipv6的数组转字符串功能，传入参数是ipv6的数组和存储ipv6字符串的数组带冒号
inline int Dwbf_common_ipv6_array_2_string_colon(unsigned char* ip, unsigned char* str, int type)
{
	unsigned int* ip_array = (unsigned int*)ip;
	unsigned long long int ip1 = 0,ip2 = 0, iph = 0, ipl = 0;
	
	int i = 0;
	char str_tmp[40] = {0};
	int offset1;
	int offset2;
	int offset3;
	
	if(NULL == str)
	{
		return -1 ;
	}
	
	if (type == DOB2S)
	{
		memcpy(&ip1, ip, 8);
		memcpy(&ip2, ip + 8, 8);
		for(i = 0; i < 4; i++)
		{
			iph |= (ip1&(255llu<<(i*8)))<<((7-i*2)*8);
			ipl |= (ip2&(255llu<<(i*8)))<<((7-i*2)*8);
			iph |= (ip1&(255llu<<((7-i)*8)))>>((7-i*2)*8);
			ipl |= (ip2&(255llu<<((7-i)*8)))>>((7-i*2)*8);		
		}
		sprintf(str_tmp, "%016llx%016llx", iph,ipl );
	}
	else if (type == UNDOB2S)
	{
		sprintf(str_tmp, "%08llx%08llx%08llx%08llx", (unsigned long long int)ip_array[0], (unsigned long long int)ip_array[1], (unsigned long long int)ip_array[2], (unsigned long long int)ip_array[3]);
	}
		
	for (i = 0;i < 8;i++)
	{
		offset1 = i * 5;
		offset2 = i * 4;
		offset3 = offset1 + 4;
		memcpy(str + offset1, str_tmp + offset2, 4);
		memcpy(str + offset3, ":", 1);
	}
	
	str[offset3] = '\0';
	
	return 0;
}

//功能说明：ipv4的地址转字符串功能，传入参数是ipv4的地址和存储ipv4字符串的数组
inline void Dwbf_common_ipv4_2_string(u_int ip, u_char str[])
{	
	u_int val, k;	
	int i=0;	
	int greater_hundred=0;
	val=(ip>>24)&0xFF;	
	if((k=val/100)>0)
	{
		str[i++]=k+'0';		
		greater_hundred = 1;
	}
	if((k=val%100/10)>0 || greater_hundred==1)
	{
		str[i++]=k+'0';	
	}
	str[i++]=val%10+'0';	

	greater_hundred=0;
	val=(ip>>16)&0xFF;        
	if((k=val/100)>0)
	{
		str[i++]=k+'0'; 
		greater_hundred = 1;
	}
	if((k=val%100/10)>0 || greater_hundred==1)
	{
		str[i++]=k+'0';   
	}

	str[i++]=val%10+'0';		

	greater_hundred=0;
	val=(ip>>8)&0xFF;        
	if((k=val/100)>0)
	{
		str[i++]=k+'0';      
		greater_hundred = 1;
	}
	if((k=val%100/10)>0 || greater_hundred==1)
	{
		str[i++]=k+'0';
	}
	str[i++]=val%10+'0';	

	greater_hundred=0;
	val=ip&0xFF;        
	if((k=val/100)>0)
	{
		str[i++]=k+'0';   
		greater_hundred = 1;
	}
	if((k=val%100/10)>0 || greater_hundred==1)
	{
		str[i++]=k+'0'; 
	}
	str[i++]=val%10+'0';	
	str[i]='\0';
}

//功能说明：ipv4的地址转字符串功能，传入参数是ipv4的地址和存储ipv4字符串的数组带点
inline void Dwbf_common_ipv4_2_string_point(u_int ip, u_char str[])
{	
	u_int val, k;	
	int i=0;	
	int greater_hundred=0;
	val=(ip>>24)&0xFF;	
	if((k=val/100)>0)
	{
		str[i++]=k+'0';		
		greater_hundred = 1;
	}
	if((k=val%100/10)>0 || greater_hundred==1)
	{
		str[i++]=k+'0';	
	}
	str[i++]=val%10+'0';	
	str[i++]='.';	

	greater_hundred=0;
	val=(ip>>16)&0xFF;        
	if((k=val/100)>0)
	{
		str[i++]=k+'0'; 
		greater_hundred = 1;
	}
	if((k=val%100/10)>0 || greater_hundred==1)
	{
		str[i++]=k+'0';   
	}

	str[i++]=val%10+'0';	
	str[i++]='.';		

	greater_hundred=0;
	val=(ip>>8)&0xFF;        
	if((k=val/100)>0)
	{
		str[i++]=k+'0';      
		greater_hundred = 1;
	}
	if((k=val%100/10)>0 || greater_hundred==1)
	{
		str[i++]=k+'0';
	}
	str[i++]=val%10+'0';	
	str[i++]='.';	

	greater_hundred=0;
	val=ip&0xFF;        
	if((k=val/100)>0)
	{
		str[i++]=k+'0';   
		greater_hundred = 1;
	}
	if((k=val%100/10)>0 || greater_hundred==1)
	{
		str[i++]=k+'0'; 
	}
	str[i++]=val%10+'0';	
	str[i]='\0';
}

//功能说明：ipv6的字符串转数组功能，传入参数是ipv6字符串和存储ipv6的数组
inline int Dbfw_common_ipv6_string_2_array(char *ipv6_string, unsigned char *ipv6)
{
	unsigned char value = 0;
	unsigned char value_tmp = 0;
	int i = 0, j = 0;
	char *one_byte = NULL;
	
	if(NULL == ipv6_string)
	{
		return -1;
	}
	//16字节的ip，转换成32个字符的字符串，所以字符串数组必须超过32个才能存下

	for(j = 0; j < 16; j++)
	{
		one_byte = ipv6_string + j*2;
		value = 0;
		for(i = 0; i < 2; i++)
		{
			switch(one_byte[i])
			{
				case 'a':
				case 'b':	
				case 'c':
				case 'd':	
				case 'e':
				case 'f':
					value_tmp  = (one_byte[i] - 'a' + 10);
					value |= ( (i%2)? value_tmp : value_tmp*16);
					break;	
				case 'A':
				case 'B':	
				case 'C':
				case 'D':	
				case 'E':
				case 'F':
					value_tmp = (one_byte[i] - 'A' + 10);
					value |= ( (i%2)? value_tmp : value_tmp*16);
					break;	
				default:
					if(one_byte[i] < '0' || one_byte[i] > '9')
					{
						return -1;
					}
					else
					{
						value_tmp = (one_byte[i] - '0');
						value |= ( (i%2)? value_tmp : value_tmp*16);
					}
					break;				
			}
		}
		ipv6[j] = value;
	}
	
	return 0;
} 


/*
 *	功能:	查找指定字符的个数
 *	参数：
 *			str：被查找的字符串。
 *      value:查找的字符
 *	返回值:	个数的值
 */
inline int Dbfw_find_charnum(char *str, char value)
{
    int num = 0;

    while(str != NULL && *str != '\0')
    {
        if(*str == value)
        {
            num++;
        }
        str++;
    }
    return num;
}

/*
 *	功能:	把一个ipv6地址的缩写，改为ipv6地址的全写
 *	参数：
 *			abbreviation：缩写的ipv6地址
 *          fullip6:返回的全写的ipv6地址
 *          flag:返回的ipv6地址是否用:分隔，默认为0，不分割, flag非0，使用冒号分隔
 *	返回值:	unint的值
 */
inline int Dbfw_parse_abbreviationTofullip6(char *abbreviation, char *fullip6, int flag)
{
    int split_num = 0;
    int char_num = 0;
    char *token = NULL;
    int length = 0;
    char *tmp_ipv6 = fullip6;
    char tmp_abbreviation[40] = {0};
    char new_abbreviation[40] = {0};
    int j = 0, i = 0, k = 0;
    if(strcmp(abbreviation,"::")==0)
    {
        if(flag)
        {
            strcpy(fullip6,"0000:0000:0000:0000:0000:0000:0000:0000") ;
        }else{
            strcpy(fullip6,"00000000000000000000000000000000") ;
        }
       return 0;
    }

    strcpy(tmp_abbreviation, abbreviation);
	char_num = Dbfw_find_charnum(tmp_abbreviation, ':');
	
    token = strstr(abbreviation, "::");
    if(token)
    { 
		strcpy(new_abbreviation, token);//拷贝::开始后的后半段的数据。
		j = strlen(tmp_abbreviation) - strlen(token) + 1;
		if(1 == j)
		{//数据 ::开头是没有数字的，需要先补全
			strcpy(tmp_abbreviation, "0000:");
			j += 5;
		}
		memset(tmp_abbreviation + j, '\0', 1);//将缩写前半段保存到：：的第一个冒号处
		for( i=0; i<8-char_num; i++)
		{//填充补零的数据。共8段
			strcat(tmp_abbreviation, "0000:");
		}
		if(2 == strlen(new_abbreviation))
		{//数据::最后的数据为空，所以后面的也需要补全数据0000
			strcat(tmp_abbreviation, "0000");//前半段和后半段(为空时补4个零)合并。
		}
		else
		{
			strcat(tmp_abbreviation, new_abbreviation + 2);//前半段和后半段合并。
		}
    }
	//防守，为了那些带入fullip6时，数组未初始化的人使用，抱怨接口不好用问题
	tmp_ipv6[0] = '\0';
	
	//上面的一步保证了数据是完整带冒号的数据，下一步需要补零和加：处理
    token = strtok(tmp_abbreviation, ":");
    for( j=0; j < 8; j++)
    {
        if(token == NULL)
        {
			break;   
        }
       // printf("j :%d token *%s*\n", j, token);
        length = strlen(token);
        if(length > 4)
        {
            break;
        }else{
            //按位数补0
            length = 4-length;
            for(k=0; k<length; k++)
                strcat(tmp_ipv6 + k, "0");
        }
        strcat(tmp_ipv6, token);
        if(flag &&  7 != j)
		{
			strcat(tmp_ipv6, ":");
		}   

        split_num++;
        
        token = strtok(NULL, ":");
    }
    if(split_num !=8)
        return -1;
    return 0;
}

/*
 *	功能:	把一个ipv6全写地址，改为ipv6地址的缩写
 *	参数：
 *			abbreviation：缩写的ipv6地址
 *          fullip6:返回的全写的ipv6地址
 *          flag:ipv6全写地址是否用:分隔，默认为0，不分割
 *	返回值:	unint的值
 */
inline int Dbfw_parse_fullip6Toabbreviation(char *fullip6, int flag, char *abbreviation)
{
    int split_flag = 0;
    int char_num = 0;
    char *p = fullip6;
    int length = strlen(fullip6);

    if((flag && length!=39) || (flag==0 && length !=32))
        return -1;
   
    for(int i=0; i<length; i++)
    {
        if(*p == ':')
            continue;
        char_num++;
        if(char_num == 4)
        {
            if(!split_flag)
                strcat(abbreviation, ":");
            split_flag = 1;
            char_num = 0;
        }
        if((split_flag || i == 0) && *p == '0')
            continue;
        sprintf(abbreviation, "%s%c",abbreviation,*p);
        split_flag = 0;
    }
    return 0;
}


/*
 *	功能:	把一个整数转换为字符串
 *	参数：
 *			value：欲转换的数据。
 *			string：目标字符串的地址。
 *			radix：转换后的进制数，可以是10进制、16进制、2、8等。
 *	返回值:	指向string这个字符串的指针
 */
inline char *Dbfw_itoa(int value, char *string, int radix)
{
	const char ch[] = "0123456789abcdefghijklmnopqrstuvwxyz";
	unsigned int uvalue = 0;
	char *ptr = string;
	char *begin = NULL;
	char *end = NULL;
	char temp = '\0';
	
	//assert(NULL != string && radix > 0);
	

	if (value < 0 && 10 == radix)
	{
		uvalue = -value;
		*ptr++ = '-';
	}
	else
	{
		uvalue = (unsigned int)value;
	}
	
	begin = ptr;

	while (uvalue)
	{
		*ptr++ = ch[uvalue% radix];
		uvalue /= radix;
	}
	*ptr = '\0';

	end = ptr-1;
	

	while (begin < end)
	{
		temp = *begin;
		*begin = *end;
		*end = temp;
		
		++begin;
		--end;
	}
	
	return string;
}

/*
 *	功能:	把一个整数转换为16进制字符串
 *	参数：
 *			value：欲转换的数据。
 *			string：目标字符串的地址。
 *			size：string大小，最小为17字节。
 *	返回值:	指向string这个字符串的指针
 */
inline char *Dbfw_lltoha(unsigned long long value, char *string, unsigned int size)
{
	unsigned int bit = sizeof(unsigned long long) * 8;
	if(size < bit/4+1)
		return NULL;
		
	string[bit/4] = '\0';
	char *temp = string;
	for (unsigned int i = 0; i < bit/4; ++i)
	{
	    temp[i] = (value << 4 * i) >> (bit-4);
	    temp[i] = temp[i] >= 0 ? temp[i] : temp[i] + 16;
	    temp[i] = temp[i] < 10 ? temp[i] + 48 : temp[i] + 55;
	}
	return string;
}

/*
 *	功能:	write函数增加换行写入功能
 *	参数：
 *			fd: 文件句柄
 *			buf: 写入字符串信息
 *	返回值:	指向string这个字符串的指针
 */
inline int Dbfw_writeline(int fd,const void * buf)
{
	int  tmp_size = write(fd, buf, strlen((char *)buf));
	if(tmp_size > 0)
	{
		write(fd, "\n", 1);
	}
	return tmp_size;
}

/*
 *	功能:	写进程堆栈等信息到文件中
 *	参数：
 *			logfilename：日志文件名
 *	返回值:	
 */
inline void *Dbfw_writeFaultTrap(char * logfilename, int signo, 
				   siginfo_t *siginfo, 
				   void *context, int just_stack=0)
{
	int fd = 0;
	int i,num;  
	u_int64 i64_tmp=0;
	u_int64 regs[16];
	char tmp_str[32];
	char log_str[512];

	fd = open((char*)logfilename, O_WRONLY | O_CREAT |O_TRUNC ,0666);
	if(fd < 0)
	{
		return NULL;		
	}
	
	memset(log_str, 0x00, sizeof(log_str));
	strcpy(log_str,"Release ");
	strcat(log_str,DBFW_VERSION_MAX);
	strcat(log_str,".");
	strcat(log_str,DBFW_VERSION_MIN);
	strcat(log_str,".");
	strcat(log_str,DBFW_VERSION_PATCH);
	strcat(log_str," Build ");
	strcat(log_str,BUILD_DATE);
	strcat(log_str," ");
	strcat(log_str,BUILD_SVN);
	Dbfw_writeline(fd,log_str);
	
	Dbfw_writeline(fd, "Crash Reason: ");
	switch (signo)
	{
	case SIGSEGV:      /* 内存访问错误 */
		Dbfw_writeline(fd, "memory segment error\n");        
		break;
	case SIGBUS:    /* 使用存储映射函数发生错误 */
		Dbfw_writeline(fd, "memory bus error\n");
		break;
	case SIGFPE:    /* 除0错误 */
		Dbfw_writeline(fd, "div zero error\n");
		break;
	case SIGABRT:    /* 异常终止 */
		Dbfw_writeline(fd, "abort error\n");
		break;
	case SIGILL:    /* 非法硬件指令 */
		Dbfw_writeline(fd, "error hardware code\n");
		break;
	case SIGQUIT:    /* ctrl+\ */
		Dbfw_writeline(fd, "ctrl+\\\n");
		break;
	case SIGSYS:    /* 无效系统调用 */
		Dbfw_writeline(fd, "invalid system call\n");
		break;
	case SIGTRAP:    /* 硬件故障 */
		Dbfw_writeline(fd, "hardware error\n");
		break;
	default:
		Dbfw_writeline(fd, "unknown error\n");
		break;
	}
	
	/* 输出siginfo的成员变量 */
  	Dbfw_writeline(fd, "------------------- siginfo ----------------");
	/* 哪个信号引起程序crash, 与siginfo->si_signo的值相同*/
	memset(tmp_str, 0x00, sizeof(tmp_str));
	memset(log_str, 0x00, sizeof(log_str));
	Dbfw_itoa(signo,tmp_str,10);
	strcpy(log_str,"signal number: ");
	strcat(log_str, tmp_str);
	Dbfw_writeline(fd,log_str);
	
	/*信号代码，见APUE书264页*/
	memset(tmp_str, 0x00, sizeof(tmp_str));
	memset(log_str, 0x00, sizeof(log_str));
	Dbfw_itoa(siginfo->si_code,tmp_str,10);
	strcpy(log_str,"signal code: ");
	strcat(log_str, tmp_str);
	Dbfw_writeline(fd,log_str);
	
	/*产生错误的内存地址,当信号是SIGSEGV或SIGILL时才有此地址*/   
	memset(tmp_str, 0x00, sizeof(tmp_str));
	memset(log_str, 0x00, sizeof(log_str));
	i64_tmp=(u_int64)siginfo->si_addr;
	Dbfw_lltoha(i64_tmp,tmp_str,sizeof(tmp_str));
	strcpy(log_str,"fault address:0x");
	strcat(log_str, tmp_str);
	Dbfw_writeline(fd,log_str);  

	/*<errno.h>中定义的错误号*/
	memset(tmp_str, 0x00, sizeof(tmp_str));
	memset(log_str, 0x00, sizeof(log_str));
	Dbfw_itoa(siginfo->si_errno,tmp_str,10);
	strcpy(log_str,"errno: ");
	strcat(log_str, tmp_str);
	Dbfw_writeline(fd,log_str);
	Dbfw_writeline(fd, "------------------- end of siginfo ----------------\n");
	
	if(!just_stack)
	{
		/* 输出Registers */
	  Dbfw_writeline(fd, "------------------- Registers ----------------");
	  Dbfw_GetRegisters(context, regs);
	  memset(log_str, 0x00, sizeof(log_str));
	  strcpy(log_str, "rip = ");
	  memset(tmp_str, 0x00, sizeof(tmp_str));
	  Dbfw_lltoha(regs[0],tmp_str,sizeof(tmp_str));
		strcat(log_str, tmp_str);
		strcat(log_str,"  rsp = ");
		memset(tmp_str, 0x00, sizeof(tmp_str));
	  Dbfw_lltoha(regs[1],tmp_str,sizeof(tmp_str));
		strcat(log_str, tmp_str);
		strcat(log_str,"  rbp = ");
		memset(tmp_str, 0x00, sizeof(tmp_str));
	  Dbfw_lltoha(regs[2],tmp_str,sizeof(tmp_str));
	  strcat(log_str, tmp_str);
	  strcat(log_str,"  rdi = ");
		memset(tmp_str, 0x00, sizeof(tmp_str));
	  Dbfw_lltoha(regs[3],tmp_str,sizeof(tmp_str));
		strcat(log_str, tmp_str);
		Dbfw_writeline(fd, log_str);
		
		memset(log_str, 0x00, sizeof(log_str));
	  strcpy(log_str, "rsi = ");
	  memset(tmp_str, 0x00, sizeof(tmp_str));
	  Dbfw_lltoha(regs[4],tmp_str,sizeof(tmp_str));
		strcat(log_str, tmp_str);
		strcat(log_str,"  rax = ");
		memset(tmp_str, 0x00, sizeof(tmp_str));
	  Dbfw_lltoha(regs[5],tmp_str,sizeof(tmp_str));
		strcat(log_str, tmp_str);
		strcat(log_str,"  rbx = ");
		memset(tmp_str, 0x00, sizeof(tmp_str));
	  Dbfw_lltoha(regs[6],tmp_str,sizeof(tmp_str));
	  strcat(log_str, tmp_str);
	  strcat(log_str,"  rcx = ");
		memset(tmp_str, 0x00, sizeof(tmp_str));
	  Dbfw_lltoha(regs[7],tmp_str,sizeof(tmp_str));
		strcat(log_str, tmp_str);
		Dbfw_writeline(fd, log_str);
		
		memset(log_str, 0x00, sizeof(log_str));
	  strcpy(log_str, "rdx = ");
	  memset(tmp_str, 0x00, sizeof(tmp_str));
	  Dbfw_lltoha(regs[8],tmp_str,sizeof(tmp_str));
		strcat(log_str, tmp_str);
		strcat(log_str,"  cs = ");
		memset(tmp_str, 0x00, sizeof(tmp_str));
	  Dbfw_lltoha(regs[9],tmp_str,sizeof(tmp_str));
		strcat(log_str, tmp_str);
		strcat(log_str,"  gs = ");
		memset(tmp_str, 0x00, sizeof(tmp_str));
	  Dbfw_lltoha(regs[10],tmp_str,sizeof(tmp_str));
	  strcat(log_str, tmp_str);
	  strcat(log_str,"  fs = ");
		memset(tmp_str, 0x00, sizeof(tmp_str));
	  Dbfw_lltoha(regs[11],tmp_str,sizeof(tmp_str));
		strcat(log_str, tmp_str);
		Dbfw_writeline(fd, log_str);
		
		memset(log_str, 0x00, sizeof(log_str));
	  strcpy(log_str, "eflags = ");
	  memset(tmp_str, 0x00, sizeof(tmp_str));
	  Dbfw_lltoha(regs[12],tmp_str,sizeof(tmp_str));
		strcat(log_str, tmp_str);
		Dbfw_writeline(fd, log_str);
	  Dbfw_writeline(fd, "------------------- End of Registers ----------------\n");
	
	  Dbfw_writeline(fd, "------------------- Blocked Signals ----------------------");
	  sigset_t mask=Dbfw_GetSigmask(context);
	  for(i=1;i<32;++i)
	  {
	      if(sigismember(&mask, i))
	      {
	      		memset(tmp_str, 0x00, sizeof(tmp_str));
	      		Dbfw_itoa(i,tmp_str,10);
	          Dbfw_writeline(fd,tmp_str);    
	      }
	  }
	  Dbfw_writeline(fd, "------------------- End of Blocked Signals ----------------------\n");
  }

	Dbfw_writeline(fd,"---------------- Begin of Stack Trace ---------------------");
	
	/*调用此接口，不用malloc，避免该函数的不可重入，且直接写文件*/
	Dbfw_Backtrace_Fd(&num, fd);

	Dbfw_writeline(fd, "---------------- End of Stack Trace -----------------\n\n");
	close(fd);
	return NULL;
}

#endif