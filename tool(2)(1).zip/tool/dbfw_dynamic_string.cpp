/********************************************************************
** dbfw_dynamic_string.cpp
**
** purpose: 
** 
** author:  yanghaifeng@schina.cn
** Copyright (C) 2012 SChina (www.schina.cn) 
**	
*********************************************************************/
#include <stdlib.h>
#include <string.h>

#include "dbfw_global.h"
#include "oranethelp.h"
#include "dbfw_dynamic_string.h"

#include "dbfw_smem.h"
#include "smem_log.h"

#ifdef SOURCECODE
#undef SOURCECODE
#endif
#define SOURCECODE 6
/***********************************************************************
**
** NAME
**      Dbfw_Init_Dynamic_String
**
** DESCRIPTION
**      初始化动态字符串对象
**      
** PARAM
**      
** RETURN
**      -1 : malloc fail
************************************************************************
*/
int Dbfw_Init_Dynamic_String(DBFW_DYNAMIC_STR *str, const char *init_str,
                             u_int init_alloc, u_int alloc_increment)
{
    u_int length;
    u_int init_size;
    init_size = init_alloc;
    if (!alloc_increment)
        alloc_increment=DBFW_DYNASTR_DEFAULT_INCREMENT;    
    length=1;
    if (init_str && (length= strlen(init_str)+1) < init_alloc)
        //init_alloc=((length+alloc_increment-1)/alloc_increment)*alloc_increment;
        init_size = init_alloc;
    else
        init_size = length;
    //if (!init_alloc)
    //    init_alloc=alloc_increment;

    str->str=(u_char*) ZMalloc(init_size);
    if(str->str==NULL)
    {
        return -1;
    }

    str->length=length-1;
    if (init_str)
        z_memcpy(str->str,init_str,length, __FILE__, __LINE__, Smem_LogError_Format);
    str->max_length=init_size;
    str->alloc_increment=alloc_increment;
    return 1;
}

int Dbfw_Init_Dynamic_String_WithCode(DBFW_DYNAMIC_STR *str, const char *init_str,
                                      u_int init_alloc, u_int alloc_increment,u_char p_SOURCECODE,u_short p_LINE)
{
    u_int length;
    u_int init_size;
    init_size = init_alloc;
    if (!alloc_increment)
        alloc_increment=DBFW_DYNASTR_DEFAULT_INCREMENT;    
    length=1;
    if (init_str && (length= strlen(init_str)+1) < init_alloc)
        //init_alloc=((length+alloc_increment-1)/alloc_increment)*alloc_increment;
        init_size = init_alloc;
    else
        init_size = length;
    //if (!init_alloc)
    //    init_alloc=alloc_increment;
#ifdef MEMPOOL_WITHSTACKWALK
    str->str=(u_char*)ZMalloc_WithStackWalk(p_SOURCECODE,p_LINE,init_size);
#else
    str->str=(u_char*) ZMalloc(init_size);
#endif
    if(str->str==NULL)
    {
        return -1;
    }

    str->length=length-1;
    if (init_str)
        z_memcpy(str->str,init_str,length, __FILE__, __LINE__, Smem_LogError_Format);
    str->max_length=init_size;
    str->alloc_increment=alloc_increment;
    return 1;
}
int Dbfw_DynStr_Set(DBFW_DYNAMIC_STR *str, const char *init_str)
{
    u_int length=0;

    if (init_str && (length= (u_int) strlen(init_str)+1) > str->max_length)
    {
        str->max_length=((length+str->alloc_increment-1)/str->alloc_increment)*
            str->alloc_increment;
        if (!str->max_length)
            str->max_length=str->alloc_increment;
        if(str->str)
            ZFree(str->str);
        str->str = (u_char*)ZMalloc(str->max_length);
        if(str->str==NULL)
            return -1;
    }
    if (init_str)
    {
        memset(str->str,0x00,str->max_length);
        str->length=length-1;
        z_memcpy(str->str,init_str,length, __FILE__, __LINE__, Smem_LogError_Format);
    }
    else
        str->length=0;
    return 1;
}

/***********************************************************************
**
** NAME
**      Dbfw_DynStr_Realloc
**
** DESCRIPTION
**      重新分配动态字符串空间,并将内容清为0x00
**      
** PARAM
**      
** RETURN
**      
************************************************************************
*/
int Dbfw_DynStr_Realloc(DBFW_DYNAMIC_STR *str, u_int additional_size)
{
    if (!additional_size) return 0;
    if (str->length + additional_size > str->max_length)
    {
        str->max_length=((str->length + additional_size+str->alloc_increment-1)/
            str->alloc_increment)*str->alloc_increment;
        if(str->str)
            ZFree(str->str);
        str->str = (u_char*)ZMalloc(str->max_length);
        if(str->str == NULL)
            return -1;
        memset(str->str,0x00,str->max_length);
    }
    return 1;
}

/***********************************************************************
**
** NAME
**      Dbfw_DynStr_Append_Mem
**
** DESCRIPTION
**      向动态字符串中添加新的指定长度的内容
**      
** PARAM
**      
** RETURN
**      
************************************************************************
*/

int Dbfw_DynStr_Append_Mem(DBFW_DYNAMIC_STR *str, const char *append,
                           u_int length)
{
    u_char *new_ptr;
    if (str->length+length >= str->max_length)
    {
        size_t new_length=(str->length+length+str->alloc_increment)/
            str->alloc_increment;
        new_length*=str->alloc_increment;
//#ifdef MEMPOOL_WITHSTACKWALK
//		ZMalloc_WithStackWalk(p_SOURCECODE,p_LINE,new_length);
//#else
        new_ptr = (u_char*)ZMalloc(new_length);
//#endif
        if(new_ptr==NULL)
            return -1;
        memset(new_ptr,0x00,new_length);
        z_memcpy(new_ptr,str->str,str->length, __FILE__, __LINE__, Smem_LogError_Format);
        ZFree(str->str);
        str->str=new_ptr;
        str->max_length=new_length;
    }
    z_memcpy(str->str + str->length,append,length, __FILE__, __LINE__, Smem_LogError_Format);
    str->length+=length;
    //str->str[str->length]=0;			/* Safety for C programs */
    return 1;
}

int Dbfw_DynStr_Append_Mem_WithCode(DBFW_DYNAMIC_STR *str, const char *append,
                           u_int length,u_char p_SOURCECODE,u_short p_LINE)
{
    u_char *new_ptr;
    if (str->length+length >= str->max_length)
    {
        size_t new_length=(str->length+length+str->alloc_increment)/
            str->alloc_increment;
        new_length*=str->alloc_increment;
#ifdef MEMPOOL_WITHSTACKWALK
   		new_ptr = (u_char*)ZMalloc_WithStackWalk(p_SOURCECODE,p_LINE,new_length);
#else
        new_ptr = (u_char*)ZMalloc(new_length);
#endif
        if(new_ptr==NULL)
            return -1;
        memset(new_ptr,0x00,new_length);
        z_memcpy(new_ptr,str->str,str->length, __FILE__, __LINE__, Smem_LogError_Format);
        ZFree(str->str);
        str->str=new_ptr;
        str->max_length=new_length;
    }
    z_memcpy(str->str + str->length,append,length, __FILE__, __LINE__, Smem_LogError_Format);
    str->length+=length;
    //str->str[str->length]=0;			/* Safety for C programs */
    return 1;
}

int Dbfw_DynStr_Expand_Mem_WithCode(DBFW_DYNAMIC_STR *str, 
                           u_int length,u_char p_SOURCECODE,u_short p_LINE)
{
    u_char *new_ptr;
    if (str->length+length >= str->max_length)
    {
        size_t new_length=(str->length+length+str->alloc_increment)/
            str->alloc_increment;
        new_length*=str->alloc_increment;
#ifdef MEMPOOL_WITHSTACKWALK
   		new_ptr = (u_char*)ZMalloc_WithStackWalk(p_SOURCECODE,p_LINE,new_length);
#else
        new_ptr = (u_char*)ZMalloc(new_length);
#endif
        if(new_ptr==NULL)
            return -1;
        memset(new_ptr,0x00,new_length);
        z_memcpy(new_ptr,str->str,str->length, __FILE__, __LINE__, Smem_LogError_Format);
        ZFree(str->str);
        str->str=new_ptr;
        str->max_length=new_length;
    }
    memset(str->str + str->length,0,length);
    str->length+=length;
    //str->str[str->length]=0;			/* Safety for C programs */
    return 1;
}

/***********************************************************************
**
** NAME
**      Dbfw_DynStr_Append
**
** DESCRIPTION
**      向动态字符串中添加新的字符串内容
**      
** PARAM
**      
** RETURN
**      
************************************************************************
*/
int Dbfw_DynStr_Append(DBFW_DYNAMIC_STR *str, const char *append)
{
    //return Dbfw_DynStr_Append_Mem(str,append,(u_int) strlen(append));
    return Dbfw_DynStr_Append_Mem_WithCode(str,append,(u_int) strlen(append),SOURCECODE,__LINE__);
}

/***********************************************************************
**
** NAME
**      Dbfw_DynStr_Trunc
**
** DESCRIPTION
**      将动态字符串中的内容从尾部去掉n字节
**      
** PARAM
**      
** RETURN
**      
************************************************************************
*/
int Dbfw_DynStr_Trunc(DBFW_DYNAMIC_STR *str, u_int n)
{
    if(str->length<n)
    {
        str->length = 0;        
    }
    else
    {
        str->length-=n;
    }    
    if(str->str != NULL)
    {
        str->str[str->length]= '\0';    /* Safety for C programs */
    }
    return 1;
}

int Dbfw_DynStr_Free(DBFW_DYNAMIC_STR *str)
{
    if(str->str)
        ZFree(str->str);
    str->length = 0;
    return 1;
}



int Dbfw_Init_Dynamic_Array(Dbfw_Dynamic_Array_Int *array, u_int init_alloc, u_int alloc_increment)
{
	u_int init_size;
	init_size = init_alloc;
	if (!alloc_increment)
		alloc_increment=DBFW_DYNASTR_DEFAULT_INCREMENT;    

	array->str=(u_int*)ZMalloc(init_size*sizeof(u_int));
	if(array->str==NULL)
	{
		return -1;
	}

	array->length=0;
	array->max_length=init_size;
	array->alloc_increment=alloc_increment;
	return 1;
}
int Dbfw_DynArray_Append_Mem(Dbfw_Dynamic_Array_Int *array, const u_int *append,
							 u_int length)
{
	u_int *new_ptr;
	if (array->length+length >= array->max_length)
	{
		size_t new_length=(array->length+length+array->alloc_increment)/
			array->alloc_increment;
		new_length*= array->alloc_increment;
		//size_t new_length=array->alloc_increment*2;
		new_ptr = (u_int*)ZMalloc(new_length*sizeof(u_int));
		if(new_ptr==NULL)
			return -1;
		memset(new_ptr,0x00,new_length*sizeof(u_int));
		z_memcpy(new_ptr,array->str,array->length*sizeof(u_int), __FILE__, __LINE__, Smem_LogError_Format);
		ZFree(array->str);
		array->str=new_ptr;
		array->max_length=new_length;
	}
	z_memcpy(array->str + array->length,append,length*sizeof(u_int), __FILE__, __LINE__, Smem_LogError_Format);
	array->length+=length;
	return 1;
}

int Dbfw_DynInt_Set(Dbfw_Dynamic_Array_Int *array)
{
	memset(array->str,0x00,array->max_length*sizeof(u_int));
	array->length = 0;
	return 1;
}

int Dbfw_DynInt_Free(Dbfw_Dynamic_Array_Int *array)
{
	if(array->str)
		ZFree(array->str);
	array->length = 0;
	return 1;
}
