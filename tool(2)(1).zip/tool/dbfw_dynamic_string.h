/********************************************************************
** dbfw_dynamic_string.h
**
** purpose: 
** 
** author:  yanghaifeng@schina.cn
** Copyright (C) 2012 SChina (www.schina.cn) 
**	
*********************************************************************/
#ifndef _DBFW_DYNAMIC_STRING_H_
#define _DBFW_DYNAMIC_STRING_H_

#include "dbfw_global.h"

#define DBFW_DYNASTR_DEFAULT_INCREMENT  128     /* 缺省的increment字节数 */
#pragma pack(1)
typedef struct Dbfw_Dynamic_String
{
    u_char  *str;
    u_int   length;             /* 当前字符串的有效长度（可能实际的长度超出了本有效长度） */
    u_int   max_length;         /* 当前字符串的最大长度 */
    u_int   alloc_increment;    /* 空间不足时，每次增加的尺寸 */
} DBFW_DYNAMIC_STR;

typedef struct Dbfw_Dynamic_Array_Int
{
	u_int  *str;
	u_int   length;             /* 当前 */
	u_int   max_length;         /* 当前 的个数*/
	u_int   alloc_increment;    /* 空间不足时, 增加的个数*/
} Dbfw_Dynamic_Array_Int;
#pragma pack()
/***********************************************************************
**
** NAME
**      Dbfw_Init_Dynamic_String
**
** DESCRIPTION
**      初始化动态字符串对象
**      
** PARAM
**      
** RETURN
**      
************************************************************************
*/
int Dbfw_Init_Dynamic_String(DBFW_DYNAMIC_STR *str, const char *init_str,
                            u_int init_alloc, u_int alloc_increment);
int Dbfw_Init_Dynamic_String_WithCode(DBFW_DYNAMIC_STR *str, const char *init_str,
                                      u_int init_alloc, u_int alloc_increment,u_char p_SOURCECODE=1,u_short p_LINE=1);
/***********************************************************************
**
** NAME
**      Dbfw_DynStr_Set
**
** DESCRIPTION
**      设置动态字符串的内容
**      如果长度小于原来的字符串长度，则不进行收缩处理，只是用新的字符串来替换原来字符串的相应字节数，并且修改
**      
** PARAM
**      
** RETURN
**      
************************************************************************
*/
int Dbfw_DynStr_Set(DBFW_DYNAMIC_STR *str, const char *init_str);

/***********************************************************************
**
** NAME
**      Dbfw_DynStr_Realloc
**
** DESCRIPTION
**      重新分配动态字符串空间,并将内容清为0x00
**      
** PARAM
**      
** RETURN
**      
************************************************************************
*/
int Dbfw_DynStr_Realloc(DBFW_DYNAMIC_STR *str, u_int additional_size);

/***********************************************************************
**
** NAME
**      Dbfw_DynStr_Append_Mem
**
** DESCRIPTION
**      向动态字符串中添加新的指定长度的内容
**      
** PARAM
**      
** RETURN
**      
************************************************************************
*/
 int Dbfw_DynStr_Append_Mem_WithCode(DBFW_DYNAMIC_STR *str, const char *append,
                           u_int length,u_char p_SOURCECODE=1,u_short p_LINE=1);int Dbfw_DynStr_Append_Mem(DBFW_DYNAMIC_STR *str, const char *append,
                           u_int length);

/***********************************************************************
**
** NAME
**      Dbfw_DynStr_Expand_Mem_WithCode
**
** DESCRIPTION
**      向动态字符串中扩充指定长度内容为0x00的内容
**      
** PARAM
**      
** RETURN
**      
************************************************************************
*/
int Dbfw_DynStr_Expand_Mem_WithCode(DBFW_DYNAMIC_STR *str, 
                           u_int length,u_char p_SOURCECODE,u_short p_LINE);
/***********************************************************************
**
** NAME
**      Dbfw_DynStr_Append
**
** DESCRIPTION
**      向动态字符串中添加新的字符串内容
**      
** PARAM
**      
** RETURN
**      
************************************************************************
*/
int Dbfw_DynStr_Append(DBFW_DYNAMIC_STR *str, const char *append);

/***********************************************************************
**
** NAME
**      Dbfw_DynStr_Trunc
**
** DESCRIPTION
**      将动态字符串中的内容从尾部去掉n字节
**      
** PARAM
**      
** RETURN
**      
************************************************************************
*/
int Dbfw_DynStr_Trunc(DBFW_DYNAMIC_STR *str, u_int n);

int Dbfw_DynStr_Free(DBFW_DYNAMIC_STR *str);

int Dbfw_Init_Dynamic_Array(Dbfw_Dynamic_Array_Int *array, u_int init_alloc, u_int alloc_increment);
int Dbfw_DynArray_Append_Mem(Dbfw_Dynamic_Array_Int *array, const u_int *append,u_int length);
int Dbfw_DynInt_Set(Dbfw_Dynamic_Array_Int *array);
int Dbfw_DynInt_Free(Dbfw_Dynamic_Array_Int *array);
#endif  /* _DBFW_DYNAMIC_STRING_H_ */