/********************************************************************
** dbfw_global.h
**
** purpose: 
** 
** author:  yanghaifeng@schina.cn
** Copyright (C) 2011 SChina (www.schina.cn) 
**	
*********************************************************************/

#ifndef _DBFW_GLOBAL_H_
#define _DBFW_GLOBAL_H_ 

#if !defined off64_t && defined __CYGWIN__
#   ifdef _off64_t
#       define off64_t _off64_t
#   else
       typedef long long off64_t;
#   endif
#endif

#ifndef u_int
#  define u_int unsigned int
#endif
#ifndef u_short
#  define u_short unsigned short
#endif
#ifndef u_char
#  define u_char unsigned char
#endif
#ifndef Bool
#  define Bool int
#endif

#ifdef _MSC_VER
#  ifndef int64
#    define int64 __int64
#  endif
#  ifndef u_int64
#    define u_int64 unsigned __int64
#  endif
#else
#  ifndef int64
#    define int64 long long
#  endif
#  ifndef u_int64
#    define u_int64 unsigned long long
#  endif
#endif

#if defined _MSC_VER || defined __CYGWIN__ || defined __i386 || defined _linux
#   define DBFW_HTON16(x)    ((((x) & 0xff00u) >> 1*8) | \
                             (((x) & 0x00ffu) << 1*8))
#   define DBFW_HTON32(x)    ((((x) & 0x000000ffu) << 24) | \
                             (((x) & 0x0000ff00u) << 8)  | \
                             (((x) & 0x00ff0000u) >> 8)  | \
                             (((x) & 0xff000000u) >> 24))
#else
#   define DBFW_HTON16(x) (x)
#   define DBFW_HTON32(x) (x)
#endif
#define DBFW_NTOH16(x) DBFW_HTON16(x)
#define DBFW_NTOH32(x) DBFW_HTON32(x)

/*
    版本号
*/
#ifdef DBFW_VERSION_MAX_PREDEF
    #define DBFW_VERSION_MAX    DBFW_VERSION_MAX_PREDEF
#else
    #define DBFW_VERSION_MAX    "0"
#endif
#ifdef DBFW_VERSION_MIN_PREDEF
    #define DBFW_VERSION_MIN    DBFW_VERSION_MIN_PREDEF
#else
    #define DBFW_VERSION_MIN    "0"
#endif
#ifdef DBFW_VERSION_PATCH_PREDEF
#define DBFW_VERSION_PATCH  DBFW_VERSION_PATCH_PREDEF
#else
    #define DBFW_VERSION_PATCH  "0.0"
#endif

/* 
    build号 
    由日期时间+SVN号(5字节)组成
    在Make的时候通过程序来替换为实际的SVN号和日期时间
*/
#ifdef BUILD_DATE_PREDEF
    #define BUILD_DATE BUILD_DATE_PREDEF
#else
    #define BUILD_DATE  "0000-00-00 00:00:00"
#endif
#ifdef BUILD_SVN_PREDEF
    #define BUILD_SVN BUILD_SVN_PREDEF
#else
    #define BUILD_SVN  "0000"
#endif


/***********************************************************************/
//各进程错误号偏移定义
#define IM_PROCESS_ERROR_MSG				-40000
#define NPC_PROCESS_ERROR_MSG				-41000
#define NPDP_PROCESS_ERROR_MSG				-42000
#define RS_PROCESS_ERROR_MSG				-43000
#define NP_PROCESS_ERROR_MSG				-44000
#define NPLS_PROCESS_ERROR_MSG				-45000
#define	NPP_PROCESS_ERROR_MSG				-46000
#define TLW_PROCESS_ERROR_MSG				-47000
#define TLP_PROCESS_ERROR_MSG				-48000
#define SMON_PROCESS_ERROR_MSG				-49000
#define PMON_PROCESS_ERROR_MSG				-50000
#define NMON_PROCESS_ERROR_MSG				-51000
#define CARRIER_PROCESS_ERROR_MSG			-52000


#pragma pack(1)




#pragma pack()

//for config file
#define MAX_VALUE_LEN		128	
#define KEY_MAX_LEN         64
#define KEY_VALUE_MAX_LEN   1024
#define MAX_PATH_LEN		1024
#define MAX_SQL_LEN			2048

//global param from config file identified
#endif /* _DBFW_GLOBAL_H_ */
