#ifndef _DBFW_IPC_H_
#define _DBFW_IPC_H_

#ifdef WIN32
#include <Windows.h>
#else
#include <unistd.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/sem.h>
#include <sys/shm.h>
#include <pthread.h>
#include <signal.h>
#include <sys/wait.h>
#include <execinfo.h> 
#include <ucontext.h>
#include <string.h>
#include <errno.h>
#include <sys/time.h>
#include <sys/resource.h>
#include <unistd.h>
#include <sys/types.h>
#endif

#include "dbfw_global.h"

#ifdef WIN32
#define inline __inline
#endif

#ifdef WIN32

/*用临界代码段封装成互斥量*/
typedef CRITICAL_SECTION pthread_mutex_t;
#define pthread_mutex_init(A)		InitializeCriticalSection(A)
#define pthread_mutex_lock(A)		EnterCriticalSection(A)
#define pthread_mutex_trylock(A)	TryEnterCriticalSection(A)
#define pthread_mutex_unlock(A)		LeaveCriticalSection(A)
#define pthread_mutex_destroy(A)	DeleteCriticalSection(A)

/*封装信号量*/
typedef HANDLE dbfw_sem_t;
#define SEM_MAX_VAL 32767	/*信号量的最大值*/

/*封装线程函数*/
typedef UINT	pthread_t;
typedef HANDLE	pthread_handle;

#else
//#ifndef ACE_HAS_SEMUN
union dbfw_semun{
    int val;
    struct semid_ds *buf;
    unsigned short  *array;	
};
//#endif
typedef int dbfw_sem_t;

#endif


/*********************************
 *
 *	信号量接口
 *
 **********************************/

/*
 *	linux版:	创建一个信号量集合，其中只包含一个信号量
 *	windows版:	创建一个信号量内核对象
 *	val:		信号量的初值
 *	返回值:		linux版:成功则返回信号量id，失败则返回-1，错误编号在errno中。
 *				windows版:成功则返回信号量句柄，失败则返回NULL。
 */
inline dbfw_sem_t Dbfw_CreateSem(int val)
{
#ifdef WIN32
    return CreateSemaphore(NULL, val, SEM_MAX_VAL, NULL);
#else
    int sem_id = 0;
    union dbfw_semun arg;
    int count = 0;

    /*
     * 我们发现在CentOS5.5上 0 信号量不稳定,偶尔会误报 ERMID(43) 错误，
     * 因此如果创建了0信号量，那么我们会重新创建；
     * 对于已经创建的 0 信号量，也不需要再关闭它，以免0被重复使用；
     * 因此，对于下面的循环，也只有第一次调用时才会循环两次，后续调用
     * 只循环一次就足够了。
     */
    for(count=0;count<2;count++)
    {
        sem_id = semget(IPC_PRIVATE, 1, IPC_CREAT|IPC_EXCL|0660);
        if(sem_id == -1)
        {
            return -1;
        }
        if(sem_id > 0)
        {
            arg.val=val;
            semctl(sem_id,0, SETVAL, arg);
            return sem_id;
        }
    }
    return -1;
#endif
}

/*
 *	linux版:	设置信号量集合中一个信号量的初始值
 *               用于信号量的归零防止超过32767
 *	val:		信号量的初值
 *	返回值:	linux版:成功则返回信号量id
 */
inline dbfw_sem_t Dbfw_SemSetValue(int sem_id,int val)
{
    union dbfw_semun arg;
    if(sem_id > 0)
    {
        arg.val=val;
        semctl(sem_id,0, SETVAL, arg);		
    }
    return sem_id;
}


/*
 *	linux版:	创建一个信号量集合，其中只包含一个信号量
 *	sid:		信号量的id
 *	返回值:		返回是否成功改变mode。
 */
inline dbfw_sem_t Dbfw_ChangeSemMode(int sid)
{
    union semun {
        int              val;    /* Value for SETVAL */
        struct semid_ds *buf;    /* Buffer for IPC_STAT, IPC_SET */
        unsigned short  *array;  /* Array for GETALL, SETALL */
        struct seminfo  *__buf;  /* Buffer for IPC_INFO (Linux-specific) */
    };

    int rc; 
    union semun semopts;
    struct semid_ds mysemds;
	int userid = 0;
	
    semopts.buf = &mysemds;

    rc = semctl(sid , 0 , IPC_STAT , semopts);

    if(rc == -1) 
        return rc;

	userid = getuid();
	if(userid)
	{
		mysemds.sem_perm.uid = userid;
		mysemds.sem_perm.cuid = userid;	
	}
	else
	{
		mysemds.sem_perm.uid = mysemds.sem_perm.gid;
		mysemds.sem_perm.cuid = mysemds.sem_perm.cgid;
	}

    rc = semctl(sid , 0 , IPC_SET , semopts);

    return rc;
}

/*
 *   对信号量减1
 *   返回值:成功则返回0，出错则返回-1，错误编号在errno中。
 */
inline int Dbfw_LockSem(dbfw_sem_t sem_id)
{
#ifdef WIN32
    if(WaitForSingleObject(sem_id, INFINITE)==WAIT_OBJECT_0)
        return 0;
    return -1;
#else
    static struct sembuf semoparray[1]={{0,-1,0}};
    return semop(sem_id, semoparray, 1);
#endif
}
/*
 *   对信号量减1，若到达超时时间则返回。超时时间以毫秒为单位
 *   返回值:
 *       0：成功
 *       -1：出错或超时，错误编号在errno中(超时的错误号是EAGAIN)。
 */
inline int Dbfw_LockSemTimed(dbfw_sem_t sem_id, u_int milliseconds)
{
#ifdef WIN32
    if(WaitForSingleObject(sem_id, milliseconds)==WAIT_OBJECT_0)
        return 0;
    return -1;
#else
    static struct sembuf semoparray[1]={{0,-1,0}};
    struct timespec timeout;
    timeout.tv_sec=milliseconds/1000;
    timeout.tv_nsec=milliseconds%1000*1000000;
    return semtimedop(sem_id, semoparray, 1, &timeout);
#endif
}

/*
 *   对信号量加1
 *   返回值:成功则返回0，出错则返回-1，错误编号在errno中。
 */
inline int Dbfw_UnlockSem(dbfw_sem_t sem_id)
{
#ifdef WIN32
    if(ReleaseSemaphore(sem_id, 1, NULL)==TRUE)
        return 0;
    return -1;
#else
    static struct sembuf semoparray[1]={{0,1,0}};
    return semop(sem_id, semoparray, 1);
#endif
}
/*
 *   返回信号量的值。Windows没有取得信号量值的接口。
 *   返回值：
 *       >=0: 信号量的值
 *       -1：出错
 */
#ifndef WIN32
inline int Dbfw_GetSemValue(dbfw_sem_t sem_id)
{
    return semctl(sem_id, 0, GETVAL);
}
#endif
/*
 *   删除信号量集合(linux版)，或关闭信号量内核对象(windows版)
 */
inline void Dbfw_RemoveSem(dbfw_sem_t sem_id)
{
#ifdef WIN32
    CloseHandle(sem_id);
#else
    semctl(sem_id,0,IPC_RMID);	
#endif
}

#ifndef WIN32

/*****************
 *
 *	共享内存接口
 *
 ******************/

/*
 *  创建共享内存
 *  shm_size:共享内存大小
 *  返回值:成功则返回共享内存id,失败则返回-1
 */
inline int Dbfw_CreateShm(unsigned int shm_size)
{
    return shmget(IPC_PRIVATE, shm_size, 0660);
}

/*
 *  连接共享内存
 *  shm_id:共享内存id
 *  返回值:成功则返回地址，失败则返回-1
 */
inline void* Dbfw_AttachShm(int shm_id)
{
    return shmat(shm_id, NULL, 0);
}

/*
 *  脱接共享内存
 *  shm_addr:共享内存地址
 *  返回值:成功则返回0，失败则返回-1
 */
inline int Dbfw_DetachShm(void* shm_addr)
{
    return shmdt(shm_addr);	
}

/*
 *  删除共享内存
 *  shm_id:共享内存id
 *  返回值:成功则返回0，失败则返回-1
 */
inline int Dbfw_RemoveShm(int shm_id)
{	  
    return shmctl(shm_id, IPC_RMID, NULL);
}
#endif


/*********************************
 *
 *	互斥量接口
 *
 *********************************/
/*
 *   初始化可用于进程间同步的互斥量
 *   返回值:成功则返回0，失败则返回错误号
 */
inline int Dbfw_InitMutex(pthread_mutex_t* mutex)
{
#ifdef WIN32
    pthread_mutex_init(mutex);
#else
    int ret;
    pthread_mutexattr_t mattr;
    if((ret=pthread_mutexattr_init(&mattr))!=0)
    {
        return ret;
    }

    if((ret=pthread_mutexattr_setpshared(&mattr, PTHREAD_PROCESS_SHARED))!=0)
    {
        return ret;
    }

    if((ret=pthread_mutex_init(mutex, &mattr))!=0)
    {
        return ret;
    }

    if((ret=pthread_mutexattr_destroy(&mattr))!=0)
    {
        return ret;
    }
#endif	  
    return 0;
}

/*
 *   对互斥量加锁
 *   返回值:成功则返回0，失败则返回错误号
 */
inline int Dbfw_LockMutex(pthread_mutex_t* mutex)
{
#ifdef WIN32
    pthread_mutex_lock(mutex);
    return 0;
#else
    return pthread_mutex_lock(mutex);
#endif
}
/*
 *   对互斥量尝试加锁
 *   返回值:成功则返回0，失败则返回错误号(linux版)或-1(windows版)
 */
inline int Dbfw_TryLockMutex(pthread_mutex_t* mutex)
{
#ifdef WIN32
    if(pthread_mutex_trylock(mutex)==TRUE)/*加锁成功*/
        return 0;
    return -1;
#else
    return pthread_mutex_trylock(mutex);/*加锁失败返回EBUSY*/
#endif
}

/**
 * 对互斥量进行带有超时时间的加锁
 * 返回值:0-成功;1-加锁超时;-1-加锁失败
 * */
inline int Dbfw_TimedLockMutex(pthread_mutex_t *mutex, const struct timespec *timeout)
{
#ifdef WIN32
    if (pthread_mutex_timedlock(mutex, timeout))
        return 0;
    return -1;
#else
    int ret = 0;
    ret=pthread_mutex_timedlock(mutex, timeout);
    return ret;
#endif
}

/*
 *   对互斥量解锁
 *   返回值:成功则返回0，失败则返回错误号
 */
inline int Dbfw_UnlockMutex(pthread_mutex_t* mutex)
{
#ifdef WIN32
    pthread_mutex_unlock(mutex);
    return 0;
#else
    return pthread_mutex_unlock(mutex);
#endif
}
/*
 *   释放互斥量
 *   返回值:成功则返回0，失败则返回错误号
 */
inline int Dbfw_DestroyMutex(pthread_mutex_t* mutex)
{
#ifdef WIN32
    pthread_mutex_destroy(mutex);
    return 0;
#else
    return pthread_mutex_destroy(mutex);
#endif
}

/**********************************
 *	
 *	读写锁操作
 *
 **********************************/
#ifndef WIN32
/*
 *	初始化读写锁，具有进程间共享的属性
 *	返回值
 *		0: 成功
 *		非0:错误编号
 */
inline int Dbfw_InitRWLock(pthread_rwlock_t *rwlock)
{

    int ret;
    pthread_rwlockattr_t rwlock_attr;
    if((ret=pthread_rwlockattr_init(&rwlock_attr))!=0)
    {
        return ret;
    }
    if((ret=pthread_rwlockattr_setpshared(&rwlock_attr, PTHREAD_PROCESS_SHARED))!=0)
    {
        return ret;
    }
    if((ret=pthread_rwlockattr_setkind_np(&rwlock_attr, PTHREAD_RWLOCK_PREFER_WRITER_NONRECURSIVE_NP))!=0)
    {
        return ret;
    }
    if((ret=pthread_rwlock_init(rwlock, &rwlock_attr))!=0)
    {
        return ret;
    }
    if((ret=pthread_rwlockattr_destroy(&rwlock_attr))!=0)
    {
        return ret;
    }
    return 0;
}

/*
 *	以读模式锁住读写锁
 *	返回值
 *		0: 成功
 *		非0:错误编号
 */
inline int Dbfw_ReadLockRWLock(pthread_rwlock_t *rwlock)
{
    return pthread_rwlock_rdlock(rwlock);
}
/*
 *	以写模式锁住读写锁
 *	返回值
 *		0: 成功
 *		非0:错误编号
 */

inline int Dbfw_WriteLockRWLock(pthread_rwlock_t *rwlock)
{
    return pthread_rwlock_wrlock(rwlock);
}
/*
 *	两个尝试加锁函数
 *	返回值
 *		0: 获取锁成功
 *		EBUSY:获取锁失败
 */
inline int Dbfw_TryReadLockRWLock(pthread_rwlock_t *rwlock)
{
    return pthread_rwlock_tryrdlock(rwlock);
}
inline int Dbfw_TryWriteLockRWLock(pthread_rwlock_t *rwlock)
{
    return pthread_rwlock_trywrlock(rwlock);
}
/*********************************
 *	解开读写锁
 *	返回值
 *		0: 成功
 *		非0:错误编号
 *********************************/
inline int Dbfw_UnlockRWLock(pthread_rwlock_t *rwlock)
{
    return pthread_rwlock_unlock(rwlock);
}
/*********************************
 *	销毁读写锁
 *	返回值
 *		0: 成功
 *		非0:错误编号
 *********************************/
inline int Dbfw_DestroyRWLock(pthread_rwlock_t *rwlock)
{
    return pthread_rwlock_destroy(rwlock);
}

#endif

#ifdef WIN32
/**********************************
 *
 *	线程操作
 *
 ***********************************/

/*
 *	创建线程
 *	func:线程函数
 *	args:线程函数的参数
 *	thread_id:创建线程后，用来保存线程id的内存地址
 *	返回值:成功则返回线程句柄；失败则返回NULL
 */
typedef unsigned int (__stdcall *start_func)(void*);
inline pthread_handle Dbfw_CreateThread(start_func func, void *args ,pthread_t *thread_id)
{
    return (pthread_handle)_beginthreadex(NULL, 0 , func, args, 0, thread_id);
}

/*
 *	等待线程结束
 *	pth:线程句柄
 *	返回值:如果被等待的线程正常结束，则返回0；否则返回-1。
 */
inline int Dbfw_WaitThread(pthread_handle pth)
{
    if(WaitForSingleObject(pth, INFINITE)==WAIT_OBJECT_0)
        return 0;
    return -1;
}

/*
 *	终止其他线程的运行
 *	pth:被终止的线程的句柄
 *	返回值:成功则返回0，失败则返回-1
 */
inline int Dbfw_TerminateThread(pthread_handle pth)
{
    if(TerminateThread(pth, 0)==TRUE)
        return 0;
    return -1;
}
/*
 *	调用该函数的线程会退出。
 *	ret_code:退出码
 */
inline void Dbfw_ExitThread(unsigned int ret_code)
{
    _endthreadex(ret_code);
}


/*
 *	关闭线程内核对象
 *	pth:线程句柄
 */

inline void Dbfw_CloseThreadHandle(pthread_handle pth)
{
    CloseHandle(pth);
}
#endif

#ifndef WIN32
/***********************************
 *
 *	创建进程操作
 *
 ************************************/

/*
 *   忽略子进程退出的信号SIGCHLD。这样子进程退出时就不会产生僵尸进程。
 *   在调用Dbfw_CreateProcess()之前，应该先调用该函数。
 *   返回值:成功则返回0，失败则返回-1。
 */

inline int Dbfw_IgnoreChildProcessExit(void)
{
    if(signal(SIGCHLD, SIG_IGN)==SIG_ERR)
    {
        return -1;	
    }
    return 0;
}
/*
// *  创建进程
// *  process_name:用来创建进程的可执行文件名
// *  argv:进程接收的的参数列表。
// *       注意:必须是指针数组，不能是二维字符数组，而且最后一个指针必须是0。
// *  返回值:成功则返回子进程的pid，失败则返回-1，错误编号在errno中。
// */
//inline int Dbfw_CreateProcess(char* process_name, char* argv[])
//{
//    pid_t pid;
//    if((pid=fork())==0)
//    {
//        if(execv(process_name, argv)==-1)
//        {
//            exit(0);
//            //            return -1;	
//        }
//    }

//    return pid;//-1或子进程的pid
//}


/*
 *  获取进程路径
 */
inline int Dbfw_GetProcessPath(char *process_path)
{	
	char *dbfw_home = getenv("DBFW_HOME");
	
	if(dbfw_home==NULL)
	{
		strcpy(process_path, "/home/dbfw/dbfw");
	}else{
		strcpy(process_path, dbfw_home);
	}

	strcat(process_path,"/bin/");
	
	return 0;
}

/*
 *  构建进程名,dbfw_INST_npp_ora_xxxxxx
 */
inline void Dbfw_ConstructProcessName(char* buf, char* instance_name, char* process_name)
{
	int len;
	time_t cur_time = time(NULL);
	
	strcpy((char*)buf, "dbfw_");
	strcat((char*)buf, (char*)instance_name);
	strcat((char*)buf, "_");
	strcat((char*)buf, (char*)process_name);
	strcat((char*)buf, "_");

	len = strlen((char*)buf);
	strftime((char*)buf+len, 32, "%Y%m%d%H%M%S", localtime(&cur_time));
	len += 14;
	buf[len]='0';
	buf[len+1]='0';
	buf[len+2]='0';
	buf[len+3]='\0';
}


/*
 *  创建进程
 *  process_name:用来创建进程的可执行文件名
 *  argv:进程接收的的参数列表。
 *       注意:必须是指针数组，不能是二维字符数组，而且最后一个指针必须是0。
 *	use_vfork:如果不为0，则使用vfork创建，否则使用fork创建，默认为0
 *	id:绑定cpu，如果为9999，则不绑定
 *  返回值:成功则返回子进程的pid，失败则返回-1，错误编号在errno中。
 */
inline int Dbfw_CreateProcess(char* process_name, char* argv[] ,int use_vfork=0,int id=9999, int close_handle=0)
{
    pid_t pid=-1;
	if(access((char*)process_name, F_OK)!=0)//判断文件是否存在
	{
		return -2;
	}
	
	if(use_vfork)
	{
		if((pid=vfork())==0)
		{
			if(close_handle == 0)
			{
				for(int i=3;i<=65535;i++)
			        close(i);
		  }else{
		  	if(close_handle > 0)
		  		close(close_handle);	
		  }
			if(id != 9999)
			{
			    seteuid(getuid());
			    cpu_set_t mask;
			    CPU_ZERO(&mask);
			    CPU_SET(id, &mask);
			    sched_setaffinity(0, sizeof(mask), &mask);
			}
			if(execv(process_name, argv)==-1)
			{
				exit(0);
			}
		}
	}
	else
	{
		if((pid=fork())==0)
		{
			if(close_handle==0)
			{
				for(int i=3;i<=65535;i++)
			        close(i);
		  }else{
		  	if(close_handle > 0)
		  		close(close_handle);	
		  }
			if(id != 9999)
			{
			    seteuid(getuid());
			    cpu_set_t mask;
			    CPU_ZERO(&mask);
			    CPU_SET(id, &mask);
			    sched_setaffinity(0, sizeof(mask), &mask);
			}
			if(execv(process_name, argv)==-1)
			{
				exit(0);
			}
		}
	}
	return pid;
}

/*
 *   注册进程退出时的信号处理函数
 *   返回值：成功则返回0，失败则返回-1
 */
typedef void (*sighandler_t)(int);
inline int Dbfw_RegisterProcessExitFunction(sighandler_t handler)
{
    if(signal(SIGUSR1, handler)==SIG_ERR  ||/*被另一个进程终止*/
            signal(SIGTERM, handler)==SIG_ERR ||/*kill命令发送的默认信号*/
            signal(SIGINT, handler)==SIG_ERR  ||/*Ctrl+C*/
            signal(SIGTSTP, handler)==SIG_ERR ||/*Ctrl+Z*/
            signal(SIGHUP, handler)==SIG_ERR )  /*连接断开*/
    {
        return -1;	
    }
    return 0;
}

/*
 *   关闭进程相关函数
 *   终止进程。
 *   返回值:成功则返回0，失败则返回-1
 */
inline int Dbfw_TerminateProcess(pid_t pid)
{
    return kill(pid, SIGUSR1);
}

/*
 *   检查指定的进程ID的进程是否存在
 *   返回值:存在则返回0，不存在则返回-1
 */
inline int Dbfw_CheckProcessExists(pid_t pid)
{
    return kill(pid, 0);
}
/*
 *   注册进程异常退出时的信号处理函数
 *   返回值:成功则返回0，失败则返回-1
 *
 */
inline int Dbfw_RegisterProcessCrashFunction(sighandler_t handler)
{
    struct sigaction act;  
    sigemptyset(&act.sa_mask);       
    act.sa_handler=handler;  
    if(sigaction(SIGSEGV,&act,NULL)==-1||/* 内存访问错误*/
            sigaction(SIGBUS,&act,NULL)==-1 ||/* 使用存储映射函数发生错误*/
            sigaction(SIGFPE,&act,NULL)==-1 ||/* 除0错误*/
            sigaction(SIGABRT,&act,NULL)==-1||/* 异常终止*/
            sigaction(SIGILL,&act,NULL)==-1 ||/* 非法硬件指令*/
            sigaction(SIGIOT,&act,NULL)==-1 ||/* 硬件故障*/
            sigaction(SIGQUIT,&act,NULL)==-1||/* ctrl+\*/
            sigaction(SIGSYS,&act,NULL)==-1 ||/* 无效系统调用*/
            sigaction(SIGTRAP,&act,NULL)==-1  /* 硬件故障*/
#if (defined HAVE_CHERRY) && (defined USE_SINGLE_DIRECTIRON_PACKAGE_PROCESS)
			|| sigaction(SIGRTMAX-4,&act,NULL)==-1  /* npp收到此信号后异常退出，不生成coredump文件 */
#endif
						|| sigaction(SIGRTMAX-9,&act,NULL)==-1 /* npp 收到此信号后异常退出，并生产coredump文件 */
			) 
    {
        return -1;
    }

    return 0;
}
/*
 *	 注册带有coredump信息的信号处理函数
 */
typedef void (*sigaction_t)(int, siginfo_t*, void*);
inline int Dbfw_RegisterProcessCrashFunctionWithCoredump(sigaction_t handler)
{
    char *dbfw_has_core = getenv("DBFW_HAS_CORE");
    if (dbfw_has_core != NULL && dbfw_has_core[0] == '1')
    {
        struct rlimit core_limit;
        core_limit.rlim_cur = core_limit.rlim_max = RLIM_INFINITY;
        setrlimit(RLIMIT_CORE, &core_limit); 
    }
    else
    {
        struct sigaction act;  
        sigemptyset(&act.sa_mask);    
        act.sa_flags=SA_SIGINFO;      
        act.sa_sigaction=handler;  
        if(sigaction(SIGSEGV,&act,NULL)==-1||/* 内存访问错误*/
                sigaction(SIGBUS,&act,NULL)==-1 ||/* 使用存储映射函数发生错误*/
                sigaction(SIGFPE,&act,NULL)==-1 ||/* 除0错误*/
                sigaction(SIGABRT,&act,NULL)==-1||/* 异常终止*/
                sigaction(SIGILL,&act,NULL)==-1 ||/* 非法硬件指令*/
                sigaction(SIGIOT,&act,NULL)==-1 ||/* 硬件故障*/
                sigaction(SIGQUIT,&act,NULL)==-1||/* ctrl+\*/
                sigaction(SIGSYS,&act,NULL)==-1 ||/* 无效系统调用*/
                sigaction(SIGTRAP,&act,NULL)==-1  /* 硬件故障*/
#if (defined HAVE_CHERRY) && (defined USE_SINGLE_DIRECTIRON_PACKAGE_PROCESS)
				|| sigaction(SIGRTMAX-4,&act,NULL)==-1  /* npp收到此信号后异常退出，不生成coredump文件 */
#endif
								|| sigaction(SIGRTMAX-9,&act,NULL)==-1 /* npp 收到此信号后异常退出，并生产coredump文件 */
				) 
        {
            return -1;
        }
    }

    return 0;
}

/************************************************
 *       以下封装coredump接口
 *       为了在打印函数栈时能够得到函数名，链接程序时
 *       要加上-rdynamic选项
 *************************************************/

/*************************************************
 *       获取寄存器
 *       参数:
 *               context:线程上下文，是输入变量。
 *               regs:保存寄存器的值，是输出变量。
 *************************************************/
inline void Dbfw_GetRegisters(void *context, u_int64 regs[])
{
    ucontext_t *uc = (ucontext_t*)context;
    regs[0] = uc->uc_mcontext.gregs[REG_RIP];
    regs[1] = uc->uc_mcontext.gregs[REG_RSP];
    regs[2] = uc->uc_mcontext.gregs[REG_RBP];
    regs[3] = uc->uc_mcontext.gregs[REG_RDI];
    regs[4] = uc->uc_mcontext.gregs[REG_RSI];
    regs[5] = uc->uc_mcontext.gregs[REG_RAX];
    regs[6] = uc->uc_mcontext.gregs[REG_RBX];
    regs[7] = uc->uc_mcontext.gregs[REG_RCX];
    regs[8] = uc->uc_mcontext.gregs[REG_RDX];
    regs[9] = uc->uc_mcontext.gregs[REG_CSGSFS]&0xff;
    regs[10] = (uc->uc_mcontext.gregs[REG_CSGSFS]>>16)&0xff;
    regs[11] = (uc->uc_mcontext.gregs[REG_CSGSFS]>>32)&0xff;
    regs[12] = uc->uc_mcontext.gregs[REG_EFL];
}
/************************************************
 *       获得信号屏蔽字
 *       返回值:
 *               信号屏蔽字,通过使用sigismember()
 *               判断哪些信号被阻塞了
 ************************************************/
inline sigset_t Dbfw_GetSigmask(void *context)
{
    return ((ucontext_t*)context)->uc_sigmask;

}

/************************************************
 *       获得函数调用栈
 *       参数:
 *               num:函数栈的数量保存在num所指向的整数里
 *       返回值:
 *               函数栈的字符串数组，每个字符串以'\0'结尾
 *               该数组是由库函数malloc出来的，所以要手动free
 ************************************************/
#define DBFW_IPC_BT_NUM 128     /*函数栈的最大数量*/
inline u_char** Dbfw_Backtrace(int *num)
{
    int n;
    void *buffer[DBFW_IPC_BT_NUM];
    n = backtrace(buffer, DBFW_IPC_BT_NUM); 
    *num = n;
    return (u_char**)backtrace_symbols(buffer, n);  
}

/************************************************
 *       获得函数调用栈
 *       参数:
 *               num:函数栈的数量保存在num所指向的整数里
 *               fd:函数栈的信息写入的文件句柄
 *       返回值:
 *               函数栈的字符串数组，每个字符串以'\0'结尾
 *               该数组是由库函数不会malloc
 ************************************************/
inline void Dbfw_Backtrace_Fd(int *num, int fd)
{
    int n;
    void *buffer[DBFW_IPC_BT_NUM];
    n = backtrace(buffer, DBFW_IPC_BT_NUM); 
    *num = n;
    backtrace_symbols_fd(buffer, n, fd);  
    return ;
}

/************************************************
 *       获得栈指针所指向的内存块
 *       参数:
 *               context:线程上下文，是输入变量
 *               raw_stack:保存内存块的内容，是输出变量。大小为1280个字节
 *       返回值:
 *               栈指针的值
 ************************************************/
#define DBFW_IPC_RAW_STACK_SIZE         1280
inline u_char* Dbfw_GetRawStack(void *context, u_char raw_stack[])
{
    u_char *sp=(u_char*)((ucontext_t*)context)->uc_mcontext.gregs[REG_RSP];
    memcpy(raw_stack, sp, DBFW_IPC_RAW_STACK_SIZE);
    return sp;
}



/*************************************
 *
 *	原子操作
 *
 **************************************/
/*
 *   将var所指变量加上val。
 *   返回变化之前的整数值。
 */
inline u_short Dbfw_FetchAndAdd(u_short *var, u_short val)
{
    return __sync_fetch_and_add(var, val);
}
inline int Dbfw_FetchAndAdd(int *var, int val)
{
    return __sync_fetch_and_add(var, val);
}
inline u_int Dbfw_FetchAndAdd(u_int *var, u_int val)
{
    return __sync_fetch_and_add(var, val);
}
inline u_int64 Dbfw_FetchAndAdd(u_int64 *var, u_int64 val)
{
    return __sync_fetch_and_add(var, val);
}
/*
 *   将var所指变量减去val。
 *   返回变化之前的整数值。
 */
inline u_short Dbfw_FetchAndSub(u_short *var, u_short val)
{
    return __sync_fetch_and_sub(var, val);
}
inline int Dbfw_FetchAndSub(int *var, int val)
{
    return __sync_fetch_and_sub(var, val);
}
inline u_int Dbfw_FetchAndSub(u_int *var, u_int val)
{
    return __sync_fetch_and_sub(var, val);
}
inline u_int64 Dbfw_FetchAndSub(u_int64 *var, u_int64 val)
{
    return __sync_fetch_and_sub(var, val);
}

/*
 *   将var所指变量与val进行或运算。
 *   返回变化之前的整数值。
 */
inline u_short Dbfw_FetchAndOr(u_short *var, u_short val)
{
    return __sync_fetch_and_or(var, val);
}
inline int Dbfw_FetchAndOr(int *var, int val)
{
    return __sync_fetch_and_or(var, val);
}
inline u_int Dbfw_FetchAndOr(u_int *var, u_int val)
{
    return __sync_fetch_and_or(var, val);
}
inline u_int64 Dbfw_FetchAndOr(u_int64 *var, u_int64 val)
{
    return __sync_fetch_and_or(var, val);
}

/*
 *   将var所指变量与val进行异或运算。
 *   返回变化之前的整数值。
 */
inline u_short Dbfw_FetchAndXor(u_short *var, u_short val)
{
    return __sync_fetch_and_xor(var, val);
}
inline int Dbfw_FetchAndXor(int *var, int val)
{
    return __sync_fetch_and_xor(var, val);
}
inline u_int Dbfw_FetchAndXor(u_int *var, u_int val)
{
    return __sync_fetch_and_xor(var, val);
}
inline u_int64 Dbfw_FetchAndXor(u_int64 *var, u_int64 val)
{
    return __sync_fetch_and_xor(var, val);
}

/*
 *   将var所指变量与val进行运算：~(*var)&val
 *   返回变化之前的整数值。
 */
inline u_short Dbfw_FetchAndNand(u_short *var, u_short val)
{
    return __sync_fetch_and_nand(var, val);
}
inline int Dbfw_FetchAndNand(int *var, int val)
{
    return __sync_fetch_and_nand(var, val);
}
inline u_int Dbfw_FetchAndNand(u_int *var, u_int val)
{
    return __sync_fetch_and_nand(var, val);
}
inline u_int64 Dbfw_FetchAndNand(u_int64 *var, u_int64 val)
{
    return __sync_fetch_and_nand(var, val);
}

/*
 *   将var所指变量加上val。
 *   返回变化之后的整数值。
 */
 inline u_char Dbfw_AddAndFetch(u_char *var, u_char val)
{
    return __sync_add_and_fetch(var, val);
}
inline u_short Dbfw_AddAndFetch(u_short *var, u_short val)
{
    return __sync_add_and_fetch(var, val);
}
inline int Dbfw_AddAndFetch(int *var, int val)
{
    return __sync_add_and_fetch(var, val);
}
inline u_int Dbfw_AddAndFetch(u_int *var, u_int val)
{
    return __sync_add_and_fetch(var, val);
}
inline u_int64 Dbfw_AddAndFetch(u_int64 *var, u_int64 val)
{
    return __sync_add_and_fetch(var, val);
}

/*
 *   将var所指变量减去val。
 *   返回变化之后的整数值。
 */
inline u_char Dbfw_SubAndFetch(u_char *var, u_char val)
{
    return __sync_sub_and_fetch(var, val);
}

inline u_short Dbfw_SubAndFetch(u_short *var, u_short val)
{
    return __sync_sub_and_fetch(var, val);
}
inline int Dbfw_SubAndFetch(int *var, int val)
{
    return __sync_sub_and_fetch(var, val);
}
inline u_int Dbfw_SubAndFetch(u_int *var, u_int val)
{
    return __sync_sub_and_fetch(var, val);
}
inline u_int64 Dbfw_SubAndFetch(u_int64 *var, u_int64 val)
{
    return __sync_sub_and_fetch(var, val);
}

/*
 *   将var所指变量与val进行或运算。
 *   返回变化之后的整数值。
 */
inline u_short Dbfw_OrAndFetch(u_short *var, u_short val)
{
    return __sync_or_and_fetch(var, val);
}
inline int Dbfw_OrAndFetch(int *var, int val)
{
    return __sync_or_and_fetch(var, val);
}
inline u_int Dbfw_OrAndFetch(u_int *var, u_int val)
{
    return __sync_or_and_fetch(var, val);
}
inline u_int64 Dbfw_OrAndFetch(u_int64 *var, u_int64 val)
{
    return __sync_or_and_fetch(var, val);
}

/*
 *   将var所指变量与val进行异或运算。
 *   返回变化之后的整数值。
 */
inline u_short Dbfw_XorAndFetch(u_short *var, u_short val)
{
    return __sync_xor_and_fetch(var, val);
}
inline int Dbfw_XorAndFetch(int *var, int val)
{
    return __sync_xor_and_fetch(var, val);
}
inline u_int Dbfw_XorAndFetch(u_int *var, u_int val)
{
    return __sync_xor_and_fetch(var, val);
}
inline u_int64 Dbfw_XorAndFetch(u_int64 *var, u_int64 val)
{
    return __sync_xor_and_fetch(var, val);
}
/*
 *   将var所指变量与val进行运算：~(*var)&val
 *   返回变化之后的整数值。
 */
inline u_short Dbfw_NandAndFetch(u_short *var, u_short val)
{
    return __sync_nand_and_fetch(var, val);
}
inline int Dbfw_NandAndFetch(int *var, int val)
{
    return __sync_nand_and_fetch(var, val);
}
inline u_int Dbfw_NandAndFetch(u_int *var, u_int val)
{
    return __sync_nand_and_fetch(var, val);
}
inline u_int64 Dbfw_NandAndFetch(u_int64 *var, u_int64 val)
{
    return __sync_nand_and_fetch(var, val);
}

/*
 *   如果var所指变量等于old_val,就把new_val赋值给该变量;否则,*var仍为原值
 *   返回值：如果*var等于old_val,返回1;否则返回0。
 */
inline u_short Dbfw_BoolCompareAndSwap(u_short *var, u_short old_val, u_short new_val)
{
    return __sync_bool_compare_and_swap(var, old_val, new_val);
}
inline int Dbfw_BoolCompareAndSwap(int *var, int old_val, int new_val)
{
    return __sync_bool_compare_and_swap(var, old_val, new_val);
}
inline u_int Dbfw_BoolCompareAndSwap(u_int *var, u_int old_val, u_int new_val)
{
    return __sync_bool_compare_and_swap(var, old_val, new_val);
}
inline u_int64 Dbfw_BoolCompareAndSwap(u_int64 *var, u_int64 old_val, u_int64 new_val)
{
    return __sync_bool_compare_and_swap(var, old_val, new_val);
}

/*
 *   如果var所指变量等于old_val,就把new_val赋值给该变量;否则,*var仍为原值
 *   返回值：*var的原值。
 */
inline u_short Dbfw_ValCompareAndSwap(u_short *var, u_short old_val, u_short new_val)
{
    return __sync_val_compare_and_swap(var, old_val, new_val);
}
inline int Dbfw_ValCompareAndSwap(int *var, int old_val, int new_val)
{
    return __sync_val_compare_and_swap(var, old_val, new_val);
}
inline u_int Dbfw_ValCompareAndSwap(u_int *var, u_int old_val, u_int new_val)
{
    return __sync_val_compare_and_swap(var, old_val, new_val);
}
inline u_int64 Dbfw_ValCompareAndSwap(u_int64 *var, u_int64 old_val, u_int64 new_val)
{
    return __sync_val_compare_and_swap(var, old_val, new_val);
}

/*
 *   将var所指变量的值设为val
 *   返回变量的原始值。
 */
inline u_short Dbfw_LockTestAndSet(u_short *var, u_short val)
{
    return __sync_lock_test_and_set(var, val);	
}
inline int Dbfw_LockTestAndSet(int *var, int val)
{
    return __sync_lock_test_and_set(var, val);	
}
inline u_int Dbfw_LockTestAndSet(u_int *var, u_int val)
{
    return __sync_lock_test_and_set(var, val);	
}
inline u_int64 Dbfw_LockTestAndSet(u_int64 *var, u_int64 val)
{
    return __sync_lock_test_and_set(var, val);	
}
/*
 *   将var所指变量置为0
 */
inline void Dbfw_LockRelease(int *var)
{
    __sync_lock_release(var);	
}
#endif




#endif
