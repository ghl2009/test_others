
#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include <sys/dir.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <string.h>
#include <unistd.h>

#include "config.h"
#include "librslist.h"

#define k64test 1

#if defined(k64test)
#define KLONG long long    // not typedef; want "unsigned KLONG" to work
#define KLF "L"
#define STRTOUKL strtoull
#else
#define KLONG long
#define KLF "l"
#define STRTOUKL strtoul
#endif

struct dbfwpmap_s{
	int pid;
	unsigned long total_shared;
	unsigned long total_private_writeable; 
	unsigned long total_private_readonly;
};

static int l_option = 0; //list pid
static int s_option = 0; //sort pid
static int t_option = 0;
static int t_count = 0;

static Rslist_t *_pid_rslist = NULL;

void display_version()
{
	printf("\nVersion:%s Build %s %s\n",
		VERSION,BUILD_DATE_PREDEF,BUILD_SVN_PREDEF);
}

void usage(char *progname)
{
	display_version();
	printf("usage: %s [-p pname] [-u uid] [-l] [-s] [-r] [-t top_num] [-V]\n",progname);	
}

int readpmap(struct direct *ent,int uid,char *pname,struct dbfwpmap_s *dbfwpmap)
{
	int pid = 0;
	char fname[128],exe_file[512],*pexename = NULL;
	struct stat stat_buf;
	FILE *fp;
	char mapbuf[9600];
    char flags[32];
    unsigned KLONG start, end;
	unsigned KLONG diff = 0;
    unsigned long long file_offset, inode;
    unsigned dev_major, dev_minor;

	pid = atoi(ent->d_name);
	if(pid == 0){
		return -1;
	}
	
	if(uid >=0){
		memset(fname,0,sizeof(fname));
		sprintf(fname,"/proc/%d",pid);
		if(stat((char*)fname, &stat_buf ) < 0){
			return -2;
		}
		if(stat_buf.st_uid != uid){
			return -3;
		}
	}

	memset(fname,0,sizeof(fname));
	sprintf(fname,"/proc/%d/exe",pid);
	memset(exe_file,0,sizeof(exe_file));
	if(readlink(fname, exe_file,sizeof(exe_file)) < 0){
		return -11;
	}
	pexename = strrchr(exe_file,'/');
	pexename++;
	if(strncmp(pexename,pname,strlen(pname)) != 0){
		return -12;
	}

	memset(dbfwpmap,0,sizeof(struct dbfwpmap_s));
	dbfwpmap->pid = pid;
	
	memset(fname,0,sizeof(fname));
	sprintf(fname,"/proc/%d/maps",pid);
	if( (fp = fopen(fname, "r")) == NULL)
		return -21;

	while(fgets(mapbuf,sizeof(mapbuf),fp)){
		if (mapbuf[0] >= 'A' && mapbuf[0] <= 'Z') {
			continue;
		}
		sscanf(mapbuf,"%"KLF"x-%"KLF"x %31s %Lx %x:%x %Lu",
			&start, &end, flags, &file_offset, &dev_major, &dev_minor, &inode);
		diff = end-start;

		if(flags[3]=='s') 
			dbfwpmap->total_shared += diff;
		if(flags[3]=='p'){
			if(flags[1]=='w') 
				dbfwpmap->total_private_writeable += diff;
			else
				dbfwpmap->total_private_readonly  += diff;
		}
//		printf("%s",mapbuf);
//		printf("   %llx %llx %s\n",start,end,flags);
	}

	fclose(fp);

	if(l_option){
		printf("pid: %-5d   mapped: %ldK   writeable/private: %ldK   shared: %ldK   exe: %s\n",pid,
			(dbfwpmap->total_shared + dbfwpmap->total_private_writeable + dbfwpmap->total_private_readonly) >> 10,
			(dbfwpmap->total_private_writeable) >> 10,
			(dbfwpmap->total_shared) >> 10,
			exe_file);
	}

	return 0;
}

static int pmap_enum_cb(FILE* fp,unsigned long long key,void *data)
{
	struct dbfwpmap_s *dbfwpmap = (struct dbfwpmap_s*)data;
	char fname[128],exe_file[512],*pexename = NULL;

	if(t_option == 0 || (t_option > 0 && t_count++ < t_option))
	{
		memset(fname,0,sizeof(fname));
		sprintf(fname,"/proc/%d/exe",dbfwpmap->pid);
		memset(exe_file,0,sizeof(exe_file));
		readlink(fname, exe_file,sizeof(exe_file));

		printf("pid: %-5d   mapped: %ldK   writeable/private: %ldK   shared: %ldK   exe: %s\n",
			dbfwpmap->pid,
			(dbfwpmap->total_shared + dbfwpmap->total_private_writeable + dbfwpmap->total_private_readonly) >> 10,
			(dbfwpmap->total_private_writeable) >> 10,
			(dbfwpmap->total_shared) >> 10,
			exe_file);
	}
}

int main(int argc, char *argv[])
{
	char errbuf[512];
	Rslist_Config config;
	uint8_t *start_addr = NULL;
	uint64_t base = 0,key = 0;
	
	int i=0,count = 0;
	dbfwpmap_s dbfwpmap_one,dbfwpmap_total;
	int uid = -1;
	char pname[512];
	DIR* procfs = NULL;
	struct direct *ent = NULL;
	
	memset(pname,0,sizeof(pname));
	
	if(argc == 1){
		usage(argv[0]);
		return 1;
	}
	
	while( (i = getopt(argc, argv, "u:p:t:lsrV") ) != -1 )
		switch (i) {
		case 'u': uid = strtoul(optarg, NULL, 10); break;
		case 'p': memcpy(pname,optarg,sizeof(pname)-1);break;
		case 'l': l_option = 1;break;
		case 's': s_option = 1;break;
		case 'r': s_option = 2;break;
		case 't': t_option = atoi(optarg); break;
		case 'V': display_version(); exit(0);
        default: usage(argv[0]);
	    return 1;
    }
//	printf("uid:%d pname:%s\n",uid,pname);

	memset(&config,0,sizeof(Rslist_Config));
	config.total_kbsize = 2048;
	config.max_slot = 1;
//	config.verbose = 1;
	config.user_data_size = sizeof(struct dbfwpmap_s);
	start_addr = (uint8_t*)malloc(config.total_kbsize*1024);

	memset(errbuf,0,sizeof(errbuf));
	_pid_rslist = Rslist_Init(start_addr,&config,errbuf);

	procfs = opendir("/proc");
	if(procfs == NULL){
		fprintf(stderr,"open dir /proc failed\n");
		return 1;
	}
	
	base = -1;
	memset(&dbfwpmap_total,0,sizeof(dbfwpmap_s));
	for (;;) {
		ent = readdir(procfs);
		if(ent == NULL)
			break;
		if(*ent->d_name < '0' || *ent->d_name > '9')
			continue;
		if(readpmap(ent,uid,pname,&dbfwpmap_one) == 0){
			dbfwpmap_total.total_private_writeable += dbfwpmap_one.total_private_writeable;
			count++;
			key = dbfwpmap_one.total_private_writeable << 20;
			key += dbfwpmap_one.pid;
			//反序输出
			if(s_option == 2){
				key = base - key;
			}
			if(s_option){
				Rslist_Insert(_pid_rslist,key,&dbfwpmap_one);
			}
		}
	}
	closedir(procfs);

	if(s_option){
		Rslist_Enum(_pid_rslist,NULL,pmap_enum_cb);
	}
	Rslist_Destroy(_pid_rslist);

	printf("total count: %-5d  writeable/private: %luK %luM\n",count,
			dbfwpmap_total.total_private_writeable >> 10,
			dbfwpmap_total.total_private_writeable >> 20);
	return 0;
}
