
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <string.h>
#include <ctype.h>

#ifndef WIN32
#include <unistd.h>
#include <sys/stat.h>
#else
#include "getopt.h"
#endif

#define VERI_FILE (char*)"/tmp/vcode.conf"

static int _verifi_action = 0;
static int _verifi_debug = 0;
static char _verifi_seed[10];
static char _verifi_password[32];
static int _def_password[] = {'z','h','i','m','a','g','u','a','n','m','e','n','0','3','0','2','o','k'};

static void usage(char *argv[])
{
	printf( "Usage: %s [-p seed] [-c password] [-h]\n", argv[0]);
	printf("\t-p    create password from seed.\n");
	printf("\t-c    check passowrd.\n");
	printf("\t-h    print this usage.\n");
	exit(2);
}

static char get_code(int num,int hex)
{
	int n = 0;
	if(hex == 36)
	{
		n = num%hex;
		if(n >= 0 && n <= 9)
		{
			return '0' + n;
		}
		else
		{
			n -= 10;
			return 'A' + n;
		}
	}
	else if(hex == 10)
	{
		n = num%hex;
		return '0' + n;
	}
	else if(hex == 26)
	{
		n = num%hex;
		return 'A' + n;
	}
	else
		return num%127;
}

static unsigned long long int dbsc_hashfunc_big(unsigned char* text,unsigned int text_len)
{
    unsigned int seed = 131; /* 31 131 1313 13131 131313 etc.. */
    unsigned int hash_bkdr = 0;
    unsigned int b    = 378551;
    unsigned int a    = 63689;
    unsigned int hash_rs = 0;
    unsigned int i    = 0;
	unsigned long long int hash = 0,hash1 = 0,hash2 = 0;
	
	if(text_len == 0)
	{
		while(*text != '\0')
		{
			hash_bkdr = (hash_bkdr * seed) + (*text);
			hash_rs = hash_rs * a + (*text);
			a    = a * b;			
			 text++;
		}
	}
	else
	{
		for(i = 0; i < text_len; text++, i++)
		{
			hash_bkdr = (hash_bkdr * seed) + (*text);
			hash_rs = hash_rs * a + (*text);
			a    = a * b;
		}
	}
    hash1 = hash_bkdr;
    hash2 = hash_rs;
	hash = (hash1<<32) + hash2;
    return (hash);
}

static int create_seed()
{
	int i = 0;
	int rd = 0;
	char buffer[10];

	#ifndef WIN32
	FILE *fp_file = NULL;
	#endif

	srand((int)time(0));
	
	memset(buffer,0,sizeof(buffer));
	for(i=0;i<4;i++)
	{
		buffer[i] = get_code(rand(),36);
	}
	
	#ifndef WIN32
	fp_file = fopen(VERI_FILE,"wb");
	if(NULL == fp_file)
		return -1;
    fwrite(buffer,sizeof(char),strlen(buffer),fp_file);
	fflush(fp_file);
	fclose(fp_file);
	chmod(VERI_FILE,S_IRUSR|S_IWUSR|S_IRGRP|S_IWGRP|S_IROTH|S_IWOTH);	
	#endif
	printf("%s",buffer);
	return 0;
}

static int create_password(char *output)
{
	char buffer[64];
	char passwd[16];
	unsigned long long int key = 0;
	int ii = 0,num = 0;

	memset(buffer,0,sizeof(buffer));
	memset(passwd,0,sizeof(passwd));

	if(strlen(_verifi_seed) == 0)
		return 1;

	sprintf(buffer,"DBSCLOUD-%s-%s",_verifi_seed,_verifi_seed);
	num = strlen(buffer);
	for(ii = 0;ii<num;ii++)
	{
		buffer[ii] = toupper(buffer[ii]);
	}
	
	key = dbsc_hashfunc_big((unsigned char*)buffer,0);

	if(_verifi_debug)
		printf("value: %s key: %llu\n",_verifi_seed,key);

	for(ii = 0;ii < 6; ii++)
	{
		num = key%100;
		key /= 100;
		passwd[ii] = get_code(num,36);
	}

	if(output)
	{
		strcpy(output,passwd);
	}	
	return 0;
}

static int check_password()
{
	int ret = 0;
	#ifndef WIN32
	FILE *fp_file = NULL;
	#endif
	char passwd[16],defpwd[32];
	int ii = 0;

	if(strlen(_verifi_password) == 0)
		return 1;

	memset(_verifi_seed,0,sizeof(_verifi_seed));

	#ifndef WIN32
	fp_file = fopen(VERI_FILE,"rb");
	if(NULL == fp_file)
	{
		return 2;
	}
	fread(_verifi_seed,sizeof(char),sizeof(_verifi_seed)-1,fp_file);
	fclose(fp_file);
	remove(VERI_FILE);
	#endif

	memset(defpwd,0,sizeof(defpwd));
	for(ii = 0;ii< (sizeof(_def_password)/sizeof(int));ii++)
	{
		defpwd[ii] = (char)_def_password[ii];
	}
#ifdef WIN32
	if(stricmp(_verifi_password,defpwd) == 0)
		return 0;
#else
	if(strcasecmp(_verifi_password,defpwd) == 0)
		return 0;
#endif
	memset(passwd,0,sizeof(passwd));
	ret = create_password(passwd);
	if(ret > 0)
		return 3;

#ifdef WIN32
	if(stricmp(_verifi_password,passwd) != 0)
		return 4;
#else
	if(strcasecmp(_verifi_password,passwd) != 0)
		return 4;
#endif
	return 0;
}


int main(int argc,char *argv[])
{
	int opt = 0;
	int ret = 9;

	while((opt=getopt(argc, argv, "c:p:h"))!=-1)
	{
		switch(opt)
		{
		case 'c':
			_verifi_action = 1;
			strncpy(_verifi_password,optarg,sizeof(_verifi_password)-1);
			break;
		case 'p':
			_verifi_action = 2;
			_verifi_debug = 1;
			strncpy(_verifi_seed,optarg,sizeof(_verifi_seed)-1);
			break;
		case 'h':
			usage(argv);
			return 1;
		default:
			usage(argv);
			return 1;
		}
	}

	if(0 == _verifi_action)
	{
		create_seed();
	}
	else if(1 == _verifi_action)
	{
		ret = check_password();
	}
	else
	{
		char passwd[16];
		memset(passwd,0,sizeof(passwd));
		create_password(passwd);
		printf("password: %s\n",passwd);
	}
	return ret;
}

