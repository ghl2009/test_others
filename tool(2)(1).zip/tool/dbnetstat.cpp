#ifdef _MSC_VER
/*
 * we do not want the warnings about the old deprecated and unsecure CRT functions
 * since these examples can be compiled under *nix as well
 */
#define _CRT_SECURE_NO_WARNINGS
#endif

#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <errno.h>
#include <time.h>
#include <pcap.h>
#ifdef WIN32
	#include <windows.h>
#else
    #include <signal.h>
	#include <sys/socket.h>
	#include <netinet/in.h>
#endif

#include "config.h"
#include "librslist.h"

#include "dbnetstat.h"
#include "meter_utils.h"
#include "protocol_analysis.h"

#ifdef __cplusplus
extern "C" {
#endif

typedef struct
{
    unsigned int port;
    const char *serv_name;
    unsigned int count;
} serv_port_stat;

struct stat_cb_param_s
{
    int count;
};

//全局变量
static DBNetstat_Global _Global;

//打包规则
static DBNetstat_Rule _Rule;

static dspr_hash_t *_Sess_Hash = NULL;
static Rslist_t *_Server_Rslist = NULL;
static Rslist_t *_ServerIp_Rslist = NULL;

//广播统计
static DBNetstat_Stat _Stat;

static int _server_count = 1;

static serv_port_stat stat_port_table[] =
{
    {1521, "Oracle", 0},
    {1433, "SQL Server", 0},
    {3306, "MySQL", 0},
    {9092, "PointBase", 0},
    {5000, "DB2", 0},
    {5432, "PostgreSQL", 0},
    {0, "Unknown", 0} /* Keep this as the last */
};

//局部函数
static int dbns_exit(int exit_code)
{
    if(_Global.pp_dev)
        pcap_close(_Global.pp_dev);
	if(_Global.interface_name)
		free(_Global.interface_name);
	if(_Sess_Hash)
		dspr_hash_destroy(&_Sess_Hash);
	if(_Server_Rslist){
        Rslist_Destroy(_Server_Rslist);
        free(_Server_Rslist);
    }
    exit(exit_code);
}

static int argument_parse(int argc,char *argv[]);

static void session_time_stat_cb(dspr_hash_node_t *node,void *param)
{
    Meter_Session_HashValue *mhvalue = (Meter_Session_HashValue*)dspr_hash_node_get_value(node);
    int elapsed = 0;
    int start_ms = 0,end_ms = 0;
    
    end_ms = mhvalue->end.tv_usec / 1000;
    start_ms = mhvalue->start.tv_usec / 1000;
    elapsed = (mhvalue->end.tv_sec - mhvalue->start.tv_sec)*1000 + (end_ms - start_ms);
    _Stat.total_session_time += elapsed;
}

static void session_stat_cb(dspr_hash_node_t *node,void *param)
{
    Meter_Session_HashValue *mhvalue = (Meter_Session_HashValue*)dspr_hash_node_get_value(node);
    Meter_Session_HashValue *mhheader = mhvalue;
    Meter_Server_Listen_Value servertcp,*pserver = NULL;
    Meter_Server_Ip_Value *pserverip = NULL,serverip;
    char clientBuf[32],serverBuf[32];
    unsigned int key = 0, total_packet = 0, total_size = 0;
    unsigned long long llkey = 0;
    int elapsed = 0;
    
    if(NULL == mhvalue)
    {
        return;
    }

    do{    
        memset(clientBuf,0,sizeof(clientBuf));
        memset(serverBuf,0,sizeof(serverBuf));
        meter_iptos(mhvalue->key.client_ip,clientBuf);
        meter_iptos(mhvalue->key.server_ip,serverBuf);

        mhvalue->end.tv_usec /= 1000;
        mhvalue->start.tv_usec /= 1000;
        elapsed = (mhvalue->end.tv_sec - mhvalue->start.tv_sec)*1000 + (mhvalue->end.tv_usec - mhvalue->start.tv_usec);

        printf("Meter Session: %-3d  %s:%-5d ---> %s:%-5d  "
               "ReqPack:%-6d ReqSize:%-6d  "
               "ResPack:%-6d ResSize:%-6d  "
               "TotalPack:%-6d TotalSize:%-6d  "
               "Elapsed:%u ms  %s.%s\n",
            ((struct stat_cb_param_s*)param)->count++,
            clientBuf,mhvalue->key.client_port,
            serverBuf,mhvalue->key.server_port,
            mhvalue->request_packet,mhvalue->request_size,
            mhvalue->response_packet,mhvalue->response_size,
            mhvalue->request_packet + mhvalue->response_packet,
            mhvalue->request_size + mhvalue->response_size,
            elapsed,
            (mhvalue->syn_flag)?"Syn":"NoConnect",
            (mhvalue->fin_flag)?"Fin":"NoEnd");
        /* for server stat */
        total_packet += mhvalue->request_packet + mhvalue->response_packet;
        total_size += mhvalue->request_size + mhvalue->response_size;
    }
    while(mhvalue = mhvalue->next);

    mhvalue = mhheader;
    //统计服务器信息
    if(_Server_Rslist)
    {
        key = DBFW_HTON32(mhvalue->key.server_ip);
        llkey = key;
        llkey <<= 32;
        llkey += mhvalue->key.server_port;
        pserver = (Meter_Server_Listen_Value*)Rslist_Find(_Server_Rslist,llkey);
        if(pserver)
        {
            pserver->total_packet += total_packet;
            pserver->total_size += total_size;
            pserver->client_number++;            
        }
        else
        {
            int i = 0;
            while(stat_port_table[i].port)
            {
                if (stat_port_table[i].port == mhvalue->key.server_port)
                    break;
                i++;
            }
            memset(&servertcp,0,sizeof(Meter_Server_Listen_Value));
            servertcp.ipaddr = mhvalue->key.server_ip;
            servertcp.port = mhvalue->key.server_port;
            servertcp.total_packet = total_packet;
            servertcp.total_size = total_size;
            servertcp.client_number = 1;
            servertcp.serv_name = stat_port_table[i].serv_name;
            Rslist_Insert(_Server_Rslist,llkey,&servertcp);
            stat_port_table[i].count++;
        }
    }
    
    if(_ServerIp_Rslist)
    {
        key = DBFW_HTON32(mhvalue->key.server_ip);
        pserverip = (Meter_Server_Ip_Value*)Rslist_Find(_ServerIp_Rslist,key);
        if(pserverip)
        {
            pserverip->total_packet += total_packet;
            pserverip->total_size += total_size;
            pserverip->client_number++;
        }
        else
        {
            memset(&serverip,0,sizeof(serverip));
            serverip.total_packet = total_packet;
            serverip.total_size = total_size;
            serverip.client_number = 1;
            Rslist_Insert(_ServerIp_Rslist,key,&serverip);
        }
    }
}

static void session_stat(dspr_hash_t *sess_hash)
{
    struct stat_cb_param_s param;
    param.count = 1;
    if(sess_hash == NULL)
        return;
    dspr_hash_enum(sess_hash,session_stat_cb,&param);
}

static void session_create_key(Meter_Packet_Info *pkt_info,Meter_Session_HashKey *mhkey)
{
    memset(mhkey,0,sizeof(Meter_Session_HashKey));
    mhkey->proto = pkt_info->ipv4_header.ip_protocol;
    if(pkt_info->direction == mb_pkt_dct_request)
    {
        mhkey->client_ip = pkt_info->ipv4_header.ip_srcaddr;
        mhkey->client_port = pkt_info->tcp_header.source_port;
        mhkey->server_ip = pkt_info->ipv4_header.ip_destaddr;
        mhkey->server_port = pkt_info->tcp_header.dest_port;
    }
    else
    {
        mhkey->client_ip = pkt_info->ipv4_header.ip_destaddr;
        mhkey->client_port = pkt_info->tcp_header.dest_port;
        mhkey->server_ip = pkt_info->ipv4_header.ip_srcaddr;
        mhkey->server_port = pkt_info->tcp_header.source_port;
    }
    mhkey->client_ip = DBFW_HTON32(mhkey->client_ip);
    mhkey->server_ip = DBFW_HTON32(mhkey->server_ip);
    return;    
}

static Meter_Session_HashValue *session_register(dspr_hash_t *sess_hash,const struct pcap_pkthdr *header,Meter_Packet_Info *pkt_info)
{
    Meter_Session_HashKey mhkey;
    Meter_Session_HashValue *mhhead = NULL,*mhvalue = NULL,*mhnext = NULL;
    
    //放入哈希表
    session_create_key(pkt_info,&mhkey);
    
    mhhead = (Meter_Session_HashValue*)dspr_hash_find(sess_hash,&mhkey,sizeof(Meter_Session_HashKey));
    if(NULL == mhhead)
    {
        mhhead = (Meter_Session_HashValue*)malloc(sizeof(Meter_Session_HashValue));
        if(mhhead)
        {
            memset(mhhead,0,sizeof(Meter_Session_HashValue));
            memcpy(&(mhhead->key),&mhkey,sizeof(Meter_Session_HashKey));
            memcpy(&(mhhead->start),&(header->ts),sizeof(struct timeval));
            memcpy(&(mhhead->end),&(header->ts),sizeof(struct timeval));
            dspr_hash_insert(sess_hash,&(mhhead->key),sizeof(Meter_Session_HashKey),mhhead,0,0);
        }
    }
    if(NULL == mhhead)
    {
        return NULL;
    }
    
    if(mhhead->session_over)
    {
        mhvalue = mhhead->tail;        
    }
    else
    {
        mhvalue = mhhead;
    }

    //这表明客户端的端口被重用了，并且访问的还是同样的数据库，因此在这里，所有相同的客户端ip,port的会话形成一个链表
    if(pkt_info->tcp_header.syn && mhvalue->fin_flag)
    {
        mhvalue->session_over = 1;
        mhnext = (Meter_Session_HashValue*)malloc(sizeof(Meter_Session_HashValue));
        if(mhnext == NULL)
        {
            return NULL;
        }
        memset(mhnext,0,sizeof(Meter_Session_HashValue));
        memcpy(&(mhnext->key),&mhkey,sizeof(Meter_Session_HashKey));
        memcpy(&(mhnext->start),&(header->ts),sizeof(struct timeval));
        memcpy(&(mhnext->end),&(header->ts),sizeof(struct timeval));
        mhvalue->next = mhnext;
        mhhead->tail = mhnext;
        mhvalue = mhnext;
    }

    if(NULL == mhvalue)
    {
        return NULL;
    }
    
    if(pkt_info->tcp_header.syn)
    {
        mhvalue->syn_flag++;
    }
    if(pkt_info->tcp_header.fin)
    {
        mhvalue->fin_flag++;
    }

    if(pkt_info->direction == mb_pkt_dct_request)
    {
        mhvalue->request_packet++;
        mhvalue->request_size += header->len;//pkt_size;
        if(mhvalue->start_sequence == 0)
        {
            mhvalue->start_sequence = pkt_info->tcp_header.sequence;
        }
        mhvalue->end_sequence = pkt_info->tcp_header.sequence;
        if(mhvalue->start_acknowledge == 0)
        {
            mhvalue->start_acknowledge = pkt_info->tcp_header.acknowledge;
        }
        mhvalue->end_acknowledge = pkt_info->tcp_header.acknowledge;
    }
    else if(pkt_info->direction == mb_pkt_dct_response)
    {
        mhvalue->response_packet++;
        mhvalue->response_size += header->len;//pkt_size;
        if(mhvalue->start_sequence == 0)
        {
            mhvalue->start_sequence = pkt_info->tcp_header.acknowledge;
        }
        mhvalue->end_sequence = pkt_info->tcp_header.acknowledge;
        if(mhvalue->start_acknowledge == 0)
        {
            mhvalue->start_acknowledge = pkt_info->tcp_header.sequence;
        }
        mhvalue->end_acknowledge = pkt_info->tcp_header.sequence;
    }
    memcpy(&(mhvalue->end),&(header->ts),sizeof(struct timeval));
    return mhvalue;
}

static int server_listen_stat_cb(FILE* fp,unsigned long long key,void *data)
{
    Meter_Server_Listen_Value *server_value = (Meter_Server_Listen_Value*)data;
    char serverBuf[20],serverTmp[32];
    if(NULL == server_value)
    {
        return -1;
    }
    memset(serverBuf,0,sizeof(serverBuf));
    meter_iptos(server_value->ipaddr,serverBuf);
    sprintf(serverTmp,"%s:%d",serverBuf,server_value->port);

    printf("Meter Server Listen:%-15s %-3d  %-22s   Client Number:%d  Total Packet:%-6d  Total Size:%-6d\n",
        server_value->serv_name,
        _server_count++,
        serverTmp,
        server_value->client_number,
        server_value->total_packet,
        server_value->total_size);
    fp = NULL;
    key = 0;
    return 0;
}

static int server_ip_enum_cb(FILE* fp,unsigned long long key,void *data)
{
    Meter_Server_Ip_Value *pserverip = (Meter_Server_Ip_Value*)data;
    char serverBuf[20];
    unsigned int mykey = (unsigned int)key;
    
    memset(serverBuf,0,sizeof(serverBuf));
    
    mykey = DBFW_HTON32(mykey);
    meter_iptos(mykey,serverBuf);
    
    printf("Meter Server IP: %-3d  %-22s   Client Number:%d  Total Packet:%-6d  Total Size:%-6d\n",
        _server_count++,
        serverBuf,
        pserverip->client_number,
        pserverip->total_packet,
        pserverip->total_size);
    fp = NULL;
    return 0;
}

static void server_stat()
{
    int i = 0;
    if(Rslist_Count(_Server_Rslist) > 0)
    {
        printf("\nMeter Stat: Report Server Listen Info:\n");
        _server_count = 1;
        Rslist_Enum(_Server_Rslist,NULL,server_listen_stat_cb);
    }
    if(Rslist_Count(_ServerIp_Rslist) > 0)
    {
        printf("\nMeter Stat: Report Server Ipaddr Info:\n");
        _server_count = 1;
        Rslist_Enum(_ServerIp_Rslist,NULL,server_ip_enum_cb);
    }
    while (stat_port_table[i].port)
    {
        if (stat_port_table[i].count > 0)
        {
            printf("Total %-6d %-15s DB server listening!\n", stat_port_table[i].count, stat_port_table[i].serv_name);
        }
        i++;
    }
}

static void stat_packet_cb(u_char *param, const struct pcap_pkthdr *header, const u_char *pkt_data)
{
//    char flagbuf[8];
    int res = 0;
//    int flag = 0;
//    unsigned int srcip = 0,dstip = 0;

    Dbfw_EthernetFrame eth_frame;
    Meter_Packet_Info pkt_info;

    param = NULL;
    memset(&eth_frame,0,sizeof(eth_frame));
    memset(&pkt_info,0,sizeof(pkt_info));        
    eth_frame.frame_data = (u_char*)pkt_data;
    eth_frame.frame_size = header->len;
    res = Dbfw_Protocol_Parse(&eth_frame,&pkt_info,_Rule.server_rule);
    if(res <= 0)
    {
        return;
    }
    if(_Stat.total_packet == 0)
        memcpy(&(_Stat.begin),&(header->ts),sizeof(struct timeval));
    memcpy(&(_Stat.end),&(header->ts),sizeof(struct timeval));
    _Stat.total_packet++;
    _Stat.total_size+= header->len;
    if(res > METER_MAX_PROTO)
    {
        return;
    }
    _Stat.proto[res-1].total_packet++;
    _Stat.proto[res-1].total_size+= header->len;
    if(res == meter_proto_cs)
    {
        session_register(_Sess_Hash,header,&pkt_info);
    }
    if(0 == (_Stat.total_packet % 100000))
    {
        printf("Meter Packet: Current Packet Count:%d\n",_Stat.total_packet);
    }
}

static char *_dbns_proto_desc[] = {
    (char*)"Client/Server",
    (char*)"Ethernet",
    (char*)"Arp",
    (char*)"Ipv6",
    (char*)"Ip",
    (char*)"Icmp",
    (char*)"Udp",
    (char*)"Tcp",
    (char*)"Http",
    (char*)"Https",
    (char*)"Ssh",//11
    (char*)"Empty",
    (char*)"Empty",
    (char*)"Empty",
    (char*)"Empty",
    (char*)"Empty"
    };

int dbns_process_stat_mode()
{
    int count = 0;
    struct tm *mytm = NULL;
    time_t tm;
    unsigned int elapsed = 0;
    float concurrency = 0.0;

    _Stat.end.tv_usec /= 1000;
    _Stat.begin.tv_usec /= 1000;
    elapsed = (_Stat.end.tv_sec - _Stat.begin.tv_sec)*1000 + (_Stat.end.tv_usec - _Stat.begin.tv_usec);

    printf("\nMeter Stat: Time Info:\n");
    tm = _Stat.begin.tv_sec;
    mytm=localtime(&tm);
    printf("Meter Stat: Begin Time: %4d-%02d-%02d %02d:%02d:%02d.%03d\n",
        mytm->tm_year+1900,mytm->tm_mon+1,mytm->tm_mday,mytm->tm_hour,
        mytm->tm_min,mytm->tm_sec,(int)_Stat.begin.tv_usec);
    tm = _Stat.end.tv_sec;
    mytm=localtime(&tm);
    printf("Meter Stat: End Time: %4d-%02d-%02d %02d:%02d:%02d.%03d\n",
        mytm->tm_year+1900,mytm->tm_mon+1,mytm->tm_mday,mytm->tm_hour,
        mytm->tm_min,mytm->tm_sec,(int)_Stat.end.tv_usec);

    elapsed /= 1000;
    printf("Meter Stat: Capture Elapsed Time: %-4u seconds\n",elapsed);

    printf("\nMeter Stat: Concurrency Info:\n");
    dspr_hash_enum(_Sess_Hash,session_time_stat_cb,NULL);
    printf("Meter Stat: Total Session: %d\n",dspr_hash_count(_Sess_Hash));
    _Stat.total_session_time /= 1000;
    printf("Meter Stat: Total Session Elapsed Time: %-4u seconds\n",_Stat.total_session_time);
    concurrency = (float)_Stat.total_session_time/(float)elapsed;
    printf("Meter Stat: Average Session Concurrency: %.1f per second\n",concurrency);

    printf("\nMeter Stat: Report Protocol Info:\n");
    for(count=0;count<meter_proto_ssh;count++)
    {
        printf("Meter Stat: %15s  %-6u  %-6u\n",
            _dbns_proto_desc[count],_Stat.proto[count].total_packet,_Stat.proto[count].total_size);
    }
    printf("Meter Stat: %15s  %-6u  %-6u\n",
        "Total",_Stat.total_packet,_Stat.total_size);

    if (dspr_hash_count(_Sess_Hash) > 0)
    {
        printf("\nMeter Stat: Report Session Info:\n");
        session_stat(_Sess_Hash);
        server_stat();
    }
    return 0;
}

void handle_int_sig(void)
{
    switch (_Global.state) {
        case dbns_state_init:
            _Global.state = dbns_state_waiting_report;
            break;
        case dbns_state_waiting_report:
        default:
            dbns_exit(-100);
    }
}

#ifdef WIN32
BOOL CtrlHandler( DWORD fdwCtrlType ) 
{ 
    if(fdwCtrlType == CTRL_C_EVENT) 
    {
        handle_int_sig();
        return TRUE;
    }
    return FALSE;
} 
#else
void sig_handler(int signo)
{
    if (signo == SIGINT)
    {
        handle_int_sig();
    }
}
#endif

/* Print all the available information on the given interface */
void print_nic_info(pcap_if_t *d)
{
  pcap_addr_t *a;
  char ip6str[128];

  /* Name */
  printf("%s\n",d->name);

  /* Description */
  if (d->description)
    printf("\tDescription: %s\n",d->description);

  /* Loopback Address*/
  printf("\tLoopback: %s\n",(d->flags & PCAP_IF_LOOPBACK)?"yes":"no");

  /* IP addresses */
  for(a=d->addresses;a;a=a->next) {
    printf("\tAddress Family: #%d\n",a->addr->sa_family);
  
    switch(a->addr->sa_family)
    {
      case AF_INET:
        printf("\tAddress Family Name: AF_INET\n");
        if (a->addr)
        {
          meter_iptos(((struct sockaddr_in *)a->addr)->sin_addr.s_addr, ip6str);
          printf("\tAddress: %s\n",ip6str);
        }
        if (a->netmask)
        {
          meter_iptos(((struct sockaddr_in *)a->netmask)->sin_addr.s_addr, ip6str);
          printf("\tNetmask: %s\n",ip6str);
        }
        if (a->broadaddr)
        {
          meter_iptos(((struct sockaddr_in *)a->broadaddr)->sin_addr.s_addr, ip6str);
          printf("\tBroadcast Address: %s\n",ip6str);
        }
        if (a->dstaddr)
        {
          meter_iptos(((struct sockaddr_in *)a->dstaddr)->sin_addr.s_addr, ip6str);
          printf("\tDestination Address: %s\n",ip6str);
        }
        break;

	  case AF_INET6:
       printf("\tAddress Family Name: AF_INET6\n");
		break;

	  default:
        printf("\tAddress Family Name: Unknown\n");
        break;
    }
  }
  printf("\n");
}

int main(int argc, char *argv[])
{
    char errbuf[PCAP_ERRBUF_SIZE];
    Rslist_Config config;
    uint8_t *start_addr = NULL;
    int res;
	struct pcap_pkthdr *header;
	const u_char *pkt_data;

    memset(&_Global,0,sizeof(DBNetstat_Global));
    memset(&_Rule,0,sizeof(DBNetstat_Rule));
    _Rule.client_rule = dspr_hash_new();
    dspr_hash_init(_Rule.client_rule,(char*)"ClientRule",4096,NULL,NULL,NULL);
    _Rule.server_rule = dspr_hash_new();
    dspr_hash_init(_Rule.server_rule,(char*)"ServerRule",4096,NULL,NULL,NULL);
    
    argument_parse(argc,argv);

    // Print nic device info and index for user to select
    if (_Global.interface_name == NULL)
    {
        pcap_if_t *alldevs;
        pcap_if_t *d;
        char errbuf[PCAP_ERRBUF_SIZE+1];
        int i = 0, inum;

    	/* Retrieve the device list */
    	if(pcap_findalldevs(&alldevs, errbuf) == -1)
    	{
    		printf("Error in pcap_findalldevs: %s\n", errbuf);
    		return -1;
    	}

    	/* Scan the list printing every entry */
    	for(d=alldevs;d;d=d->next)
    	{
            printf("%d ", ++i);
    		print_nic_info(d);
    	}

        if(i==0)
        {
            printf("\nNo interfaces found! Make sure pcap is installed.\n");
            return -2;
        }
        
        printf("Enter the interface number (1-%d):",i);
        scanf("%d", &inum);
        
        if(inum < 1 || inum > i)
        {
            printf("\nInterface number out of range.\n");
            /* Free the device list */
            pcap_freealldevs(alldevs);
            return -3;
        }
    		
    	/* Jump to the selected adapter */
        for(d=alldevs, i=0; i< inum-1 ;d=d->next, i++);
        
        _Global.interface_name = strdup(d->name);

        /* Free the device list */
        pcap_freealldevs(alldevs);
    }

    /* Open the adapter */
    if ((_Global.pp_dev = pcap_open_live(_Global.interface_name,   // name of the device
                             65536,         // portion of the packet to capture. 
                                            // 65536 grants that the whole packet will be captured on all the MACs.
                             1,             // promiscuous mode (nonzero means promiscuous)
                             1000,          // read timeout
                             errbuf         // error buffer
                             )) == NULL)
    {
        fprintf(stderr,"\nUnable to open the adapter. %s is not supported by pcap\n", _Global.interface_name);
        return -4;
    }
    
    printf("Meter Info:  dbnetstat version:%s  libpcap version:%s\n",VERSION,pcap_lib_version());
    printf("Meter Info:  Interface '%s'\n", _Global.interface_name);

    _Sess_Hash = dspr_hash_new();
    dspr_hash_init(_Sess_Hash,(char*)"SessionHash",10000,NULL,NULL,NULL);

    memset(&config,0,sizeof(Rslist_Config));
    config.total_kbsize = 4096;
    config.max_slot = 1;
//    config.verbose = 1;
    config.user_data_size = sizeof(Meter_Server_Listen_Value);
    start_addr = (uint8_t*)malloc(config.total_kbsize*1024);

    memset(errbuf,0,sizeof(errbuf));
    _Server_Rslist = Rslist_Init(start_addr,&config,errbuf);
    if(_Server_Rslist == NULL)
        printf("Meter Error: Rslist_Init error:%s\n",errbuf);

    memset(&config,0,sizeof(Rslist_Config));
    config.total_kbsize = 2048;
    config.max_slot = 1;
//    config.verbose = 1;
    config.user_data_size = sizeof(Meter_Server_Ip_Value);
    start_addr = (uint8_t*)malloc(config.total_kbsize*1024);

    memset(errbuf,0,sizeof(errbuf));
    _ServerIp_Rslist = Rslist_Init(start_addr,&config,errbuf);
    if(_ServerIp_Rslist == NULL)
        printf("Meter Error: Rslist_Init error:%s\n",errbuf);

#ifdef WIN32
    if(!SetConsoleCtrlHandler((PHANDLER_ROUTINE) CtrlHandler, TRUE)) 
    { 
        printf( "\nERROR: Could not set control handler"); 
        dbns_exit(-8);
    }
#else
    signal(SIGINT, sig_handler);
#endif

    printf("\nlistening on %s... \nPress Ctrl+C to stop...\n", _Global.interface_name);
    
    printf("\nMeter Packet: Begin Stat ...\n");

	/* Retrieve packets from adapter and get statistics info */
	while((res = pcap_next_ex( _Global.pp_dev, &header, &pkt_data)) >= 0)
    {
		if(res == 0)
			/* Timeout elapsed */
			continue;

        if(_Global.state == dbns_state_waiting_report)
            /* Print statistics report */
            break;

		stat_packet_cb(NULL, header, pkt_data);
	}
	
	if(res == -1)
    {
		printf("Error reading the packets: %s\n", pcap_geterr(_Global.pp_dev));
		dbns_exit(-6);
	}
	
    pcap_close(_Global.pp_dev);
    _Global.pp_dev = NULL;
	    
    dbns_process_stat_mode();
    dbns_exit(0);
}

static void usage(char *progname)
{
    printf("\nVersion:%s  %s  Build %s %s\n",
        VERSION,pcap_lib_version(),BUILD_DATE,BUILD_SVN);
    
    printf("\nUasge: %s [option]\n",progname);
    printf("Option:\n");
    printf("\t--nic device  network device to open\n");

    exit(0);
}

static int argument_parse(int argc,char *argv[])
{
    int arg_num = argc - 1,i;

    for(i = 1; i < arg_num; i++)
    {
		if(0 == strcmp(argv[i],"--nic"))
        {
            if(i >= arg_num-1){
                printf("Meter Error: argument '%s' error\n",argv[i]);
                usage(argv[0]);
                return -1;
            }
            i++;
            _Global.interface_name = argv[i];
        }
        else
        {
            printf("Meter Error: unknown argument '%s'\n",argv[i]);
            usage(argv[0]);
            return -1;            
        }
    }

    return 0;
}

#ifdef __cplusplus
}
#endif
