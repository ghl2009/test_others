
#ifndef DBNETSTAT_H
#define DBNETSTAT_H

#include <sys/types.h>
#include <pcap.h>
#include "meter_broadcast.h"
#include "dspr_hash.h"

#ifdef __cplusplus
extern "C" {
#endif

enum
{
    dbns_state_init = 0,
    dbns_state_waiting_report
};

typedef struct 
{
    int state;
    char *interface_name;
    pcap_t *pp_dev;
}DBNetstat_Global;

typedef struct 
{
    dspr_hash_t *client_rule;    
    dspr_hash_t *server_rule;
}DBNetstat_Rule;

#define METER_MAX_PROTO        16

typedef struct 
{
    struct timeval begin;
    struct timeval end;
    unsigned int total_session_time;//
    unsigned int total_packet;
    unsigned int total_size;
    Meter_Proto_Stat proto[METER_MAX_PROTO];
}DBNetstat_Stat;

#ifdef __cplusplus
}
#endif

#endif
