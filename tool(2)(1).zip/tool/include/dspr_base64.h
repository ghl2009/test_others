#ifndef DSPR_BASE64_H
#define DSPR_BASE64_H

#include <stdio.h>

#ifdef __cplusplus
extern "C" {
#endif

int dspr_base64_encode(const void *src, int src_len, char *dst);
int dspr_base64_decode(const char *src_base, int len,void *dst, const char **end_ptr);


#ifdef __cplusplus
}
#endif

#endif
