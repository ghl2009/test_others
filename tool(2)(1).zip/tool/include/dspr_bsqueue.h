#ifndef DSPR_BSQUEUE_H
#define DSPR_BSQUEUE_H

#ifdef __cplusplus
extern "C" {
#endif

#pragma pack(1)
#define barrier() __asm__ __volatile__("": : :"memory") 

#define DSPR_BSQUEUE_MAGIC  0x66bb77cc

/*
 *
 */
typedef struct 
{
	/*  配置性数据 */
	int                       total_size;//单位是M
	int                       node_number;
	unsigned int              magic;
	
	/* 队列相关变量  */
	int                       queue_start;
	int                       queue_size;
	int                       queue_write_offset;
	int                       queue_read_offset;
	int                       queue_length;
	
	/* 数据内容相关变量  */
	int                       content_start;
	int                       content_size;
	int                       content_cursor;
	int                       reserved;

	/* 统计相关变量  */
	unsigned int              write_op_total;
	unsigned int              read_op_total;
	unsigned long long int    write_size_total;
	unsigned long long int    read_size_total;

}Dspr_Bsqueue_t;

/*
 *
 */
typedef struct
{
	unsigned char* data;
	unsigned short size;
	unsigned short reserved;
}Dspr_Bsqueue_Node;


/*
 *
 */
Dspr_Bsqueue_t *dspr_bsqueue_init(unsigned char* start_addr,int msize,int node_number,char *errstr);


Dspr_Bsqueue_t *dspr_bsqueue_check(unsigned char* start_addr);

/*
 * 1.
 */
int dspr_bsqueue_put(Dspr_Bsqueue_t *queue,unsigned char* data,unsigned short size);

/*
 * 2.
 */
int dspr_bsqueue_get(Dspr_Bsqueue_t *queue,Dspr_Bsqueue_Node *node);


int dspr_bsqueue_clean(Dspr_Bsqueue_t *queue);

#ifdef __cplusplus
}
#endif

#endif
