#ifndef DSPR_DATA_H
#define DSPR_DATA_H

#ifdef __cplusplus
extern "C" {
#endif

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

typedef struct
{
	unsigned char *data;
	int            size;
	int            length;
}dspr_data_t;

int dspr_data_init(dspr_data_t *data,int size);

int dspr_data_create(dspr_data_t *data,unsigned char *value,int size);

int dspr_data_append(dspr_data_t *data,unsigned char *value,int size);

int dspr_data_copy(dspr_data_t *to,dspr_data_t *from);

int dspr_data_free(dspr_data_t *data);

int dspr_data_read_word(dspr_data_t *data,int size,void* value);

int dspr_data_read_data(dspr_data_t *data,int size,dspr_data_t* value);

int dspr_data_read_auto(dspr_data_t *data,int prefix_size,dspr_data_t* value);


#ifdef __cplusplus
}
#endif

#endif
