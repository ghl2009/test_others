#ifndef DSPR_FILE_H
#define DSPR_FILE_H

#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <dirent.h>

#ifdef __cplusplus
extern "C" {
#endif

#define dspr_dir_open  opendir
#define dspr_dir_read  readdir
#define dspr_dir_close  closedir
int dspr_dir_make(const char *path);

int dspr_chown(const char *path,char *user);
#ifdef __cplusplus
}
#endif

#endif
