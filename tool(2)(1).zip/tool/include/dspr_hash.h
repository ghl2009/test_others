
#ifndef DSPR_HASH_H
#define DSPR_HASH_H

/**
 *\file dspr_hash.h
 *\brief DSPR库的Hash表模块
 *\author 刘晓强
 *\version 0.1.0
 *\date 2012-02-12
 */

#ifdef __cplusplus
extern "C" {
#endif

/**************************************************************************************************/
/**
 *\defgroup hash 哈希表
 *
 **************************************************************************************************/

/**************************************************************************************************/
/**
 *\defgroup hash_struct 基本数据结构
 *\ingroup hash
 **************************************************************************************************/

/**
 *\ingroup hash_struct
 *\brief 默认哈希表大小
 */
#define HASH_DEFAULT_SIZE		2048

/**
 *\ingroup hash_struct
 *\brief 哈希表关键字非法长度
 */
#define SPPR_HASH_KEY_STRING	(-1)

/**
 *\ingroup hash_struct
 *\brief 哈希表名称的最大长度
 */
#define HASH_MAX_NAME		20

/**
 *\ingroup hash_struct
 *\brief 哈希表节点的描述
 */
typedef struct dspr_hash_node_s dspr_hash_node_t;

/**
 *\ingroup hash_struct
 *\brief 哈希表的哈希函数
 */
typedef int(*dspr_hashfunc_t)(const void *key,int key_size);

/**
 *\ingroup hash_struct
 *\brief 哈希表的比较回调函数
 */
typedef int (*dspr_cmpfunc_t)(const void *keya,const void *keyb,int key_size);

/**
 *\ingroup hash_struct
 *\brief 哈希表的删除回调函数
 */
typedef void (*dspr_hashdelete_t)(dspr_hash_node_t *node);

/**
 *\ingroup hash_struct
 *\brief 哈希表的遍历回调函数
 */
typedef void (*dspr_hashenum_t)(dspr_hash_node_t *node,void *param);

/**
 *\ingroup hash_struct
 *\brief 描述一个哈希表结构
 */
typedef struct dspr_hash_s dspr_hash_t;

/**************************************************************************************************/
/**
 *\defgroup hash_base 基本函数
 *\ingroup hash
 **************************************************************************************************/

/**
 *\ingroup hash_base
 *\fn dspr_hash_t *dspr_hash_new()
 *\brief 创建一个新的哈希表
 *\return dspr_hash_t*类型指针
 *\retval 非空 成功创建一个新的哈希表,返回哈希表指针。
 *\retval NULL 失败 
 */
dspr_hash_t *dspr_hash_new();

/**
 *\ingroup hash_base
 *\brief 销毁一个哈希表
 *\param[in] hash 哈希表二级指针。
 *\return 是否销毁成功
 *\retval 0 成功
 *\retval <0 失败
 */
int dspr_hash_destroy(dspr_hash_t **hash);


/**
 *\ingroup hash_base
 *\brief 初始化一个哈希表
 *\param[in] hash 哈希表指针。			
 *\param[in] name 哈希表名称。			
 *\param[in] size 哈希表大小。			
 *\param[in] hash_func 哈希函数。			
 *\param[in] cmp_func 哈希比较函数。			
 *\return 是否创建成功
 *\retval 0 成功
 *\retval <0 失败
 */
int dspr_hash_init(dspr_hash_t *hash,char *name,int size,
						dspr_hashfunc_t hash_func,dspr_cmpfunc_t cmp_func,
						dspr_hashdelete_t del_func);

/**
 *\ingroup hash_base
 *\brief 与初始化对应的操作
 *\param[in] hash 哈希表指针。			
 *\return 是否释放成功
 *\retval 0 成功
 *\retval <0 失败
 */
int dspr_hash_finalize(dspr_hash_t *hash);


/**************************************************************************************************/
/**
 *\defgroup hash_ability 功能函数
 *\ingroup hash
 **************************************************************************************************/

/**
 *\ingroup hash_ability
 *\brief 向哈希表插入节点
 *\param[in] hash 哈希表指针。			
 *\param[in] key 关键字		
 *\param[in] key_size 关键字长度			
 *\param[in] value 哈希数据		
 *\param[in] group 所属分组 
 *\param[in] flags 标志信息 		
 *\return 返回参数value值
 *\retval <0 插入失败
 *\retval >=0 成功
 */
int dspr_hash_insert(dspr_hash_t *hash,void *key,int key_size,
						void *value,int group,unsigned int flags);

/**
 *\ingroup hash_ability
 *\brief 从哈希表删除节点
 *\param[in] hash 哈希表指针。			
 *\param[in] key 关键字		
 *\param[in] key_size 关键字长度
 *\param[in] delete_cb 删除的回调函数
 *\return 是否删除成功
 *\retval 0 成功
 *\retval <0 失败
 */
int dspr_hash_delete(dspr_hash_t *hash,const void *key,int key_size,
			dspr_hashdelete_t delete_cb);

/**
 *\ingroup hash_ability
 *\brief 清空哈希表,删除所有节点
 *\param[in] hash 哈希表指针。			
 *\param[in] delete_cb 删除的回调函数
 *\return 是否清空成功
 *\retval 0 成功
 *\retval <0 失败
 */
int dspr_hash_clear(dspr_hash_t *hash,dspr_hashdelete_t delete_cb);


/**
 *\ingroup hash_ability
 *\brief 查找节点
 *\param[in] hash 哈希表指针。			
 *\param[in] key 关键字		
 *\param[in] key_size 关键字长度			
 *\return 返回查到到的节点的数据的指针
 *\retval 非空 数据指针
 *\retval NULL 没找到
 */
void *dspr_hash_find(dspr_hash_t *hash,const void *key,int key_size);

/**
 *\ingroup hash_ability
 *\brief 在组中查找节点
 *\param[in] hash 哈希表指针。			
 *\param[in] key 关键字		
 *\param[in] key_size 关键字长度			
 *\param[in] group 组ID		
 *\return 返回查到到的节点的数据的指针
 *\retval 非空 数据指针
 *\retval NULL 没找到
 */
void *dspr_hash_group_find(dspr_hash_t *hash,const void *key,int key_size,int group);

/**
 *\ingroup hash_ability
 *\brief 遍历哈希表
 *\param[in] hash 哈希表指针
 *\param[in] enum_cb 遍历的回调函数
 *\param[in] param 回调函数的参数
 *\return 是否遍历成功
 *\retval 0 成功
 *\retval <0 失败
 */
int dspr_hash_enum(dspr_hash_t *hash,
				dspr_hashenum_t enum_cb,void *param);

/**
 *\ingroup hash_ability
 *\brief 按照组遍历哈希表
 *\param[in] hash 哈希表指针
 *\param[in] group 组id
 *\param[in] enum_cb 遍历的回调函数
 *\param[in] param 回调函数的参数
 *\return 是否遍历成功
 *\retval 0 成功
 *\retval <0 失败
 */
int dspr_hash_group_enum(dspr_hash_t *hash,int group,
				dspr_hashenum_t enum_cb,void *param);

/**************************************************************************************************/
/**
 *\defgroup hash_status 状态获取类函数
 *\ingroup hash
 **************************************************************************************************/

/**
 *\ingroup hash_status
 *\brief 获取当前节点数
 *\param[in] hash 哈希表指针
 *\return 返回节点个数
 *\retval >=0 当前节点数
 *\retval <0 失败
 */
int dspr_hash_count(dspr_hash_t *hash);


/**
 *\ingroup hash_status
 *\brief 哈希表是否可用
 *\param[in] hash 哈希表指针
 *\return 返回哈希表状态
 *\retval 0 成功
 *\retval <0 失败
 */
int dspr_hash_can_use(dspr_hash_t *hash);


int dspr_hash_set_userdata(dspr_hash_t *hash,void *userdata);

void *dspr_hash_get_userdata(dspr_hash_t *hash);

const char *dspr_hash_get_name(dspr_hash_t *hash);

int dspr_hash_get_size(dspr_hash_t *hash);

int dspr_hash_get_node_size();


void *dspr_hash_node_get_key(dspr_hash_node_t *node);

int dspr_hash_node_get_key_size(dspr_hash_node_t *node);

void *dspr_hash_node_get_value(dspr_hash_node_t *node);

int dspr_hash_node_set_value(dspr_hash_node_t *node,void *new_value);

void *dspr_hash_node_get_value_addr(dspr_hash_node_t *node);


int dspr_hash_node_get_slot(dspr_hash_node_t *node);

int dspr_hash_node_get_hashvalue(dspr_hash_node_t *node);

int dspr_hash_node_get_groupid(dspr_hash_node_t *node);


#ifdef __cplusplus
}
#endif

#endif
