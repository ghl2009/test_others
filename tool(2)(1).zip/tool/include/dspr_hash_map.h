#ifndef __DSPR_HASH_MAP_H__
#define __DSPR_HASH_MAP_H__


#ifdef __cplusplus
extern "C" {
#endif


#define COMM_HASHMAP_PRIME_FOR_SESSION         	5987	/*hash函数取模的质数,为 client ip+port => session_id提供 */
#define COMM_HASHMAP_MAX_ELEMENTS_FOR_SESSION  	8320	/*session_hashmp的缓冲池里节点的最大数量, 
														  session最多有8192个,增加了128个冗余节点,
														  因为当session断开时,节点不会被立即回收 
														*/
#define COMM_HASHMAP_PRIME_FOR_DB         		1021	/*hash函数取模的质数,为 db ip+port => 1 提供 */
#define COMM_HASHMAP_MAX_ELEMENTS_FOR_DB  		1024	/*db_hashmap的缓冲池里节点的最大数量，用此值来确定hashpool的大小*/

#define COMM_HASHMAP_NOT_FIND_KEY        65535   /*在hash表中没找到key时返回此值, 给find()和delete()函数使用*/

#define	COMM_DYNAMIC_PORT_TYPE_IN_HASH_MAP	2
#define	COMM_TELNET_PORT_TYPE_IN_HASH_MAP	1

#ifndef u_int64
typedef unsigned long long u_int64;
#endif

/*************************************
**
**	Hashmap中使用的节点
**	22个字节
**************************************/
typedef struct comm_hash_node
{
    u_int64				_key;			/* 在db_hashmap里,是db ip+port; 在session_hashmap里,是client ip+port */
    u_short				_value;			/* 在db_hashmap里是1; 在session_hashmap里,是session_id(0-8191) */
	int					_sem_id;		/* 在db_hashmap里没有使用;在session_hashmap里,是session_id对应的信号量id */
    struct comm_hash_node* _next;
}COMM_HASH_NODE;

/**************************************************************
**
**	每个hashmap有一个自己的hashpool
**	db_hashmap占用的大小: 1021*8+1024*22=8168+22528=30696
**	session_hashmap占用的大小: 5987*8+8320*22=47896+183040=230936
**
**************************************************************/
typedef struct comm_hash_pool
{
	void			*_pool;				/*缓冲池首地址的指针*/
	COMM_HASH_NODE	*_header;			/*缓冲池的所有节点构成一个链表,_header用于分配和释放节点*/
	u_int			_size;				/*缓冲池的大小,单位是字节 */
	COMM_HASH_NODE	**_buckets;			/*节点的指针数组*/
	u_int			_num_bucket;		/*桶的数量,是质数*/
	u_int			_num_element;		/*缓冲池最多可容纳的节点数量 */
}COMM_HASH_POOL;






extern void comm_hash_pool_init(u_char *pool, u_int num_node);
extern COMM_HASH_NODE* common_hash_map_alloc_node(COMM_HASH_POOL* hashpool);
extern int common_hash_map_init(COMM_HASH_POOL* hashpool);
extern void common_hash_map_destroy(COMM_HASH_POOL *hashpool);
extern int common_hash_map_insert(COMM_HASH_POOL* hashpool, u_int64 key, u_short value, int sem_id = -1);
extern u_short common_hash_map_find(COMM_HASH_POOL* hashpool, u_int64 key);
extern u_short common_hash_map_delete(COMM_HASH_POOL *hashpool, u_int64 key);
extern int common_hash_map_reset(COMM_HASH_POOL* hashpool);




#ifdef __cplusplus
}
#endif



#endif

