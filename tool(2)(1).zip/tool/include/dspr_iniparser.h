
#ifndef DSPR_INIPARSER_H
#define DSPR_INIPARSER_H

/***************************************************************
 *  
 **************************************************************/

#include <stdio.h>
#include <stdint.h>
#ifndef WIN32
#include <pthread.h>
#endif

#include "libbslhash.h"

#ifdef __cplusplus
extern "C" {
#endif

//#define DSPR_INIPARSER_MIN_BUF  16384
#define DSPR_INIPARSER_MIN_MANAGENT_SIZE (12*512/1024)

typedef Bslhash_t Dspr_IniParser;

typedef struct{
	int table_offset;
	int key_offset;
	int value_offset;
}Dspr_IniParser_Node;


Dspr_IniParser *Dspr_IniParser_Open(char *inifile,uint8_t *start_addr,int size,int verbose,int *errcode, int need_transcode = 0);

int Dspr_IniParser_Close(Dspr_IniParser *iniparser);

int Dspr_IniParser_Get(Dspr_IniParser *iniparser,char *table,char *key,char *value,int value_len);

typedef int(*iniparser_cb_t)(char *table,char *key,char *value,void *param);

int Dspr_IniParser_Enum(Dspr_IniParser *iniparser,char *table,iniparser_cb_t cb,void *param);

#ifdef __cplusplus
}
#endif

#endif
