#ifndef DSPR_IPC_H
#define DSPR_IPC_H

#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <unistd.h>

#include <sys/ipc.h>
#include <sys/sem.h>

#ifdef __cplusplus
extern "C" {
#endif

union dspr_semun
{
   int val;
   struct semid_ds *buf;
   unsigned short  *array;	
};

int dspr_sem_create(int nsems);

inline int dspr_sem_lock(int sem_id,int semunm)
{
	struct sembuf semoparray[1]={{semunm,-1,0}};
    return semop(sem_id, semoparray, 1);
}

inline int dspr_sem_lock_timed(int sem_id,int semunm,unsigned int milliseconds)
{
	struct sembuf semoparray[1]={{semunm,-1,0}};
	struct timespec timeout;
	timeout.tv_sec=milliseconds/1000;
	timeout.tv_nsec=milliseconds%1000*1000000;
	return semtimedop(sem_id, semoparray, 1, &timeout);	
}

inline int dspr_sem_unlock(int sem_id,int semunm)
{
	struct sembuf semoparray[1]={{semunm,1,0}};
    return semop(sem_id, semoparray, 1);
}

inline int dspr_sem_getvalue(int sem_id,int semunm)
{
	return semctl(sem_id, semunm, GETVAL);
}

inline void dspr_sem_remove(int sem_id)
{
	semctl(sem_id,0,IPC_RMID);	
}

#ifdef __cplusplus
}
#endif

#endif
