
#ifndef DSPR_LOG_H
#define DSPR_LOG_H

#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>

#ifdef __cplusplus
extern "C" {
#endif

#define DSPR_LOG_MAGIC                   0x55aa1234

#define DSPR_LOG_FATAL					0  //致命信息
#define DSPR_LOG_ERROR					1  //错误信息				打印错误信息
#define DSPR_LOG_WARNING				2  //告警信息				打印告警信息
#define DSPR_LOG_NOTICE					3  //重要信息				打印正常信息，但是比较重要
#define DSPR_LOG_INFO					4  //一般信息				打印一般的信息
#define DSPR_LOG_DEBUG					5  //一般调试信息				最轻量级的调试输出，函数的出入口可用此等级

#define DSPR_LOG_DAILY 0x01
#define DSPR_LOG_PID      0x02
#define DSPR_LOG_GB2312_SUPPORT 0x04
#define DSPR_LOG_OVERRIDE 0x08


typedef struct
{
	unsigned int magic;
	char file[512];
	char suffix[8];	
	int level;
	unsigned int flag;

	char curr_file[512];
	char curr_date[64];
	int curr_day;
	int last_day;

	int max_file_size;
	int max_file_num;
	int save_days;

	pthread_mutex_t mutex;
	FILE *pfile;	
}dspr_log_t;


int dspr_log_init(dspr_log_t *log,char *log_file,int level,unsigned int flag,int max_file_size,int max_file_num,int save_days);

int dspr_log_exit(dspr_log_t* log);
int dspr_log_open(dspr_log_t* log);

int dspr_log_close(dspr_log_t* log);

int dspr_log(dspr_log_t* log,const char *filename,const char *funcname,int line,int level,char *fmt,...);

int dspr_log_info(dspr_log_t* log,const char *filename, const char *funcname,int line,int level,char *info);


#ifdef __cplusplus
}
#endif

#endif

