#ifndef DSPR_MEMQUEUE_H
#define DSPR_MEMQUEUE_H

#ifdef __cplusplus
extern "C" {
#endif

#pragma pack(1)

// need to consider over unsigned long long ; 
// so we should set DSPR_MEMQUEUE_INDEX_NUM to be multi of 0XFFFF
#define DSPR_MEMQUEUE_INDEX_NUM        0xFFFF

#define barrier() __asm__ __volatile__("": : :"memory") 

#define DSPR_MQ_NORMAL 0
#define DSPR_MQ_NOPACK 1
#define DSPR_MQ_TRYAG  2
#define DSPR_MQ_ERROR  3
#define DSPR_MQ_FULL_1	0x80
#define DSPR_MQ_FULL_2	0x40

/*
 *
 */
typedef struct 
{
	int err_no;
	unsigned long long iSend;
	unsigned long long iRecv;
}Dspr_MemQueue_Err;

/*
 *
 */
typedef struct 
{
	unsigned long long iTotalSize;
	unsigned long long iIndexNum;
	
	unsigned long long iSend;
	unsigned long long iRecv;
	unsigned long long iCounter;
	
	pthread_mutex_t mq_mutex;
	
	unsigned long long iIndex[0];   // 这个变量必须在结构体的末尾
}Dspr_MemQueue_t;

/*
 *
 */
typedef struct
{
	unsigned short id;
	unsigned short flag;
	unsigned int value;
}Dspr_MemQueue_Node;

#pragma pack()

/*
 * totalsize: memqueue的总大小，单位为kb， totalsize * 1024要大于或等于(sizeof(Dspr_MemQueue_t) + sizeof(unsigned long long) * nodenum)
 * nodenum:   memqueue的支持的node的大小，范围为1--0xFFFFFF
 */
int dspr_memqueue_init(Dspr_MemQueue_t *queue, unsigned int totalsize, unsigned int nodenum);

/*
 * 1.
 */
int dspr_memqueue_put(Dspr_MemQueue_t *queue,Dspr_MemQueue_Node *node, Dspr_MemQueue_Err *merr);

/*
 * 2.
 */
unsigned long long dspr_memqueue_get(Dspr_MemQueue_t *queue,Dspr_MemQueue_Node *node);

int dspr_memqueue_mwmr_put(Dspr_MemQueue_t *queue,unsigned long long value);
unsigned long long dspr_memqueue_mwmr_tryget(Dspr_MemQueue_t *queue,unsigned long long *retval);
unsigned long long dspr_memqueue_mwmr_get(Dspr_MemQueue_t *queue,unsigned long long *retval);
unsigned long long dspr_memqueue_mutex_get(Dspr_MemQueue_t *queue,unsigned long long *retval);

#ifdef __cplusplus
}
#endif

#endif
