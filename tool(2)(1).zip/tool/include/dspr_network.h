#ifndef DSPR_NETWORK_H
#define DSPR_NETWORK_H

#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <unistd.h>

#ifdef __cplusplus
extern "C" {
#endif

void dspr_net_ntos(unsigned int ip,char *str);

int dspr_net_read(int sockfd,unsigned char *data, int datasz);

int dspr_net_write(int sockfd,unsigned char *data, int datasz);

#ifdef __cplusplus
}
#endif

#endif
