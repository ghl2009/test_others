#ifndef DSPR_OS_H
#define DSPR_OS_H

#include <string.h>
#include <stdio.h>
#include <stdlib.h>

#ifdef __cplusplus
extern "C" {
#endif

#define DSPR_CPU_MAX 24

#define CPU_TYPE_I5_2400 1
#define CPU_TYPE_I7_2600 2
#define CPU_TYPE_E5_2600 3
#define CPU_TYPE_I3_2120 4

#define PRODUCT_DBA      1
#define PRODUCT_DBF      2
#define PRODUCT_DBA_V    3
#define PRODUCT_DBF_V    4


#define DBA_B1000        1    // I5 8G
#define DBA_B5000        2    // I5 16G
#define DBA_B5000C       3    // I5 16G 2U
#define DBA_E10000       4    // I7 16G
#define DBA_E30000       5    // I7 32G
#define DBA_E50000       6    // I7 32G
#define DBA_RH80000      7    // E5(μ￥?·) 64G 
#define DBA_RH80000C     8    // E5(???·) 128G


#define PRODUCT_DBA_B1000        10001000
#define PRODUCT_DBA_B5000        10005000
#define PRODUCT_DBA_B5000C       10005002
#define PRODUCT_DBA_E10000       10010000
#define PRODUCT_DBA_E30000       10030000
#define PRODUCT_DBA_X50000       10050000
#define PRODUCT_DBA_RH80000      10080000
#define PRODUCT_DBA_RH80000C     10080002

#define PRODUCT_DBF_B1000        20001000
#define PRODUCT_DBF_B5000        20005000
#define PRODUCT_DBF_B5000C       20005002
#define PRODUCT_DBF_E10000       20010000
#define PRODUCT_DBF_E30000       20030000
#define PRODUCT_DBF_X50000       20050000
#define PRODUCT_DBF_RH80000      20080000
#define PRODUCT_DBF_RH80000C     20080002

#define PRODUCT_DBA_V_B1000      30001000
#define PRODUCT_DBA_V_B5000      30005000
#define PRODUCT_DBA_V_E10000     30010000
#define PRODUCT_DBA_V_E30000     30030000
#define PRODUCT_DBA_V_X50000     30050000

#define PRODUCT_DBF_V_B1000      40001000
#define PRODUCT_DBF_V_B5000      40005000
#define PRODUCT_DBF_V_E10000     40010000
#define PRODUCT_DBF_V_E30000     40030000
#define PRODUCT_DBF_V_X50000     40050000


/******************************************************
 *  设备类型和 cpu 内存 硬盘 类型的对应关系
 ******************************************************/
typedef struct DEV_INFO_LIST
{
    char                    product_name[32];   // 产品类型 DBA DBF DBA-V DBF-V 
    int                     n_dev_type;      // int型的设备类型号
    char                    s_dev_type[32];  // str型的设备类型号
    char                    type_name[32];   // 此类型名字
    int                     cpu_core_num;    // cpu核数
    int                     mem_size;        // 内存大小 G
    int                     disk_size;       // 磁盘大小 G

    //   limit信息
    int                     cpu_limit;       // cpu百分比限制
    int                     mem_limit;       // 内存百分比限制
    int                     packet_limit;    // 每秒包数限制
    int                     sql_limit;       // 每秒SQL数限制
    int                     session_limit;   // 会话数限制

    struct DEV_INFO_LIST    *next;           // 下一个节点的指针

}DEV_INFO_LIST;

/**************************************
*	描述信息
*	    绑定CPU接口，提供绑定指定CPU的功能
*	    可用模式如下:
*	        mode = 0,  绑定指定某一个CPU
*	            arg1 : 指定绑定CPU的序号(第一个为0，如果为倒数则为-1）
*	            arg2 : 不生效
*	            pid  : 不生效
*	        mode = 1,  绑定指定范围CPU，以node区分
*	            arg1 : 指定绑定的node, (第一个为0，倒数为-1, 100为所有node)
*	            arg2 : 由指定的node中剩余的CPU个数，剩余的CPU在最后，可为0
*	            pid  : 如果不为0，则为以上范围中的一个(由pid对范围个数取余获得范围数组下标)
*	        mode = 2,  绑定指定范围CPU，以边界区分
*	            arg1 : 范围的开始(第一个为0)
*	            arg2 : 范围的结束(最后一个为-1)
*	            pid  : 如果不为0，则为以上范围中的一个(由pid对范围个数取余获得范围数组下标)
*	            
*	返回值
*		=0  绑定成功
*       <0  绑定失败
***************************************/
int dspr_bind_cpu(int mode, int arg1, int arg2, int pid);
int dspr_bind_cpu_for_nfw( int id );

/*******************************************************
 * 功能名称：debug 输出函数
 *           需要 extern int debug_level;
 *           在debug_level >= 1的时候输出
 *******************************************************/
void LEVEL_PRINT(const char *fmt, ...);



/**************************************
*	描述信息
*	    获取CPU的信息，CPU总数 和 node数
*	            
*	返回值
*		=0  获取成功
*       <0  获取失败
***************************************/
int dspr_get_cpu_node_info();

/*******************************************************
 * 功能名称：从/proc/cpuinfo文件中获取CPU核数
 * 参数：
 * 返回值：
 *   -1: open /proc/cpuinfo error
 *   >0: cpu num
 *******************************************************/
int dspr_get_cpu_core_num();

/*******************************************************
 * 功能名称：通过numa获取cpu node数量
 * 参数：
 * 返回值：
 *   -1: error
 *   >0: cpu node num
 *******************************************************/
int dspr_get_cpu_node_num();

/*******************************************************
 * 功能名称：从/proc/cpuinfo文件中获取CPU详细信息
 * 参数：
 *      char *cpuinfo       传出参数  保存获取到的CPU信息
 *      int info_len        传入参数  cpuinfo长度
 * 返回值：
 *   -1: open /proc/cpuinfo error
 *    0: 成功
 *******************************************************/
int dspr_get_cpu_info(char *cpuinfo, int info_len);

/****************************************************
 * 功能名称：从/proc/partitions文件中获取最大的一颗硬盘的大小
 *          (找到最大的一块磁盘的大小)
 * 参数：
 * 返回值：
 *   -1: open /proc/partitions error
 *   >0: memory size, 单位 G
 ****************************************************/
int dspr_get_disk_size();

/****************************************************
 * 功能名称：从/proc/meminfo文件中获取内存大小
 *          (会比硬件实际的小  128G会小2G多的内存)
 * 参数：
 * 返回值：
 *   -1: open /proc/meminfo error
 *   >0: memory size, (G)
 ****************************************************/
int dspr_get_mem_size();

/*************************************************************
 * 功能名称：根据产品类型 和 CPU内存 获取真实的设备类型（num）(唯一)
 * 参数:
 * 返回值:
 *      -1  获取cpu个数失败
 *      -2  获取内存大小失败
 *      -3  获取磁盘大小失败
 *      -4  没有找到对应的类型 (不应该的，应该在配置文件中避免这种情况)
 *      >0  成功
 *************************************************************/
int dspr_get_real_dev_type(const char *product_type);

/******************************************************
 *  功能：  获取操作系统信息
 *          包含cpu、内存、硬盘信息，格式为 'cpu_info|mem_size(G)|disk(G)'
 *  参数：
 *          char *sysinfo    传出参数  保存获取到的操作系统信息
 *          int   info_len   传入的sysinfo串长度
 *  返回值：
 *      -1 获取cpu信息失败
 *      -2 获取mem信息失败
 *      -3 获取disk信息失败
 *      0  正常
 *
 ******************************************************/
int dspr_get_sysinfo(char *sysinfo, int info_len);

/******************************************************
 *  功能：  初始化dev_info_list结构体,用于保存设备类型和limit信息对应关系
 *          信息从totalconfig.lst文件中获取）
 *  参数：  
 *  返回值：
 *      -1 获取失败
 *      0  成功
 *
 ******************************************************/
int dspr_get_dev_info_list();

/******************************************************
 *  功能：  释放dev_info_list链表
 *  参数：  
 *  返回值：
 *      -1 失败
 *      0  成功
 *
 ******************************************************/
int dspr_destory_dev_info_list();


/******************************************************
 *  功能：  获取当前运行环境
 *  参数：  
 * 		char *runenv   运行环境返回值的缓冲区
 *      int bufsize    缓冲区大小
 *  返回值：
 *      -1 失败
 *      0  成功
 *
 ******************************************************/
int dspr_get_runenv(char *runenv,int bufsize);

/******************************************************
 *  功能：  根据设备类型获取到其对应的limit值（信息从totalconfig.lst文件中获取）
 *  参数：  
 *          int n_dev_type, 
 *          char *license_info,  //  license 内容
 *   		char *s_dev_type,    //  字符串的设备类型
 *          int *cpu_limit,      //  cpu使用百分比上限
 *          int *mem_limit,      //  内存使用百分比上限
 *          int *packet_limit,   //  每秒包数上限
 *          int *sql_limit,      //  每秒sql数上限
 *          int *session_limit)  //  会话数上限
 *  返回值：
 *      -1 获取失败
 *      0  成功
 *
 ******************************************************/
#ifdef ENABLE_DBSCLOUD
int dspr_get_limit_info_int(int n_dev_type, 
                            char *license_info,  //  license 内容
							char *s_dev_type,    //  字符串的设备类型
                            int *cpu_limit,      //  cpu使用百分比上限
                            int *mem_limit,      //  内存使用百分比上限
                            int *packet_limit,   //  每秒包数上限
                            int *sql_limit,      //  每秒sql数上限
                            int *session_limit);  //  会话数上限
/******************************************************
 *  功能：  从license字符串中获取超限信息
 *  参数：  
 *          const char* license_info    传入参数    license字符串内容
 *          int *packet_limit           传出参数    包数上限
 *          int *sql_limit              传出参数    sql数上限
 *          int *session_limit          传出参数    会话数上限
 *  返回值：
 *      -1 获取失败
 *      0  成功
 *
 ******************************************************/
int dspr_get_limit_extend(const char* license_info,   //  license内容
                        int *packet_limit,          //  每秒包数上限
                        int *sql_limit,             //  每秒sql数上限
                        int *session_limit);        //  会话数上限
#else
int dspr_get_limit_info_int(int n_dev_type, 
                            int *cpu_limit,      //  cpu使用百分比上限
                            int *mem_limit,      //  内存使用百分比上限
                            int *packet_limit,   //  每秒包数上限
                            int *sql_limit,      //  每秒sql数上限
                            int *session_limit); //  会话数上限
#endif

/******************************************************
 *  功能：  将字符串类型的设备类型信息转换为int类型（信息从totalconfig.lst文件中获取）
 *  参数：  
 *          char *s_dev_type 传入参数  string 类型的设备类型信息(需要以\0结尾)
 *  返回值：
 *      -1  获取失败
 *      >0  设备类型对应的int类型
 *
 ******************************************************/
#ifdef ENABLE_DBSCLOUD
int dspr_change_devtype_toint(char* s_dev_type, const char* product_type,char *product_runenv);
#else 
int dspr_change_devtype_toint(char* s_dev_type, const char* product_type);
#endif

/******************************************************
 *  功能：  获取系统cpu使用情况
 *  参数：  
 *          *cpu_total 
 *			*cpu_idle
 *  返回值：
 *          void
 *
 ******************************************************/
void dspr_get_cpu_total_occupy(unsigned long long *cpu_total, unsigned long long *cpu_idle);

#ifdef __cplusplus
}
#endif

#endif
