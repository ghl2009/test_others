#ifndef DSPR_PROCESS_H
#define DSPR_PROCESS_H

#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>

#ifdef __cplusplus
extern "C" {
#endif

int dspr_process_create(int wait,int *status,char* process_name,char* argv[]);

int dspr_pid_get(char* procname,int withpath,int *array,int arrsize);

int dspr_pname_get(int pid,char *procname,int length);

#ifdef __cplusplus
}
#endif

#endif
