#ifndef DSPR_SGA_H
#define DSPR_SGA_H

#include <string.h>
#include <stdio.h>
#include <stdlib.h>

#ifdef __cplusplus
extern "C" {
#endif

#define DSPR_SGA_MAGIC1 0x55aa88ee
#define DSPR_SGA_MAGIC2 0x12345678

#define DSPR_SGA_HEADER_KBSIZE  4

#define DSPR_SGA_BLOCK_HEADER_OFFSET 512
#define DSPR_SGA_BLOCK_MAX   32

/* 注意：在sga内部，所有的大小都以KB为单位 */
typedef struct
{
	unsigned int magic1;
	int id;
	char name[32];
	int total_kbsize; /* 以KB为单位 */
	int free_kbsize; /* 以KB为单位 */
	int header_kbsize; /* 以KB为单位 */
	int block_used;
	unsigned int cursor;  /* 以字节为单位 */
	unsigned int magic2;
}Dspr_Sga_Header;


typedef struct
{
	char name[32];
	int total_kbsize;	//当使用乒乓缓冲时，可用大小为toal_kbsize除以2
	unsigned int offset;
	unsigned int pingpong_enable;	/*0不使用乒乓 1使用乒乓*/
	unsigned int pingping_kbsize;	//(total_size)/2
	unsigned int pingpong_cnt;	/*乒乓缓冲计数*/
	unsigned int pong_offset;	//等于offset + (total_size)/2
	int element_count;
	unsigned int change_count;
	char reserved[32];
}Dspr_Sga_Block_Header; //保持这个结构的大小为96字节

typedef struct 
{
	unsigned int magic1;
	int block_offset;
	int header_offset;
	unsigned int magic2;
}Dspr_Sga_Block_Prefix;

/**************************************************************
	第一层： 基本接口
**************************************************************/

int dspr_sga_create(int mbsize);

int dspr_sga_destroy(int shmid);

void* dspr_sga_attach(int shmid);

int dspr_sga_detach(void* shm_addr);


/**************************************************************
	第二层： 按名称管理
**************************************************************/
int dspr_sga_init(int shmid,int mbsize,int id,char *name);

int dspr_sga_find(int id,char *name);


typedef int(*sga_enum_cb)(Dspr_Sga_Header *sga_header,void *param);
int dspr_sga_enum(sga_enum_cb enum_cb,void *param);


int dspr_sga_info();


/**************************************************************
	第三层： 内部划分管理
**************************************************************/
int dspr_sga_block_register(void* shm_addr,char *name,int kbsize,int pingpong_enable);

//当该block是乒乓缓冲时不能直接使用块儿的起始地址。需要调用其它函数获得当前正在使用的乒乓缓冲地址
void *dspr_sga_block_find(void* shm_addr,char *name);

//获得正在使用的乒乓缓冲起始地址
void *dspr_sga_block_pingpong_inuse(void *pblock);

//获得没在使用的乒乓缓冲起始地址
void *dspr_sga_block_pingpong_nouse(void *pblock);

//更新乒乓缓冲计数
int dspr_sga_block_pingpong_change(void *pblock);

Dspr_Sga_Block_Header *dspr_sga_block_header(void *pblock);

void *dspr_sga_address(void *pblock);

#ifdef __cplusplus
}
#endif

#endif
