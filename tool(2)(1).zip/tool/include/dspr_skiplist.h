#ifndef DSPR_SKIPLIST_H
#define DSPR_SKIPLIST_H

#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <dirent.h>

#ifdef __cplusplus
extern "C" {
#endif

#define DSPR_SKIPLIST_MAX_LEVEL  32
#define DSPR_SKIPLIST_MAX_KEY    0xffffffffffffffff

//节点  
typedef struct Dspr_Slist_Node_s
{
	unsigned long long int key;
	void* value;
	int level;
	struct Dspr_Slist_Node_s *forward[1];  
}Dspr_Slist_Node;

//跳表
typedef struct
{
	int level;
	int size;
	Dspr_Slist_Node *header;  
	Dspr_Slist_Node *tailer;  
}Dspr_Skiplist;

Dspr_Skiplist* dspr_skiplist_create();

int dspr_skiplist_destroy(Dspr_Skiplist *sl,int free_value);

int dspr_skiplist_insert(Dspr_Skiplist *sl,unsigned long long int key,void* value);

int dspr_skiplist_delete(Dspr_Skiplist *sl,unsigned long long int key,int free_value);

void* dspr_skiplist_find(Dspr_Skiplist *sl,unsigned long long int key);

void dspr_skiplist_enum(Dspr_Skiplist *sl,int(*enum_cb)(unsigned long long int key,void *value,void *param),void *param);

void dspr_skiplist_print(Dspr_Skiplist *sl);

#ifdef __cplusplus
}
#endif

#endif
