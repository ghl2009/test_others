
#ifdef __cplusplus
extern "C" {
#endif

#ifndef DSPR_STRING_H
#define DSPR_STRING_H

#include <ctype.h>
#ifdef WIN32
#define snprintf _snprintf
#define strcasecmp(str1,str2) stricmp(str1,str2)
#define strncasecmp(str1,str2,len) strnicmp(str1,str2,len)
#else
#define stricmp(str1,str2) strcasecmp(str1,str2)
#define strnicmp(str1,str2,len) strncasecmp(str1,str2,len)
#endif

/**************************************************************************************************/
/**
 *\defgroup string 字符串
 *
 **************************************************************************************************/

/**************************************************************************************************/
/**
 *\defgroup string_base 基本函数
 *\ingroup string
 **************************************************************************************************/

/**
 *\ingroup string_base
 *\param[in] *pdata 字符串指针
 *\param[in] *array 将分割完的字符串放入字符数组
 *\param[in] num    最多分割次数
 *\param[in] *sep   分隔符
 *\ 分割字符串，分隔符sep的每一个字符都是一个分隔符，例如" \r"
 */
int dspr_str_split(char *pdata,char *array[],int num,char *sep);

/**
 *\ingroup string_base
 *\brief 去掉字符串左侧空白
 *\param[in] *pdata 字符串指针
 */
char *dspr_str_ltrim(char *pdata);
/**
 *\ingroup string_base
 *\brief 去掉字符串右侧空白
 *\param[in] *pdata 字符串指针
 */
char *dspr_str_rtrim(char *pdata);
/**
 *\ingroup string_base
 *\brief 去掉字符串所有空白
 *\param[in] *pdata 字符串指针
 */
char *dspr_str_trim(char *pdata);

/**
 *\ingroup string_base
 * @brief 利用指定字符串替换源字符串中的指定子字符串
 * @param src 源字符串
 * @param str_src 待替换子字符串
 * @param str_des 目标字符串
 * @retval 0 成功
 * @retval -1 失败
 */
int dspr_str_replace(char* src,char* str_src, char* str_des);

/**
 *\ingroup string_base
 * @brief 翻转指定子字符串
 * @param s 源字符串
 * @retval 翻转后的字符串 
 */
char* dspr_str_reverse(char* s);

/**
 *\ingroup string_base
 * @brief 检测指定字符是否为数字字符串
 * @param src 待检测字符
 * @param len 字符串长度
 * @retval 0 匹配
 * @retval -1 不匹配
 */
int dspr_str_isdigits(char* src, int len);

/**
 *\ingroup string_base
 * @brief 把数字转为二进制格式的字符串
 * @param digi 数字 
 * @param format 转化的格式
 * @param output 输出缓冲区
 * @param size 输出缓冲区长度
 */
char *dspr_str_hextobin(unsigned long digi,char *format,char *output,int size);

/**
 *\ingroup string_base
 * @brief 把二进制格式的字符串转为数字
 * @param binstr 二进制格式的字符串
 */
unsigned long dspr_str_bintohex(char *binstr);

/**
 *\ingroup string_base
 * @brief 过滤字符串
 * @param data 字符串
 * @param c1 需要过滤的字符
 * @param c2 目的字符
 */
int dspr_str_filter(char *data,char c1,char c2);


unsigned long int dspr_number_pow(unsigned char a1,unsigned char a2);

#ifdef WIN32
char *strtok_r(char *s, const char *delim, char **save_ptr); 
#endif

void dspr_hex_print(const char *info,const unsigned char *buf,int len);

void dspr_safe_print(const char *info,const char *buf,int len);

int dspr_ipaddr_parse(char *pipaddr,unsigned int *pbottom,unsigned int *ptop);


int dspr_str_get_sub(char *str,int start,int end,char *substr);

/**
 *\ingroup string_base
 * @brief 从指定位置和范围替换字符串，如果没有包围符 '\'',则会自动在两头添加包围符
 * @param str 字符串
 * @param start 需要替换的字符的开始位置
 * @param end 需要替换的字符的结束位置
 * @param substr 用来替换的字符串
 * @param length 用来替换的字符串的长度
 */
int dspr_str_replace_sub(char *str,int start,int end,char *substr,int length);


int dspr_str_toupper(char *text,int size);
int dspr_str_tolower(char *text,int size);

#endif

#ifdef __cplusplus
}
#endif
