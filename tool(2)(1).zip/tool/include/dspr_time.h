#ifndef DSPR_TIME_H
#define DSPR_TIME_H

#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>

#ifdef __cplusplus
extern "C" {
#endif

void dspr_time_localtime(time_t time, long timezone, struct tm *tm_time);

int dspr_time_get(char *currtime);

#ifdef __cplusplus
}
#endif

#endif
