#ifndef DSPR_UTILS_H
#define DSPR_UTILS_H

#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <dirent.h>

#ifdef __cplusplus
extern "C" {
#endif

void dspr_hex_print(const char *info,const unsigned char *buf,int len);

void dspr_safe_print(const char *info,const char *buf,int len);

int dspr_ipaddr_parse(char *pipaddr,unsigned int *pbottom,unsigned int *ptop);


#ifdef __cplusplus
}
#endif

#endif
