
#ifndef DSPR_BSLHASH_H
#define DSPR_BSLHASH_H

/***************************************************************
 *  Based Shared Memory Hash with List
 **************************************************************/

#include <stdio.h>
#include <stdint.h>
#ifndef WIN32
#include <pthread.h>
#endif

#ifdef __cplusplus
extern "C" {
#endif

#define BSLHASH_MAX_GROUP  32  //最大组数
#define BSLHASH_ALIGN 16  //字节对齐的大小
#define BSLHASH_MAGIC 0x55aa77cc  //BSLHASH的魔法数

#define BSLHASH_NODE_MAGIC 0x55aa
#define BSLHASH_NODE_FLAG_USED 0x0001

#define BSLHASH_KEY_TYPE_NUMBER  0  //数字模式，这个也是默认模式
#define BSLHASH_KEY_TYPE_STRING  1  //字符串模式

#define BSLHASH_KEY_MAX_LENGTH 20   //字符串模式下关键字的最大长度

#define BSLHASH_RETCODE_DELETE_NODE -101

#define BSLHASH_ERROR_NO_FREE_NODE	-21

#pragma pack(1)

typedef struct
{
	char name[16];
	int total_kbsize;//总的大小，以K为单位
	int slot_number;
	int group_number;
	int key_type;//关键字的类型
	int user_data_size;//用户数据的大小
	int lock_off;
	int verbose;
}Bslhash_Config;

typedef struct
{
	uint32_t key; 
	int count;
	uint32_t head;
	uint32_t tail;
}Bslhash_Group_List;

typedef struct
{
	//基本信息
	uint32_t magic;//用来判断是否已经初始化
	Bslhash_Config config;
	uint32_t total_size;
	uint32_t node_size;

	//槽的相关变量
	uint32_t slot_offset;
	uint32_t slot_size;
	
	//组的相关变量
	uint32_t group_offset;
	uint32_t group_size;
	int group_max_node;
	int group_insert_count;
	int group_clean_count;

	//节点的分配/释放管理
	uint32_t idle_offset;
	uint32_t idle_size;
	uint32_t idle_cursor;
#ifndef WIN32	
	pthread_spinlock_t lock_idle;
#endif

	//节点区
	int node_offset;
	int node_area_size;
	uint32_t total_node_num;
	int lock_on;
#ifndef WIN32
	pthread_rwlock_t lock_node;
#endif
	int node_count;  //节点数
}Bslhash_t;

typedef struct
{
	uint32_t magic;
	uint16_t flag;
	uint16_t group_id;
    unsigned long long key;
	uint32_t next;
	uint32_t group_prep;
	uint32_t group_next;
}Bslhash_Node_Header;

typedef struct
{
	uint32_t magic;
	uint16_t flag;
	uint16_t group_id;
    char key[BSLHASH_KEY_MAX_LENGTH];
	uint32_t hash_value;
	uint32_t next;
	uint32_t group_prep;
	uint32_t group_next;
}Bslhash_Node_HeaderS;

#pragma pack()

/**
 *\ingroup tis_utils
 *\brief 地址对齐
 */
#define MEMORY_ALIGN(size, boundary) \
    (((size) + ((boundary) - 1)) & ~((boundary) - 1))
    
Bslhash_t *Bslhash_Init(uint8_t* start_addr,Bslhash_Config *config,char *errbuf);

int Bslhash_Destroy(Bslhash_t *rslhash);

int Bslhash_Clear(Bslhash_t *bslhash);

int Bslhash_Insert(Bslhash_t *rslhash,unsigned long long key,void *data,int group);

void* Bslhash_Find(Bslhash_t *rslhash,unsigned long long key);

int Bslhash_Delete(Bslhash_t *rslhash,unsigned long long key);

int Bslhash_Clean_Group(Bslhash_t *bslhash,int group_id);

int Bslhash_Count_Group(Bslhash_t *bslhash,int group_id);

int Bslhash_Group_SetKey(Bslhash_t *bslhash,unsigned int key);

typedef void (*bslhash_enum_cb_t)(FILE* fp,unsigned long long key,void *data);

void Bslhash_Enum(Bslhash_t *bslhash,int enum_type,FILE* fp,bslhash_enum_cb_t cb);

typedef void (*bslhash_enumex_cb_t)(unsigned long long key,void *data,void *param);

void Bslhash_EnumEx(Bslhash_t *bslhash,int enum_type,bslhash_enumex_cb_t cb,void *param);

typedef int (*bslhash_enum_delete_cb_t)(unsigned long long key,void *data);

int Bslhash_Enum_With_Delete(Bslhash_t *bslhash,bslhash_enum_delete_cb_t cb);

int Bslhash_Count(Bslhash_t *rslhash);

int Bslhash_Max_Count(Bslhash_t *bslhash);

uint32_t Bslhash_Cal_Size(int data_size, int node_count);


inline uint8_t *Bslhash_Slot_Offset(Bslhash_t *bslhash,uint32_t slot_id)
{
	return ((uint8_t*)(bslhash) + bslhash->slot_offset + (slot_id*sizeof(uint32_t)));
}

inline Bslhash_Group_List* Bslhash_Group_Offset(Bslhash_t *bslhash,uint32_t group_id)
{
	return (Bslhash_Group_List*)((uint8_t*)bslhash + bslhash->group_offset + (group_id*sizeof(Bslhash_Group_List)));
}

inline Bslhash_Node_Header* Bslhash_Node_Offset(Bslhash_t *bslhash,uint32_t node_id)
{
	if(node_id == 0)
		return NULL;
	return (Bslhash_Node_Header*)((uint8_t*)bslhash + bslhash->node_offset + ((node_id-1)*bslhash->node_size));
}

#ifdef __cplusplus
}
#endif

#endif
