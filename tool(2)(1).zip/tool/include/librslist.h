
#ifndef DSPR_RSLIST_H
#define DSPR_RSLIST_H

/***************************************************************
 *  Rotate SkipList
 **************************************************************/

#include <stdio.h>
#include <stdint.h>
#ifndef WIN32
#include <pthread.h>
#endif

#ifdef __cplusplus
extern "C" {
#endif

#define RSLIST_MAX_SLOT  16
#define RSLIST_MAX_LEVEL 16 //最大层数  
#define RSLIST_ALIGN 16

#define RSLIST_MAGIC 0x55aa77cc

#define RSLIST_SLOT_MAGIC 0x55aa

#define RSLIST_NODE_MAGIC 0x55aa

#define RSLIST_SLOT_FLAG_REST 0x0001
#define RSLIST_SLOT_FLAG_INSERT 0x0001

#define RSLIST_NODE_FLAG_USED 0x00000001

#pragma pack(1)

typedef struct
{
	uint32_t total_kbsize;//总的大小，以K为单位
	uint32_t max_slot;//最大槽数,如果是2，则就是乒乓机制
	uint32_t user_data_size;//用户数据的大小
	uint16_t verbose;
	uint16_t lock;
}Rslist_Config;

typedef struct
{
	uint16_t id;
	uint16_t magic;
#ifndef WIN32
	pthread_spinlock_t spinlock;
#endif	
	int level;
	uint32_t begin;
	uint32_t end;
	uint32_t node_count;
}Rslist_Slot;

typedef struct
{
	uint32_t magic;//用来判断，tis是否已经初始化
	Rslist_Config config;
	uint32_t total_size;
	uint32_t node_size;
	
#ifndef WIN32
	pthread_spinlock_t lock_rotate;
#endif
	uint32_t curr_rester;//当前休息者
	uint32_t curr_inserter;//当前可被插入者
	
	uint32_t idle_offset;
	uint32_t idle_size;
	uint32_t idle_cursor;
#ifndef WIN32	
	pthread_spinlock_t lock_idle;
#endif

	uint32_t node_offset;
	uint32_t total_node_num;
	uint32_t slot_node_num;

	Rslist_Slot slot[RSLIST_MAX_SLOT];

	uint32_t node_count;	
}Rslist_t;

typedef struct Rslist_Node_Header
{
	uint32_t magic;
	uint32_t flag;
    unsigned long long key;
	uint32_t forward[RSLIST_MAX_LEVEL];
	uint32_t backward;
}Rslist_Node_Header;

#pragma pack()

/**
 *\ingroup tis_utils
 *\brief 地址对齐
 */
#define MEMORY_ALIGN(size, boundary) \
    (((size) + ((boundary) - 1)) & ~((boundary) - 1))
    
Rslist_t *Rslist_Init(uint8_t* start_addr,Rslist_Config *config,char *errbuf);

int Rslist_Destroy(Rslist_t *rslist);

int Rslist_Insert(Rslist_t *rslist,unsigned long long key,void *data);

void* Rslist_Find(Rslist_t *rslist,unsigned long long key);

int Rslist_Delete(Rslist_t *rslist,unsigned long long key);

typedef int (*rslist_enum_cb_t)(FILE* fp,unsigned long long key,void *data);

void Rslist_Enum(Rslist_t *rslist,FILE* fp,rslist_enum_cb_t cb);

int Rslist_Count(Rslist_t *rslist);

int Rslist_Rester_Get(Rslist_t *rslist);


inline Rslist_Node_Header* Rslist_Node_Offset(Rslist_t *rslist,uint32_t node_id)
{
	return (Rslist_Node_Header*)((uint8_t*)rslist + rslist->node_offset + ((node_id-1)*(rslist->node_size)));
}

inline int Rslist_Node_Invalid(Rslist_t *rslist,uint32_t node_id,Rslist_Node_Header *node)
{
	if(node_id > rslist->total_node_num)
		return -1;
	if(NULL == node)
		return -2;
	if(node->magic != RSLIST_NODE_MAGIC)
		return -3;
	if(0 == (node->flag & RSLIST_NODE_FLAG_USED))
		return -4;
	return 0;
}

#ifdef __cplusplus
}
#endif

#endif
