#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <errno.h>
#include <time.h>
#include <sys/time.h>
#include <unistd.h>
#include <pthread.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <linux/socket.h>
#include <netinet/in.h>
#include <netdb.h>
#include <linux/if.h>
#include <linux/if_ether.h>
#include <arpa/inet.h>
#include <linux/ip.h>
//#include <linux/tcp.h>
#include <netinet/tcp.h>

#include <pcap.h>
#include <string.h>

#include "librslist.h"

#include "config.h"
#include "meter_broadcast.h"
#include "meter_utils.h"
#include "protocol_analysis.h"

#ifdef __cplusplus
extern "C" {
#endif

struct stat_cb_param_s
{
	int count;
};

static pcap_dumper_t *global_dumpfp = NULL;

//全局变量
static Meter_Broadcast_Global _Global;

//打包规则
static Meter_Broadcast_Rule _Rule;

//文件缓存
static Meter_Broadcast_Cache _Cache;

static dspr_hash_t *_Sess_Hash = NULL;
static dspr_hash_t *_Discard_Hash = NULL;
static Rslist_t *_Server_Rslist = NULL;
static Rslist_t *_ServerIp_Rslist = NULL;

//广播统计
static Meter_Broadcast_Stat _Stat;

static unsigned int _total_npack = 0;
static unsigned long long int _total_nsize = 0;
static unsigned int _total_loop = 0;

static int _server_count = 1;

//局部函�?
static int argument_parse(int argc,char *argv[]);


static void packet_print(Meter_Packet_Info *pkt_info)
{
	char clientBuf[20],serverBuf[20];
	unsigned int srcip = 0,dstip = 0;

	memset(clientBuf,0,sizeof(clientBuf));
	memset(serverBuf,0,sizeof(serverBuf));
	srcip = pkt_info->ipv4_header.ip_srcaddr;
	dstip = pkt_info->ipv4_header.ip_destaddr;
	srcip = DBFW_HTON32(srcip);
	dstip = DBFW_HTON32(dstip);
	meter_iptos(srcip,clientBuf);
	meter_iptos(dstip,serverBuf);
	if(pkt_info->direction == mb_pkt_dct_request)
	{
		printf("Meter Packet: %s:%-5d ---> %s:%-5d  len:%-4d  seq:%-7u  ack:%-7u\n",
			clientBuf,pkt_info->tcp_header.source_port,
			serverBuf,pkt_info->tcp_header.dest_port,pkt_info->data_size,
			pkt_info->tcp_header.sequence,pkt_info->tcp_header.acknowledge);
	}
	else if(pkt_info->direction == mb_pkt_dct_response)
	{
		printf("Meter Packet: %s:%-5d <--- %s:%-5d  len:%-4d  seq:%-7u  ack:%-7u\n",
			serverBuf,pkt_info->tcp_header.dest_port,
			clientBuf,pkt_info->tcp_header.source_port,pkt_info->data_size,
			pkt_info->tcp_header.acknowledge,pkt_info->tcp_header.sequence);
	}
}

static void session_time_stat_cb(dspr_hash_node_t *node,void *param)
{
	Meter_Session_HashValue *mhvalue = (Meter_Session_HashValue*)dspr_hash_node_get_value(node);
	int elapsed = 0;
	int start_ms = 0,end_ms = 0;
	
	do{
		end_ms = mhvalue->end.tv_usec / 1000;
		start_ms = mhvalue->start.tv_usec / 1000;
		elapsed = (mhvalue->end.tv_sec - mhvalue->start.tv_sec)*1000 + (end_ms - start_ms);
		_Stat.total_session_time += elapsed;
		if(mhvalue->duplicate_mirror)
		{
			_Stat.duplicate_session++;
			_Stat.duplicate_packet += mhvalue->total_packet;
			_Stat.duplicate_size += mhvalue->total_size;
		}
		mhvalue = mhvalue->next;
	}
	while(mhvalue);
	if(param == NULL || param != NULL)
	return;
}

static void session_stat_cb(dspr_hash_node_t *node,void *param)
{
	Meter_Session_HashValue *mhvalue = (Meter_Session_HashValue*)dspr_hash_node_get_value(node);
	Meter_Session_HashValue *mhheader = mhvalue;
	Meter_Server_Listen_Value servertcp,*pserver = NULL;
	Meter_Server_Ip_Value *pserverip = NULL,serverip;
	unsigned int key = 0;
	unsigned long long llkey = 0;
	int elapsed = 0;

	if(NULL == mhvalue)
	{
		return;
	}

	do{
//		memset(clientBuf,0,sizeof(clientBuf));
//		memset(serverBuf,0,sizeof(serverBuf));
//		meter_iptos(mhvalue->key.client_ip,clientBuf);
//		meter_iptos(mhvalue->key.server_ip,serverBuf);

		mhvalue->end.tv_usec /= 1000;
		mhvalue->start.tv_usec /= 1000;
		elapsed = (mhvalue->end.tv_sec - mhvalue->start.tv_sec)*1000 + (mhvalue->end.tv_usec - mhvalue->start.tv_usec);

		if(mhvalue->key.proto == 0x0800)
		{
			printf("Meter Session: %-3d  %s:%-5d ---> %s:%-5d  Total Packet:%-6d  Total Size:%-6d  Elapsed:%u ms  %s.%s %s\n",
				((struct stat_cb_param_s*)param)->count++,
				mhvalue->key.client_ip_str,mhvalue->key.client_port,
				mhvalue->key.server_ip_str,mhvalue->key.server_port,
				mhvalue->total_packet,mhvalue->total_size,
				elapsed,
				(mhvalue->syn_flag)?"Syn":"NoConnect",
				(mhvalue->fin_flag)?"Fin":"NoEnd",
				mhvalue->duplicate_mirror?"Duplicate Mirror":"");
		}else{
					printf("Meter Session: %-3d  %02x%02x:%02x%02x:%02x%02x:%02x%02x:%02x%02x:%02x%02x:%02x%02x:%02x%02x:%-5d ---> %02x%02x:%02x%02x:%02x%02x:%02x%02x:%02x%02x:%02x%02x:%02x%02x:%02x%02x:%-5d  Total Packet:%-6d  Total Size:%-6d  Elapsed:%u ms  %s.%s %s\n",
				((struct stat_cb_param_s*)param)->count++,
				mhvalue->key.client_ip_str[0],mhvalue->key.client_ip_str[1],mhvalue->key.client_ip_str[2],mhvalue->key.client_ip_str[3],mhvalue->key.client_ip_str[4],mhvalue->key.client_ip_str[5],mhvalue->key.client_ip_str[6],mhvalue->key.client_ip_str[7],
				mhvalue->key.client_ip_str[8],mhvalue->key.client_ip_str[9],mhvalue->key.client_ip_str[10],mhvalue->key.client_ip_str[11],mhvalue->key.client_ip_str[12],mhvalue->key.client_ip_str[13],mhvalue->key.client_ip_str[14],mhvalue->key.client_ip_str[15],
				mhvalue->key.client_port,
				mhvalue->key.server_ip_str[0],mhvalue->key.server_ip_str[1],mhvalue->key.server_ip_str[2],mhvalue->key.server_ip_str[3],mhvalue->key.server_ip_str[4],mhvalue->key.server_ip_str[5],mhvalue->key.server_ip_str[6],mhvalue->key.server_ip_str[7],
				mhvalue->key.server_ip_str[8],mhvalue->key.server_ip_str[9],mhvalue->key.server_ip_str[10],mhvalue->key.server_ip_str[11],mhvalue->key.server_ip_str[12],mhvalue->key.server_ip_str[13],mhvalue->key.server_ip_str[14],mhvalue->key.server_ip_str[15],
				mhvalue->key.server_port,
				mhvalue->total_packet,mhvalue->total_size,
				elapsed,
				(mhvalue->syn_flag)?"Syn":"NoConnect",
				(mhvalue->fin_flag)?"Fin":"NoEnd",
				mhvalue->duplicate_mirror?"Duplicate Mirror":"");	
		}
		mhvalue = mhvalue->next;
	}
	while(mhvalue);

	mhvalue = mhheader;
	//统计服务器信�?
	if(_Server_Rslist)
	{
		key = DBFW_HTON32(mhvalue->key.server_ip);
		llkey = key;
		llkey <<= 32;
		llkey += mhvalue->key.server_port;
		pserver = (Meter_Server_Listen_Value*)Rslist_Find(_Server_Rslist,llkey);
		if(pserver)
		{
			pserver->total_packet += mhvalue->total_packet;
			pserver->total_size += mhvalue->total_size;
			pserver->client_number++;
		}
		else
		{
			memset(&servertcp,0,sizeof(Meter_Server_Listen_Value));
			servertcp.proto = mhvalue->key.proto;
			servertcp.ipaddr = mhvalue->key.server_ip;
			memcpy(servertcp.ipstr,mhvalue->key.server_ip_str,sizeof(servertcp.ipstr));
			servertcp.port = mhvalue->key.server_port;
			servertcp.total_packet = mhvalue->total_packet;
			servertcp.total_size = mhvalue->total_size;
			servertcp.client_number = 1;
			Rslist_Insert(_Server_Rslist,llkey,&servertcp);
		}
	}

	if(_ServerIp_Rslist)
	{
		key = DBFW_HTON32(mhvalue->key.server_ip);
		pserverip = (Meter_Server_Ip_Value*)Rslist_Find(_ServerIp_Rslist,key);
		if(pserverip)
		{
			pserverip->total_packet += mhvalue->total_packet;
			pserverip->total_size += mhvalue->total_size;
			pserverip->client_number++;
			pserverip->port_number++;
		}
		else
		{
			memset(&serverip,0,sizeof(serverip));
			serverip.total_packet = mhvalue->total_packet;
			serverip.total_size = mhvalue->total_size;
			serverip.client_number = 1;
			serverip.port_number = 1;
			Rslist_Insert(_ServerIp_Rslist,key,&serverip);
		}
	}

/*
	printf("Meter Session: Sequence(Start:%-8u End:%-8u Step:%u)  Acknowledge(Start:%-8u End:%-8u Step:%u)\n",
		mhvalue->start_sequence,mhvalue->end_sequence,
		mhvalue->end_sequence - mhvalue->start_sequence,
		mhvalue->start_acknowledge,mhvalue->end_acknowledge,
		mhvalue->end_acknowledge - mhvalue->start_acknowledge);
*/
}

static void session_stat(dspr_hash_t *sess_hash)
{
	struct stat_cb_param_s param;
	param.count = 1;
	if(sess_hash == NULL)
		return;
	dspr_hash_enum(sess_hash,session_stat_cb,&param);
}

static void session_create_key(Meter_Packet_Info *pkt_info,Meter_Session_HashKey *mhkey)
{
	memset(mhkey,0,sizeof(Meter_Session_HashKey));
	mhkey->proto = pkt_info->ethernet.type;

	if(pkt_info->ethernet.type == 0x0800)
	{
		if(pkt_info->direction == mb_pkt_dct_request)
		{
			mhkey->client_ip = pkt_info->ipv4_header.ip_srcaddr;
			mhkey->client_port = pkt_info->tcp_header.source_port;
			mhkey->server_ip = pkt_info->ipv4_header.ip_destaddr;			
			mhkey->server_port = pkt_info->tcp_header.dest_port;
		}
		else
		{
			mhkey->client_ip = pkt_info->ipv4_header.ip_destaddr;
			mhkey->client_port = pkt_info->tcp_header.dest_port;
			mhkey->server_ip = pkt_info->ipv4_header.ip_srcaddr;
			mhkey->server_port = pkt_info->tcp_header.source_port;
		}
		mhkey->client_ip = DBFW_HTON32(mhkey->client_ip);
		mhkey->server_ip = DBFW_HTON32(mhkey->server_ip);
		meter_iptos(mhkey->client_ip,(char *)mhkey->client_ip_str);
		meter_iptos(mhkey->server_ip,(char *)mhkey->server_ip_str);
	}else{
		if(pkt_info->direction == mb_pkt_dct_request)
		{
			mhkey->client_ip = Dbfw_hash_xor_key16(pkt_info->ipv6_header.ip_srcaddr);
			memcpy(mhkey->client_ip_str,pkt_info->ipv6_header.ip_srcaddr,16);
			mhkey->client_port = pkt_info->tcp_header.source_port;
			mhkey->server_ip = Dbfw_hash_xor_key16(pkt_info->ipv6_header.ip_destaddr);
			memcpy(mhkey->server_ip_str,pkt_info->ipv6_header.ip_destaddr,16);
			mhkey->server_port = pkt_info->tcp_header.dest_port;
		}
		else
		{
			mhkey->client_ip = Dbfw_hash_xor_key16(pkt_info->ipv6_header.ip_destaddr);
			memcpy(mhkey->client_ip_str,pkt_info->ipv6_header.ip_destaddr,16);
			mhkey->client_port = pkt_info->tcp_header.dest_port;
			mhkey->server_ip = Dbfw_hash_xor_key16(pkt_info->ipv6_header.ip_srcaddr);
			memcpy(mhkey->server_ip_str,pkt_info->ipv6_header.ip_srcaddr,16);
			mhkey->server_port = pkt_info->tcp_header.source_port;
		}
	}
	return;
}

static void sequence_update(Meter_Packet_Info *pkt_info,Meter_Session_HashValue *mhvalue)
{
	if(NULL == pkt_info || NULL == mhvalue)
	{
		return;
	}
	if(pkt_info->direction == mb_pkt_dct_request)
	{
		mhvalue->end_sequence = pkt_info->tcp_header.sequence + pkt_info->data_size;
		mhvalue->end_acknowledge = pkt_info->tcp_header.acknowledge;
	}
	else if(pkt_info->direction == mb_pkt_dct_response)
	{
		mhvalue->end_sequence = pkt_info->tcp_header.acknowledge;
		mhvalue->end_acknowledge = pkt_info->tcp_header.sequence + pkt_info->data_size;
	}
	mhvalue->step_sequence = mhvalue->end_sequence - mhvalue->start_sequence;
	mhvalue->step_acknowledge = mhvalue->end_acknowledge - mhvalue->start_acknowledge;

/*
	printf("sequence_update  step_sequence:%u  start_sequence:%u  end_sequence:%u  step_acknowledge:%u  start_acknowledge:%u  end_acknowledge:%u\n",
			mhvalue->step_sequence,mhvalue->start_sequence,mhvalue->end_sequence,
			mhvalue->step_acknowledge,mhvalue->start_acknowledge,mhvalue->end_acknowledge);
*/
}

static Meter_Session_HashValue *session_register(dspr_hash_t *sess_hash,Meter_Packet_Hdr *header,Meter_Packet_Info *pkt_info)
{
	Meter_Session_HashKey mhkey;
	Meter_Session_HashValue *mhvalue = NULL,*mhnext = NULL;

	if(sess_hash == NULL || header == NULL || pkt_info == NULL)
		return NULL;

	//放入哈希�?
	session_create_key(pkt_info,&mhkey);

//	hex_print("Meter_Hash_Find ",(const unsigned char*)&mhkey,sizeof(Meter_Session_HashKey));
	mhvalue = (Meter_Session_HashValue*)dspr_hash_find(sess_hash,&mhkey,sizeof(Meter_Session_HashKey));
	if(NULL == mhvalue)
	{
		mhvalue = (Meter_Session_HashValue*)malloc(sizeof(Meter_Session_HashValue));
		if(mhvalue)
		{
			memset(mhvalue,0,sizeof(Meter_Session_HashValue));
			memcpy(&(mhvalue->key),&mhkey,sizeof(Meter_Session_HashKey));
			mhvalue->start.tv_sec = header->sec;
			mhvalue->start.tv_usec = header->usec;
			mhvalue->end.tv_sec = header->sec;
			mhvalue->end.tv_usec = header->usec;
			dspr_hash_insert(sess_hash,&(mhvalue->key),sizeof(Meter_Session_HashKey),mhvalue,0,0);
		}
	}
	if(NULL == mhvalue)
	{
		return NULL;
	}

	if(mhvalue->session_over)
	{
		mhvalue = mhvalue->tail;
	}
	else
	{
		//这表明客户端的端口被重用了，并且访问的还是同样的数据库，因此在这里，所有相同的客户端ip,port的会话形成一个链�?
		if(pkt_info->tcp_header.syn && mhvalue->fin_flag)
		{
			mhvalue->session_over = 1;
			mhnext = (Meter_Session_HashValue*)malloc(sizeof(Meter_Session_HashValue));
			if(mhnext == NULL)
			{
				return NULL;
			}
			memset(mhnext,0,sizeof(Meter_Session_HashValue));
			memcpy(&(mhnext->key),&mhkey,sizeof(Meter_Session_HashKey));
			mhnext->start.tv_sec = header->sec;
			mhnext->start.tv_usec = header->usec;
			mhnext->end.tv_sec = header->sec;
			mhnext->end.tv_usec = header->usec;
			if(mhvalue->tail == NULL)
			{
				mhvalue->next = mhnext;
			}
			else
			{
				mhvalue->tail->next = mhnext;
			}
			mhvalue->tail = mhnext;
			mhvalue = mhnext;
		}
	}
	if(NULL == mhvalue)
	{
		return NULL;
	}

	if(pkt_info->tcp_header.syn)
	{
		mhvalue->syn_flag++;
		header->syn = 1;
	}
	else
	{
		if(mhvalue->syn_flag == 2)
		{
			mhvalue->syn_flag++;
			header->syn = 1;
		}
	}

	if(pkt_info->tcp_header.fin)
	{
		mhvalue->fin_flag++;
		header->fin = 1;
	}
	else
	{
		if(mhvalue->fin_flag == 2)
		{
			mhvalue->fin_flag++;
			header->fin = 1;
		}
	}

	mhvalue->total_packet++;
	mhvalue->total_size += header->len;//pkt_size;

	mhvalue->end.tv_sec = header->sec;
	mhvalue->end.tv_usec = header->usec;

	//检查有没有重复镜像
	if(pkt_info->tcp_header.ack
		&& pkt_info->tcp_header.syn == 0
		&& pkt_info->tcp_header.fin == 0
		&& pkt_info->tcp_header.psh == 0
		&& pkt_info->data_size == 0)
	{
		if(mhvalue->ack_sequence == 0)
		{
			mhvalue->ack_sequence = pkt_info->tcp_header.sequence;
			mhvalue->ack_acknowledge = pkt_info->tcp_header.acknowledge;
		}
		else
		{
			if(mhvalue->ack_sequence == pkt_info->tcp_header.sequence
			&& mhvalue->ack_acknowledge == pkt_info->tcp_header.acknowledge)
			{
				mhvalue->duplicate_mirror = 1;
			}
		}
	}

	/* 对于syn包和fin包，不参与sequence �? acknowledge 的统�? */
	if(header->syn || header->fin)
	{
		return mhvalue;
	}

	if(pkt_info->direction == mb_pkt_dct_request)
	{
		if(mhvalue->start_sequence == 0)
		{
			mhvalue->start_sequence = pkt_info->tcp_header.sequence;
		}
		mhvalue->end_sequence = pkt_info->tcp_header.sequence;
		if(mhvalue->start_acknowledge == 0)
		{
			mhvalue->start_acknowledge = pkt_info->tcp_header.acknowledge;
		}
		mhvalue->end_acknowledge = pkt_info->tcp_header.acknowledge;
	}
	else if(pkt_info->direction == mb_pkt_dct_response)
	{
		if(mhvalue->start_sequence == 0)
		{
			mhvalue->start_sequence = pkt_info->tcp_header.acknowledge;
		}
		mhvalue->end_sequence = pkt_info->tcp_header.acknowledge;
		if(mhvalue->start_acknowledge == 0)
		{
			mhvalue->start_acknowledge = pkt_info->tcp_header.sequence;
		}
		mhvalue->end_acknowledge = pkt_info->tcp_header.sequence;
	}
	return mhvalue;
}

static int server_listen_stat_cb(FILE* fp,unsigned long long key,void *data)
{
	Meter_Server_Listen_Value *server_value = (Meter_Server_Listen_Value*)data;
	char serverTmp[32];
	if(NULL == server_value)
	{
		return -1;
	}
//	memset(serverBuf,0,sizeof(serverBuf));
//	meter_iptos(server_value->ipaddr,serverBuf);
	if(server_value->proto == 0x0800)
	{
		sprintf(serverTmp,"-----%s:%d-----",server_value->ipstr,server_value->port);
	}else{
		sprintf(serverTmp,"-----%02x%02x%02x%02x%02x%02x%02x%02x%02x%02x%02x%02x%02x%02x%02x%02x:%d-----",
			server_value->ipstr[0],server_value->ipstr[1],server_value->ipstr[2],server_value->ipstr[3],server_value->ipstr[4],server_value->ipstr[5],server_value->ipstr[6],server_value->ipstr[7],
			server_value->ipstr[8],server_value->ipstr[9],server_value->ipstr[10],server_value->ipstr[11],server_value->ipstr[12],server_value->ipstr[13],server_value->ipstr[14],server_value->ipstr[15],server_value->port);
	}
	printf("Meter Server Listen: %-3d  %-22s   Client Number:%d  Total Packet:%-6d  Total Size:%-6d\n",
		_server_count++,
		serverTmp,
		server_value->client_number,
		server_value->total_packet,
		server_value->total_size);
	if(fp == NULL || fp != NULL)
	fp = NULL;
	if(key == 0 || key != 0)
	key = 0;
	return 0;
}

static int server_ip_enum_cb(FILE* fp,unsigned long long key,void *data)
{
	Meter_Server_Ip_Value *pserverip = (Meter_Server_Ip_Value*)data;
	char serverBuf[20];
	unsigned int mykey = (unsigned int)key;

	memset(serverBuf,0,sizeof(serverBuf));

	mykey = DBFW_HTON32(mykey);
	meter_iptos(mykey,serverBuf);

	printf("Meter Server IP: %-3d  %-22s   Client Number:%d  Total Packet:%-6d  Total Size:%-6d\n",
		_server_count++,
		serverBuf,
		pserverip->client_number,
		pserverip->total_packet,
		pserverip->total_size);
	if(fp == NULL || fp != NULL)
	fp = NULL;
	return 0;
}

static void server_stat()
{
	if(_Server_Rslist)
	{
		printf("\nMeter Stat: Report Server Listen Info:\n");
		_server_count = 1;
		Rslist_Enum(_Server_Rslist,NULL,server_listen_stat_cb);
	}
	if(_ServerIp_Rslist)
	{
		printf("\nMeter Stat: Report Server Ipaddr Info:\n");
		_server_count = 1;
		Rslist_Enum(_ServerIp_Rslist,NULL,server_ip_enum_cb);
	}
}

static int cache_get_next(Meter_Broadcast_Cache *pcache,Meter_Broadcast_Cache_Control *pctrl,Meter_Packet_Hdr **header,const u_char **pkg_data)
{
	if(pctrl->cursor >= pcache->length)
	{
		return -1;
	}
	*header = (Meter_Packet_Hdr*)(pcache->data + pctrl->cursor);
	pctrl->cursor += sizeof(Meter_Packet_Hdr);
	*pkg_data = pcache->data + pctrl->cursor;
	pctrl->cursor += (*header)->caplen;
	return 0;
}

static int cache_init(Meter_Broadcast_Global *global,Meter_Broadcast_Cache *cache)
{
	int res = 0;
	struct pcap_pkthdr *header = NULL;
	const u_char *pkt_data = NULL;
	Dbfw_EthernetFrame eth_frame;
	Meter_Packet_Info pkt_info;
	Meter_Packet_Hdr pkt_hdr;

	cache->size = global->file_size + 64;
	cache->begin_offset = global->begin_offset;
	cache->data = (u_char*)malloc(cache->size);
	if(NULL == cache->data)
	{
		return -1;
	}
	memset(cache->data,0,cache->size);

	fseek(global->fp_file,0,SEEK_SET);
	fread(cache->data,1,global->begin_offset,global->fp_file);

	cache->length = global->begin_offset;
	fseek(global->fp_file,cache->begin_offset,SEEK_SET);
	while(pcap_next_ex(global->pp_file, &header, &pkt_data) >= 0)
	{
		//解析网络�?
		memset(&eth_frame,0,sizeof(eth_frame));
		memset(&pkt_info,0,sizeof(pkt_info));
		eth_frame.frame_data = (u_char*)pkt_data;
		eth_frame.frame_size = header->len;
		if(meter_mode_all == _Global.mode)
		{
			//放入Cache
			memset(&pkt_hdr,0,sizeof(pkt_hdr));
			pkt_hdr.sec = header->ts.tv_sec;
			pkt_hdr.usec = header->ts.tv_usec;
			pkt_hdr.caplen = header->caplen;
			pkt_hdr.len = header->len;
			memcpy(cache->data+cache->length,&pkt_hdr,sizeof(pkt_hdr));
			cache->length += sizeof(pkt_hdr);
			memcpy(cache->data+cache->length,pkt_data,header->caplen);
			cache->length += header->caplen;
			cache->packet_count++;
			continue;
		}
		res = Dbfw_Protocol_Parse(&eth_frame,&pkt_info,_Rule.server_rule);
		if(res != meter_proto_cs)
		{
			continue;
		}
		if(cache->length + sizeof(struct pcap_pkthdr) + header->caplen > cache->size)
		{
			printf("Meter Error: cache overflow!  max size:%d  current size:%d\n",cache->size,cache->length);
			break;
		}
		//放入Cache
		memset(&pkt_hdr,0,sizeof(pkt_hdr));
		pkt_hdr.sec = header->ts.tv_sec;
		pkt_hdr.usec = header->ts.tv_usec;
		pkt_hdr.caplen = header->caplen;
		pkt_hdr.len = header->len;

		//放入哈希�?
		session_register(_Sess_Hash,&pkt_hdr,&pkt_info);

		memcpy(cache->data+cache->length,&pkt_hdr,sizeof(pkt_hdr));
		cache->length += sizeof(pkt_hdr);
		memcpy(cache->data+cache->length,pkt_data,header->caplen);
		cache->length += header->caplen;
		cache->packet_count++;

	}
	printf("Meter Packet: Total=%d  Size=%d\n",cache->packet_count,cache->length);
	printf("Meter Session: Total=%d\n",dspr_hash_count(_Sess_Hash));
	return 0;
}


static void control_init_cb(dspr_hash_node_t *node,void *param)
{
	dspr_hash_t *sess_hash = (dspr_hash_t *)param;
	Meter_Session_HashValue *mhvalue = (Meter_Session_HashValue*)dspr_hash_node_get_value(node);
	Meter_Session_HashValue *new_mhvalue = NULL;
	if(NULL == mhvalue || NULL == sess_hash)
	{
		return;
	}
	new_mhvalue = (Meter_Session_HashValue*)malloc(sizeof(Meter_Session_HashValue));
	if(new_mhvalue)
	{
		memset(new_mhvalue,0,sizeof(Meter_Session_HashValue));
		memcpy(new_mhvalue,mhvalue,sizeof(Meter_Session_HashValue));
		dspr_hash_insert(sess_hash,&(new_mhvalue->key),sizeof(Meter_Session_HashKey),new_mhvalue,0,0);
	}
}

static int random_discard_init(Meter_Broadcast_Cache_Control *pcontrol)
{
	int ii = 0;
	struct timeval tv;
	unsigned int seed = 0;
	unsigned int offset = 0;

	if(_Global.ramdom_discard <= 0)
	{
		return 0;
	}

	gettimeofday(&tv,NULL);
	seed = tv.tv_sec + tv.tv_usec; //种子为了在短时间内足够随机化，因此把微妙数也加上�?
	srandom(seed);

	for(ii=0;ii<_Global.ramdom_discard;ii++)
	{
		offset = random() % 1000;
		pcontrol->random_discard[offset] = 1;
	}

	return 0;
}

static int meter_broadcast_control_init(Meter_Broadcast_Cache_Control *pcontrol)
{
	int res = 0;

	pcontrol->loop_count = 0;
	pcontrol->curr_npack = 0;
	pcontrol->curr_nsize = 0;
	pcontrol->total_npack = 0;
	pcontrol->total_npack = 0;

	pcontrol->buffer_size = METER_MAX_PKT_BUFFER;
	pcontrol->pkt_buffer = (u_char*)malloc(pcontrol->buffer_size);
	if(!pcontrol->pkt_buffer)
	{
		return -1;
	}

	random_discard_init(pcontrol);

	pcontrol->sess_hash = dspr_hash_new();
	dspr_hash_init(pcontrol->sess_hash,(char*)"SessionHash",4096,NULL,NULL,NULL);

	if(dspr_hash_count(_Sess_Hash) > 0)
	{
		//复制哈希�?
		dspr_hash_enum(_Sess_Hash,control_init_cb,pcontrol->sess_hash);
		//session_stat(pcontrol->sess_hash);
	}
	else
	{
		Meter_Packet_Hdr *header = NULL;
		const u_char *pkt_data = NULL;
		Dbfw_EthernetFrame eth_frame;
		Meter_Packet_Info pkt_info;

		pcontrol->cursor = _Cache.begin_offset;
		while(0 == cache_get_next(&_Cache,pcontrol,&header,&pkt_data))
		{
			memset(pcontrol->pkt_buffer,0,pcontrol->buffer_size);
			memcpy(pcontrol->pkt_buffer,pkt_data,header->caplen);
			eth_frame.frame_data = (u_char*)pcontrol->pkt_buffer;
			eth_frame.frame_size = header->len;
			res = Dbfw_Protocol_Parse(&eth_frame,&pkt_info,_Rule.server_rule);
			if(res != meter_proto_cs)
			{
				continue;
			}
			//放入哈希�?
			session_register(pcontrol->sess_hash,header,&pkt_info);
		}
	}
	return 0;
}

#define PACKET_CHANGE_METHOD1  1
//#define PACKET_CHANGE_METHOD2  1

static unsigned int ipaddr_make(unsigned int ipaddr_in,int id)
{
	unsigned int ipaddr_out = 0;
	unsigned char ipaddr_h1_tmp = 0,ipaddr_h2_tmp = 0,ipaddr_h3_tmp = 0,ipaddr_h4_tmp = 0;
	unsigned char ipaddr_h1 = 0,ipaddr_h2 = 0,ipaddr_h3 = 0,ipaddr_h4 = 0;

	ipaddr_h1_tmp = (ipaddr_in & 0xff000000) >> 24;
	ipaddr_h2_tmp = (ipaddr_in & 0x00ff0000) >> 16;
	ipaddr_h3_tmp = (ipaddr_in & 0x0000ff00) >> 8;
	ipaddr_h4_tmp = (ipaddr_in & 0xff);

	ipaddr_h1 = ipaddr_h1_tmp;
	ipaddr_h4 = ipaddr_h4_tmp;

	if(id < 250)
	{
		ipaddr_h2 = ipaddr_h2_tmp + id;
		ipaddr_h3 = ipaddr_h3_tmp;
		if(ipaddr_h2 == 0)
		{
			ipaddr_h2 = ipaddr_h2_tmp - 1;
		}
		else if(ipaddr_h2 == 0xff)
		{
			ipaddr_h2 = ipaddr_h2_tmp - 2;
		}
	}
	else
	{
		ipaddr_h3 = ipaddr_h3_tmp + id/250;
		if(ipaddr_h3 == 0)
		{
			ipaddr_h3 = ipaddr_h3_tmp - 1;
		}
		else if(ipaddr_h3 == 0xff)
		{
			ipaddr_h3 = ipaddr_h3_tmp - 2;
		}
		ipaddr_h2 = ipaddr_h2_tmp + id%250;
		if(ipaddr_h2 == 0)
		{
			ipaddr_h2 = ipaddr_h2_tmp - 1;
		}
		else if(ipaddr_h2 == 0xff)
		{
			ipaddr_h2 = ipaddr_h2_tmp - 2;
		}
	}

	ipaddr_out = (ipaddr_h1 << 24) + (ipaddr_h2 << 16) + (ipaddr_h3 << 8) + ipaddr_h4;
//	printf("ipaddr_make id:%d %08x ---> %08x\n",id,ipaddr_in,ipaddr_out);
	ipaddr_out = DBFW_HTON32(ipaddr_out);
	return ipaddr_out;
}

int ipaddr6_make(u_char *key,int id)
{
	uint64_t *k = (uint64_t *)key;
	
	k[1] = k[1] + id;
//	printf("%llu  %llu\n",k[0], k[1]);
//	printf("ret=%0x%0x%0x%0x%0x%0x%0x%0x%0x%0x%0x%0x%0x%0x%0x%0x  id=%d\n",((u_char *)key)[0],((u_char *)key)[1],((u_char *)key)[2],((u_char *)key)[3],((u_char *)key)[4],((u_char *)key)[5],((u_char *)key)[6],((u_char *)key)[7],((u_char *)key)[8],((u_char *)key)[9],((u_char *)key)[10],((u_char *)key)[11],((u_char *)key)[12],((u_char *)key)[13],((u_char *)key)[14],((u_char *)key)[15],id);

	return 1;
}

int str2byte(char s[],unsigned char bits[]) {
	int i,n = 0;
	for(i = 0; s[i]; i += 2) {
		if(s[i] >= 'a' && s[i] <= 'f')
			bits[n] = s[i] - 'a' + 10;
		else bits[n] = s[i] - '0';
		if(s[i + 1] >= 'a' && s[i + 1] <= 'f')
			bits[n] = (bits[n] << 4) | (s[i + 1] - 'a' + 10);
		else bits[n] = (bits[n] << 4) | (s[i + 1] - '0');
		++n;
	}
	return n;
}

//string* byte2str(char byte_arr[],int arr_len)
//{
//	string*  hexstr=new string();
//	for (int i=0;i<arr_len;i++)
//	{
//		char hex1;
//		char hex2;
//		int value=byte_arr[i];
//		int v1=value/16;
//		int v2=value % 16;
// 
//		if (v1>=0&&v1<=9)
//			hex1=(char)(48+v1);
//		else
//			hex1=(char)(55+v1);
// 
//		if (v2>=0&&v2<=9)
//			hex2=(char)(48+v2);
//		else
//			hex2=(char)(55+v2);
// 
//		*hexstr=*hexstr+hex1+hex2;
//	}
//	return hexstr;
//}


static int packet_change(Meter_Broadcast_Cache_Control *pcontrol,Meter_Packet_Info *pkt_info,Meter_Session_HashValue *mhvalue)
{
	unsigned int ipaddr_tmp = 0,ipaddr_tmp1 = 0,ipaddr_final = 0;
//	u_short port = 0;
	unsigned int step_seq = 0,step_ack = 0;
	unsigned int curr_seq = 0,curr_ack = 0;
	Meter_Broadcast_Id key;
	Meter_Broadcast_Rule_Value *rvalue = NULL;

	if(!pcontrol || !pkt_info)
	{
		return -1;
	}

	//1.根据--client参数改变IP地址
	if(mb_pkt_dct_request == pkt_info->direction)
	{
		//先查找有ip地址无端口的情形
		if(pkt_info->ethernet.type == 0x0800)
		{
			key.ipaddr = pkt_info->ipv4_header.ip_srcaddr;
		}else{
			key.ipaddr = Dbfw_hash_xor_key16(pkt_info->ipv6_header.ip_srcaddr);
		}
		key.port = 0;
		rvalue = (Meter_Broadcast_Rule_Value*)dspr_hash_find(
					_Rule.client_rule,&key,sizeof(Meter_Broadcast_Id));
		if(rvalue)
		{
			if(rvalue->sim.ipaddr)
			{
				if(pkt_info->ethernet.type == 0x0800)
				{
					memcpy(pcontrol->pkt_buffer+pkt_info->ip_cursor+12,&rvalue->sim.ipaddr,sizeof(unsigned int));
				}else{
					memcpy(pcontrol->pkt_buffer+pkt_info->ip_cursor+8,&rvalue->sim_value.ipaddr,16);
				}
			}
		}
		else
		{
			//再查找有ip地址有端口的情形
			if(pkt_info->ethernet.type == 0x0800)
			{
				key.ipaddr = pkt_info->ipv4_header.ip_srcaddr;
				key.port = pkt_info->tcp_header.source_port;
			}else{
				key.ipaddr = Dbfw_hash_xor_key16(pkt_info->ipv6_header.ip_srcaddr);
				key.port = pkt_info->tcp_header.source_port;
			}
			rvalue = (Meter_Broadcast_Rule_Value*)dspr_hash_find(
						_Rule.client_rule,&key,sizeof(Meter_Broadcast_Id));
			if(rvalue)
			{
				if(rvalue->sim.ipaddr)
				{
					if(pkt_info->ethernet.type == 0x0800)
					{
						memcpy(pcontrol->pkt_buffer+pkt_info->ip_cursor+12,&rvalue->sim.ipaddr,sizeof(unsigned int));
					}else{
						memcpy(pcontrol->pkt_buffer+pkt_info->ip_cursor+8,&rvalue->sim_value.ipaddr,16);
					}
				}
				if(rvalue->sim.port)
				{
					memcpy(pcontrol->pkt_buffer+pkt_info->tcp_cursor,&rvalue->sim.port,sizeof(u_short));
				}
			}
		}
	}
	else if(mb_pkt_dct_response == pkt_info->direction)
	{
		if(pkt_info->ethernet.type == 0x0800)
		{
			key.ipaddr = pkt_info->ipv4_header.ip_destaddr;
			
		}else{
			key.ipaddr = Dbfw_hash_xor_key16(pkt_info->ipv6_header.ip_destaddr);
		}
		key.port = 0;
		rvalue = (Meter_Broadcast_Rule_Value*)dspr_hash_find(
					_Rule.client_rule,&key,sizeof(Meter_Broadcast_Id));
		if(rvalue)
		{
			if(rvalue->sim.ipaddr)
			{
				if(pkt_info->ethernet.type == 0x0800)
				{
					memcpy(pcontrol->pkt_buffer+pkt_info->ip_cursor+16,&rvalue->sim.ipaddr,sizeof(unsigned int));
				}else{
					memcpy(pcontrol->pkt_buffer+pkt_info->ip_cursor+24,&rvalue->sim_value.ipaddr,16);
				}
			}
		}
		else
		{
			if(pkt_info->ethernet.type == 0x0800)
			{
				key.ipaddr = pkt_info->ipv4_header.ip_destaddr;
				
			}else{
				key.ipaddr = Dbfw_hash_xor_key16(pkt_info->ipv6_header.ip_destaddr);
			}
			key.port = pkt_info->tcp_header.dest_port;
			rvalue = (Meter_Broadcast_Rule_Value*)dspr_hash_find(
						_Rule.client_rule,&key,sizeof(Meter_Broadcast_Id));
			if(rvalue)
			{
				if(rvalue->sim.ipaddr)
				{
					if(pkt_info->ethernet.type == 0x0800)
					{
						memcpy(pcontrol->pkt_buffer+pkt_info->ip_cursor+16,&rvalue->sim.ipaddr,sizeof(unsigned int));
					}else{
						memcpy(pcontrol->pkt_buffer+pkt_info->ip_cursor+24,&rvalue->sim_value.ipaddr,16);
					}
				}
				if(rvalue->sim.port)
				{
					memcpy(pcontrol->pkt_buffer+pkt_info->tcp_cursor+2,&rvalue->sim.port,sizeof(u_short));
				}
			}
		}
	}

	//2. 改变IP地址和端�?
	//为了实现meter_broadcast的session机制，需要把一个包动态计算出不同的IP和端�?
	if(mb_pkt_dct_request == pkt_info->direction)
	{
		//使用端口的计算机�?
		/*
		port = pkt_info->tcp_header.source_port + pcontrol->id*(_Global.worker_max+1);
		//不让出现低于1024端口的包
		if(port < 1024)
		{
			port += 1024;
		}
		port = DBFW_HTON16(port);
		memcpy(pcontrol->pkt_buffer+pkt_info->tcp_cursor,&port,sizeof(u_short));
		*/
		//使用IP地址的计算机�?
//		memcpy(&ipaddr_tmp1,pcontrol->pkt_buffer+pkt_info->ip_cursor+12,sizeof(unsigned int));
		if(pkt_info->ethernet.type == 0x0800)
		{
			memcpy(&ipaddr_tmp1,pcontrol->pkt_buffer+pkt_info->ip_cursor+12,sizeof(unsigned int));
			ipaddr_tmp = DBFW_HTON32(ipaddr_tmp1);//DBFW_HTON32(pkt_info->ipv4_header.ip_srcaddr);
			if(_Global.short_connect)
			{
				ipaddr_final = ipaddr_make(ipaddr_tmp,pcontrol->loop_count);
			}
			else
			{
				ipaddr_final = ipaddr_make(ipaddr_tmp,pcontrol->id-1);
			}
			memcpy(pcontrol->pkt_buffer+pkt_info->ip_cursor+12,&ipaddr_final,sizeof(unsigned int));
		}else{
			if(_Global.short_connect)
			{
//				printf("-------%0x%0x%0x%0x%0x%0x%0x%0x%0x%0x%0x%0x%0x%0x%0x%0x\n",pkt_info->ipv6_header.ip_srcaddr[0],pkt_info->ipv6_header.ip_srcaddr[1],pkt_info->ipv6_header.ip_srcaddr[2],pkt_info->ipv6_header.ip_srcaddr[3],pkt_info->ipv6_header.ip_srcaddr[4],pkt_info->ipv6_header.ip_srcaddr[5],pkt_info->ipv6_header.ip_srcaddr[6],pkt_info->ipv6_header.ip_srcaddr[7],
//				pkt_info->ipv6_header.ip_srcaddr[8],pkt_info->ipv6_header.ip_srcaddr[9],pkt_info->ipv6_header.ip_srcaddr[10],pkt_info->ipv6_header.ip_srcaddr[11],pkt_info->ipv6_header.ip_srcaddr[12],pkt_info->ipv6_header.ip_srcaddr[13],pkt_info->ipv6_header.ip_srcaddr[14],pkt_info->ipv6_header.ip_srcaddr[15]);
				ipaddr_final = ipaddr6_make(pkt_info->ipv6_header.ip_srcaddr,pcontrol->loop_count);
			}
			else
			{
//				printf("-------%0x%0x%0x%0x%0x%0x%0x%0x%0x%0x%0x%0x%0x%0x%0x%0x\n",pkt_info->ipv6_header.ip_srcaddr[0],pkt_info->ipv6_header.ip_srcaddr[1],pkt_info->ipv6_header.ip_srcaddr[2],pkt_info->ipv6_header.ip_srcaddr[3],pkt_info->ipv6_header.ip_srcaddr[4],pkt_info->ipv6_header.ip_srcaddr[5],pkt_info->ipv6_header.ip_srcaddr[6],pkt_info->ipv6_header.ip_srcaddr[7],
//				pkt_info->ipv6_header.ip_srcaddr[8],pkt_info->ipv6_header.ip_srcaddr[9],pkt_info->ipv6_header.ip_srcaddr[10],pkt_info->ipv6_header.ip_srcaddr[11],pkt_info->ipv6_header.ip_srcaddr[12],pkt_info->ipv6_header.ip_srcaddr[13],pkt_info->ipv6_header.ip_srcaddr[14],pkt_info->ipv6_header.ip_srcaddr[15]);
				ipaddr_final = ipaddr6_make(pkt_info->ipv6_header.ip_srcaddr,pcontrol->id-1);
			}
			if(ipaddr_final<=0)
			{
				printf("change addr error!\n");
				return -1;
			}
			memcpy(pcontrol->pkt_buffer+pkt_info->ip_cursor+8,pkt_info->ipv6_header.ip_srcaddr,16);
		}
		/*
		if(_Global.short_connect)
		{
			port = pkt_info->tcp_header.source_port + pcontrol->loop_count;
			//不让出现低于1024端口的包
			if(port < 1024)
			{
				port += 1024;
			}
			port = DBFW_HTON16(port);
			memcpy(pcontrol->pkt_buffer+pkt_info->tcp_cursor,&port,sizeof(u_short));
		}
		*/
	}
	else if(mb_pkt_dct_response == pkt_info->direction)
	{
		//使用端口的计算机�?
		/*
		port = pkt_info->tcp_header.dest_port + pcontrol->id*(_Global.worker_max+1);
		//不让出现低于1024端口的包
		if(port < 1024)
		{
			port += 1024;
		}
		port = DBFW_HTON16(port);
		memcpy(pcontrol->pkt_buffer+pkt_info->tcp_cursor+2,&port,sizeof(u_short));
		*/
		//使用IP地址的计算机�?
		if(pkt_info->ethernet.type == 0x0800)
		{
			memcpy(&ipaddr_tmp1,pcontrol->pkt_buffer+pkt_info->ip_cursor+16,sizeof(unsigned int));
			ipaddr_tmp = DBFW_HTON32(ipaddr_tmp1); //DBFW_HTON32(pkt_info->ipv4_header.ip_destaddr);
			if(_Global.short_connect)
			{
				ipaddr_final = ipaddr_make(ipaddr_tmp,pcontrol->loop_count);
			}
			else
			{
				ipaddr_final = ipaddr_make(ipaddr_tmp,pcontrol->id-1);
			}
			memcpy(pcontrol->pkt_buffer+pkt_info->ip_cursor+16,&ipaddr_final,sizeof(unsigned int));
		}else{

			if(_Global.short_connect)
			{
				ipaddr_final = ipaddr6_make(pkt_info->ipv6_header.ip_destaddr,pcontrol->loop_count);
			}
			else
			{
				ipaddr_final = ipaddr6_make(pkt_info->ipv6_header.ip_destaddr,pcontrol->id-1);
			}
			if(ipaddr_final<=0)
			{
				printf("change addr error!\n");
				return -1;
			}
			memcpy(pcontrol->pkt_buffer+pkt_info->ip_cursor+24,pkt_info->ipv6_header.ip_destaddr,16);
		}
		/*
		if(_Global.short_connect)
		{
			port = pkt_info->tcp_header.dest_port + pcontrol->loop_count;
			//不让出现低于1024端口的包
			if(port < 1024)
			{
				port += 1024;
			}
			port = DBFW_HTON16(port);
			memcpy(pcontrol->pkt_buffer+pkt_info->tcp_cursor+2,&port,sizeof(u_short));
		}
		*/
	}

	//3.根据--server参数改变IP地址
	if(mb_pkt_dct_request == pkt_info->direction)
	{
		if(pkt_info->ethernet.type == 0x0800)
		{
			key.ipaddr = pkt_info->ipv4_header.ip_destaddr;
		}else{
			key.ipaddr = Dbfw_hash_xor_key16(pkt_info->ipv6_header.ip_destaddr);
		}
		key.port = pkt_info->tcp_header.dest_port;
		rvalue = (Meter_Broadcast_Rule_Value*)dspr_hash_find(
					_Rule.server_rule,&key,sizeof(Meter_Broadcast_Id));
		if(rvalue)
		{
			if(rvalue->sim.ipaddr)
			{
				if(pkt_info->ethernet.type == 0x0800)
				{
					memcpy(pcontrol->pkt_buffer+pkt_info->ip_cursor+16,&rvalue->sim.ipaddr,sizeof(unsigned int));
				}else{
					memcpy(pcontrol->pkt_buffer+pkt_info->ip_cursor+24,&rvalue->sim_value.ipaddr,16);
				}
			}
			if(rvalue->sim.port)
			{
				memcpy(pcontrol->pkt_buffer+pkt_info->tcp_cursor+2,&rvalue->sim.port,sizeof(u_short));
			}
		}
	}
	else if(mb_pkt_dct_response == pkt_info->direction)
	{
		if(pkt_info->ethernet.type == 0x0800)
		{
			key.ipaddr = pkt_info->ipv4_header.ip_srcaddr;
		}else{
			key.ipaddr = Dbfw_hash_xor_key16(pkt_info->ipv6_header.ip_srcaddr);
		}
		key.port = pkt_info->tcp_header.source_port;
		rvalue = (Meter_Broadcast_Rule_Value*)dspr_hash_find(
					_Rule.server_rule,&key,sizeof(Meter_Broadcast_Id));
		if(rvalue)
		{
			if(rvalue->sim.ipaddr)
			{
				if(pkt_info->ethernet.type == 0x0800)
				{
					memcpy(pcontrol->pkt_buffer+pkt_info->ip_cursor+12,&rvalue->sim.ipaddr,sizeof(unsigned int));
				}else{
					memcpy(pcontrol->pkt_buffer+pkt_info->ip_cursor+8,&rvalue->sim_value.ipaddr,16);
				}
			}
			if(rvalue->sim.port)
			{
				memcpy(pcontrol->pkt_buffer+pkt_info->tcp_cursor,&rvalue->sim.port,sizeof(u_short));
			}
		}
	}

	//4.改变序列�?
	if(mhvalue && pcontrol->loop_count)
	{
#ifdef PACKET_CHANGE_METHOD1
		if(mb_pkt_dct_request == pkt_info->direction)
		{
			step_seq = pcontrol->loop_count*(mhvalue->step_sequence);
			step_ack = pcontrol->loop_count*(mhvalue->step_acknowledge);
		}
		else if(mb_pkt_dct_response == pkt_info->direction)
		{
			step_seq = pcontrol->loop_count*(mhvalue->step_acknowledge);
			step_ack = pcontrol->loop_count*(mhvalue->step_sequence);
		}
		pkt_info->tcp_header.sequence += step_seq;
		pkt_info->tcp_header.acknowledge += step_ack;
#endif

#ifdef PACKET_CHANGE_METHOD2
		if(mb_pkt_dct_request == pkt_info->direction)
		{
			pkt_info->tcp_header.sequence = mhvalue->end_sequence;
			pkt_info->tcp_header.acknowledge = mhvalue->end_acknowledge;
		}
		else
		{
			pkt_info->tcp_header.sequence = mhvalue->end_acknowledge;
			pkt_info->tcp_header.acknowledge = mhvalue->end_sequence;
		}
#endif

		curr_seq = pkt_info->tcp_header.sequence;
		curr_ack = pkt_info->tcp_header.acknowledge;
		curr_seq = DBFW_HTON32(curr_seq);
		curr_ack = DBFW_HTON32(curr_ack);
		memcpy(pcontrol->pkt_buffer+pkt_info->tcp_cursor+4,&curr_seq,sizeof(unsigned int));
		memcpy(pcontrol->pkt_buffer+pkt_info->tcp_cursor+8,&curr_ack,sizeof(unsigned int));
	}

#ifdef PACKET_CHANGE_METHOD1
	if(pcontrol->loop_count == 0)
	{
		sequence_update(pkt_info,mhvalue);
	}
#endif

#ifdef PACKET_CHANGE_METHOD2
	sequence_update(pkt_info,mhvalue);
#endif

	return 0;
}

static int meter_broadcast_cache_one(Meter_Broadcast_Cache_Control *pcontrol)
{
	int res = 0,sleep_flag = 0,syn_count = 0;
	Meter_Packet_Hdr *header = NULL;
	const u_char *pkt_data = NULL;
	pcap_pkthdr *pp = NULL;
	Dbfw_EthernetFrame eth_frame;
	Meter_Packet_Info pkt_info;
	Meter_Session_HashKey mhkey;
	Meter_Session_HashValue *mhvalue = NULL;
	Meter_Discard_HashKey diskey;

	pp = (pcap_pkthdr *)malloc(sizeof(pcap_pkthdr));
	pcontrol->cursor = _Cache.begin_offset;
	pcontrol->curr_npack = 0;
	pcontrol->curr_nsize = 0;
	while(0 == cache_get_next(&_Cache,pcontrol,&header,&pkt_data))
	{
		memset(pp,0,sizeof(pcap_pkthdr));
		pp->caplen = header->caplen;
		pp->len = header->len;
		pp->ts.tv_sec = header->sec;
		pp->ts.tv_usec = header->usec;
		memset(pcontrol->pkt_buffer,0,pcontrol->buffer_size);
		memcpy(pcontrol->pkt_buffer,pkt_data,header->caplen);
		eth_frame.frame_data = (u_char*)pcontrol->pkt_buffer;
		eth_frame.frame_size = header->len;

		if(meter_mode_all == _Global.mode)
		{
			mhvalue=(Meter_Session_HashValue *)malloc(sizeof(Meter_Session_HashValue));
			memset(mhvalue, 0, sizeof(Meter_Session_HashValue));
			goto sendpkt;
		}

		memset(&pkt_info,0,sizeof(pkt_info));
		res = Dbfw_Protocol_Parse(&eth_frame,&pkt_info,_Rule.server_rule);
		if(res != meter_proto_cs)
		{
			continue;
		}

//		if(_Global.short_connect == 0)
		{
			if(header->syn && pcontrol->loop_count == 0)
			{
				if(_Global.syn_delay >0 && syn_count>0)
				{
					syn_count = 0;
					usleep(_Global.syn_delay);
				}
				syn_count++;
			}

			//已经登录，不能再重复建立连接
			if(header->syn && pcontrol->loop_count)
			{
				continue;
			}
			//不是最后一次，不能断开连接
			if(header->fin && (pcontrol->loop_count < (pcontrol->loop_max - 1)))
			{
				continue;
			}
/*
			if(header->len != header->caplen)
				printf("meter_broadcast_cache_one packet len:%d caplen:%d  %08x:%d ---> %08x:%d\n",
					header->len,header->caplen,
					pkt_info.ipv4_header.ip_srcaddr,pkt_info.tcp_header.source_port,
					pkt_info.ipv4_header.ip_destaddr,pkt_info.tcp_header.dest_port);
*/
		}

		if((_Global.sequence > 0) && pcontrol->loop_count)
		{
			if(pkt_info.direction == mb_pkt_dct_request)
			{
				if(pkt_info.tcp_header.sequence < _Global.sequence)
					continue;
			}
			else
			{
				if(pkt_info.tcp_header.acknowledge < _Global.sequence)
					continue;
			}
		}

		session_create_key(&pkt_info,&mhkey);
		mhvalue = (Meter_Session_HashValue*)dspr_hash_find(pcontrol->sess_hash,&mhkey,sizeof(Meter_Session_HashKey));
		mhvalue->packet_count++;

		/* 判断是否需要随机丢�? */
		if(_Global.ramdom_discard > 0 && pkt_info.data_size > 0)
		{
			int offset = mhvalue->packet_count%1000;
			if(pcontrol->random_discard[offset])
			{
				char ipaddr[64];
				unsigned int srcip = 0;
				memset(ipaddr,0,sizeof(ipaddr));
				if(pkt_info.ethernet.type == 0x0800)
				{
					srcip = DBFW_HTON32(pkt_info.ipv4_header.ip_srcaddr);
					meter_iptos(srcip,ipaddr);
				}else{
					memcpy(ipaddr,pkt_info.ipv6_header.ip_srcaddr,16);
				}
				printf("discard_packet=%s:%d.%u\n",ipaddr,
						pkt_info.tcp_header.source_port,
						pkt_info.tcp_header.sequence);
				continue;
			}
		}
		/* 判断是否需要丢弃指定的�? */
		if(_Discard_Hash && pkt_info.data_size > 0)
		{
			if(pkt_info.ethernet.type == 0x0800)
			{
				diskey.ipaddr = pkt_info.ipv4_header.ip_srcaddr;
			}else{
				diskey.ipaddr = Dbfw_hash_xor_key16(pkt_info.ipv6_header.ip_srcaddr);
			}
			diskey.port = pkt_info.tcp_header.source_port;
			diskey.sequence = pkt_info.tcp_header.sequence;
//			hex_print("meter_broadcast_cache_one",(const unsigned char*)&diskey,sizeof(Meter_Discard_HashKey));
			if(dspr_hash_find(_Discard_Hash,&diskey,sizeof(Meter_Discard_HashKey)))
			{
				char ipaddr[64];
				unsigned int srcip = 0;
				memset(ipaddr,0,sizeof(ipaddr));
				if(pkt_info.ethernet.type == 0x0800)
				{
					srcip = DBFW_HTON32(pkt_info.ipv4_header.ip_srcaddr);
					meter_iptos(srcip,ipaddr);
				}else{
					memcpy(ipaddr,pkt_info.ipv6_header.ip_srcaddr,16);
				}
				printf("discard_packet=%s:%d.%u\n",ipaddr,
						pkt_info.tcp_header.source_port,
						pkt_info.tcp_header.sequence);
				continue;
			}
		}

		//改变�?
		packet_change(pcontrol,&pkt_info,mhvalue);

		if(_Global.verbose >= 2)
		{
			packet_print(&pkt_info);
		}
	sendpkt:
		if(_Global.savepkt_flag)
		{
			pcap_dump((u_char*)global_dumpfp, pp, eth_frame.frame_data);
			pcap_dump_flush(global_dumpfp);

			mhvalue->packet_count++;
			pcontrol->curr_npack++;
			pcontrol->curr_nsize += header->len;
			if(_Global.mode == meter_mode_all)
			{
				free(mhvalue);
			}
			continue;
		}

		if(pcap_sendpacket(_Global.pp_dev,pcontrol->pkt_buffer,header->caplen) != 0)
		{
			fprintf(stderr,"Meter Error: Sending the packet: %s  Packet:%d Size:%d\n",
				pcap_geterr(_Global.pp_dev),pcontrol->curr_npack+1,header->caplen);
			if(_Global.mode == meter_mode_all)
			{
				free(mhvalue);
			}
			continue;
		}
		if(_Global.pkt_per_interval > 0 && (pcontrol->curr_npack % _Global.pkt_per_interval == 0))
		{
			usleep(METER_PPS_USLEEP);
			sleep_flag = 1;
		}
		mhvalue->packet_count++;
		pcontrol->curr_npack++;
		pcontrol->curr_nsize += header->len;
		if(_Global.mode == meter_mode_all)
		{
			free(mhvalue);
		}
	}
	pcontrol->loop_count++;
	pcontrol->total_npack += pcontrol->curr_npack;
	pcontrol->total_nsize += pcontrol->curr_nsize;
	if(_Global.verbose >= 1)
	{
		if(_Global.savepkt_flag)
		{	
			printf ("Session:%03d Loop:%03d Save packets count:%d size:%llu\n",
					pcontrol->id,pcontrol->loop_count,pcontrol->curr_npack,pcontrol->curr_nsize);
		}
		else
		{	
			printf ("Session:%03d Loop:%03d Send packets count:%d size:%llu\n",
					pcontrol->id,pcontrol->loop_count,pcontrol->curr_npack,pcontrol->curr_nsize);
		}
	}
	if(sleep_flag == 0 && _Global.savepkt_flag == 0)
	{
		usleep(METER_PPS_USLEEP);
	}
	free(pp);
//	pcap_dump_close(global_dumpfp);
	return 0;
}


static int meter_broadcast_cache_loop(Meter_Broadcast_Cache_Control *pcontrol)
{
	int count = 0;
	struct timeval tvbegin,tvend;
	int elapsed = 0;

	if(NULL == pcontrol)
	{
		return -1;
	}

	meter_broadcast_control_init(pcontrol);

	gettimeofday(&tvbegin,NULL);
	for(count=0;count<_Global.loop_max;count++)
	{
		if(_Global.interval >0 && count >0)
			usleep(_Global.interval);
		meter_broadcast_cache_one(pcontrol);
	}
	gettimeofday(&tvend,NULL);

	tvend.tv_usec /= 1000;
	tvbegin.tv_usec /= 1000;
	elapsed = (tvend.tv_sec - tvbegin.tv_sec)*1000 + (tvend.tv_usec - tvbegin.tv_usec);

	__sync_fetch_and_add(&_total_npack,pcontrol->total_npack);
	__sync_fetch_and_add(&_total_nsize,pcontrol->total_nsize);
	__sync_fetch_and_add(&_total_loop,pcontrol->loop_count);

	printf ("Session:%03d Loop:%03d Total packets count:%u size:%llu Elapsed time:%d\n",
		pcontrol->id,pcontrol->loop_count,pcontrol->total_npack,pcontrol->total_nsize,elapsed);

	free(pcontrol->pkt_buffer);
	return 0;
}

RET_THREAD thread_broadcast(void* thread_param)
{
	Meter_Broadcast_Cache_Control *pcontrol = (Meter_Broadcast_Cache_Control*)thread_param;
	_Global.worker_count++;
	printf("Meter Worker: begin %d\n",pcontrol->id);
	meter_broadcast_cache_loop(pcontrol);
	_Global.worker_count--;
	return NULL_THREAD;
}

static int meter_broadcast_cache()
{
	struct timeval tvbegin,tvend;
	int elapsed = 0;
	char dumpname[1024], pcapfile[1024], *psep = NULL;
	Meter_Broadcast_Cache_Control *first_control = NULL;
	memset(dumpname, 0, sizeof(dumpname));
	memset(pcapfile, 0, sizeof(pcapfile));

	strncpy(pcapfile,_Global.pcap_file_name,sizeof(pcapfile)-1);
	psep = strrchr(pcapfile,'.');
	if(psep)
	{
		*psep = 0;
	}
	if(_Global.savepkt_flag == 1)
	{
		sprintf(dumpname, "%s-all_info.pcap", pcapfile);
		global_dumpfp = pcap_dump_open(_Global.pp_file,dumpname);
	}

	if(_Global.worker_max > 1)
	{
		Meter_Broadcast_Cache_Control *pcontrol = NULL;
		int count = 1;

		gettimeofday(&tvbegin,NULL);
		for(count = 1; count <= _Global.worker_max;count++)
		{
			pcontrol = (Meter_Broadcast_Cache_Control*)malloc(sizeof(Meter_Broadcast_Cache_Control));
			if(NULL == pcontrol)
			{
				continue;
			}
			memset(pcontrol,0,sizeof(Meter_Broadcast_Cache_Control));
			pcontrol->id = count;
			pcontrol->loop_max = _Global.loop_max;
			meter_thread_create(thread_broadcast,(void*)pcontrol);
			usleep(_Global.start_interval);//延迟15毫秒，避免一窝蜂打包的情�?
			if(first_control == NULL)
				first_control = pcontrol;
		}
		count = 0;
		while(1)
		{
			sleep(1);
			count++;
			if(count >= 5)
			{
				printf("Meter Worker: count:%d  loop:%d\n",_Global.worker_count,first_control->loop_count);
				count = 0;
			}
			if(_Global.worker_count <= 0)
			{
				break;
			}
		}
		gettimeofday(&tvend,NULL);

		tvend.tv_usec /= 1000;
		tvbegin.tv_usec /= 1000;
		elapsed = (tvend.tv_sec - tvbegin.tv_sec)*1000 + (tvend.tv_usec - tvbegin.tv_usec);

		printf ("\nBroadcast Report: Total packets loop:%u count:%u size:%llu Elapsed time:%d\n",
			_total_loop,_total_npack,_total_nsize,elapsed);

	}
	else if(_Global.worker_max == 1)
	{
		Meter_Broadcast_Cache_Control control;
		memset(&control,0,sizeof(Meter_Broadcast_Cache_Control));
		control.id = 1;
		control.loop_max = _Global.loop_max;
		meter_broadcast_cache_loop(&control);
	}	

	return 0;
}


static int meter_broadcast_file_one(Meter_Broadcast_Cache_Control *pcontrol)
{
	int res = 0,syn_step = 0,syn_count = 0;
	struct pcap_pkthdr *header = NULL;
	const u_char *pkt_data = NULL;
	Meter_Packet_Hdr pkt_hdr;
	Dbfw_EthernetFrame eth_frame;
	Meter_Packet_Info pkt_info;
	Meter_Session_HashValue *mhvalue = NULL;
	Meter_Discard_HashKey diskey;

	pcontrol->curr_npack = 0;
	pcontrol->curr_nsize = 0;
	fseek(_Global.fp_file,_Global.begin_offset,SEEK_SET);

	while((res = pcap_next_ex(_Global.pp_file, &header, &pkt_data)) >= 0)
	{
		memset(pcontrol->pkt_buffer,0,pcontrol->buffer_size);
		memcpy(pcontrol->pkt_buffer,pkt_data,header->caplen);

		memset(&eth_frame,0,sizeof(eth_frame));
		memset(&pkt_info,0,sizeof(pkt_info));
		eth_frame.frame_data = (u_char*)pcontrol->pkt_buffer;
		eth_frame.frame_size = header->len;
		if(meter_mode_all == _Global.mode)
		{
			goto sendpkt;
		}

		res = Dbfw_Protocol_Parse(&eth_frame,&pkt_info,_Rule.server_rule);
		if(res != meter_proto_cs)
		{
			continue;
		}

		memset(&pkt_hdr,0,sizeof(pkt_hdr));
		pkt_hdr.sec = header->ts.tv_sec;
		pkt_hdr.usec = header->ts.tv_usec;
		pkt_hdr.caplen = header->caplen;
		pkt_hdr.len = header->len;

		//放入哈希�?
		if(pcontrol->loop_count == 0)
		{
			mhvalue = session_register(_Sess_Hash,&pkt_hdr,&pkt_info);
		}

		if(pkt_info.tcp_header.syn && pcontrol->loop_count == 0)
		{
			if(_Global.syn_delay >0 && syn_count>0)
			{
				syn_count = 0;
				usleep(_Global.syn_delay);
			}
			syn_count++;
		}

		//已经登录，不能再重复建立连接
		if(_Global.short_connect == 0)
		{
			if(pkt_info.tcp_header.syn && pcontrol->loop_count)
			{
				syn_step++;
				continue;
			}

			//不是最后一次，不能断开连接
			if(pkt_info.tcp_header.fin && (pcontrol->loop_count < (pcontrol->loop_max - 1)))
			{
				continue;
			}

			if(pkt_info.tcp_header.ack && pkt_info.tcp_header.fin == 0 && pkt_info.tcp_header.syn == 0 && pkt_info.tcp_header.psh == 0)
			{
				if(syn_step)
				{
					syn_step = 0;
					continue;
				}
			}
		}

		//忽略复位信号
		/*if(pkt_info.tcp_header.rst)
		{
			continue;
		}*/


		if((_Global.sequence > 0) && pcontrol->loop_count)
		{
			if(pkt_info.direction == mb_pkt_dct_request)
			{
				if(pkt_info.tcp_header.sequence < _Global.sequence)
					continue;
			}
			else
			{
				if(pkt_info.tcp_header.acknowledge < _Global.sequence)
					continue;
			}
		}

		pcontrol->packet_count++;
		/* 判断是否需要随机丢�? */
		if(_Global.ramdom_discard > 0 && pkt_info.data_size > 0)
		{
			int offset = pcontrol->packet_count%1000;
			if(pcontrol->random_discard[offset])
			{
				char ipaddr[64];
				unsigned int srcip = 0;
				memset(ipaddr,0,sizeof(ipaddr));
				srcip = DBFW_HTON32(pkt_info.ipv4_header.ip_srcaddr);
				meter_iptos(srcip,ipaddr);
				printf("discard_packet=%s:%d.%u\n",ipaddr,
						pkt_info.tcp_header.source_port,
						pkt_info.tcp_header.sequence);
				continue;
			}
		}
		/* 判断是否需要丢弃指定的�? */
		if(_Discard_Hash && pkt_info.data_size > 0)
		{
			diskey.ipaddr = pkt_info.ipv4_header.ip_srcaddr;
			diskey.port = pkt_info.tcp_header.source_port;
			diskey.sequence = pkt_info.tcp_header.sequence;
//			hex_print("meter_broadcast_cache_one",(const unsigned char*)&diskey,sizeof(Meter_Discard_HashKey));
			if(dspr_hash_find(_Discard_Hash,&diskey,sizeof(Meter_Discard_HashKey)))
			{
				char ipaddr[64];
				unsigned int srcip = 0;
				memset(ipaddr,0,sizeof(ipaddr));
				srcip = DBFW_HTON32(pkt_info.ipv4_header.ip_srcaddr);
				meter_iptos(srcip,ipaddr);
				printf("discard_packet=%s:%d.%u\n",ipaddr,
						pkt_info.tcp_header.source_port,
						pkt_info.tcp_header.sequence);
				continue;
			}
		}

		packet_change(pcontrol,&pkt_info,mhvalue);

	sendpkt:
		if(_Global.savepkt_flag)
		{
			pcap_dump((u_char *)global_dumpfp, header, eth_frame.frame_data);
			pcap_dump_flush(global_dumpfp);
			pcontrol->curr_npack++;
			pcontrol->curr_nsize += header->len;
			continue;
		}
		if(pcap_sendpacket(_Global.pp_dev,pcontrol->pkt_buffer,header->len) != 0)
		{
			fprintf(stderr,"Meter Error: Sending the packet: %s\n", pcap_geterr(_Global.pp_dev));
			continue;
		}
		if(_Global.pkt_per_interval > 0 && (pcontrol->curr_npack % _Global.pkt_per_interval == 0))
		{
			usleep(METER_PPS_USLEEP);
		}
		pcontrol->curr_npack++;
		pcontrol->curr_nsize += header->len;
	}
	pcontrol->loop_count++;
	pcontrol->total_npack += pcontrol->curr_npack;
	pcontrol->total_nsize += pcontrol->curr_nsize;
	if(pcontrol->loop_count == 0)
	{
		session_stat(_Sess_Hash);
	}
	if(_Global.savepkt_flag)
	{
		printf ("Loop:%03d Save packets count:%d size:%llu\n",
				pcontrol->loop_count,pcontrol->curr_npack,pcontrol->curr_nsize);
	}
	else
	{
		printf ("Loop:%03d Send packets count:%d size:%llu\n",
				pcontrol->loop_count,pcontrol->curr_npack,pcontrol->curr_nsize);
	}
	return 0;
}

static int meter_broadcast_file_loop(Meter_Broadcast_Cache_Control *pcontrol)
{
	int count=0;
	char pcapfile[1024], dumpname[1024], *psep;
	struct timeval tvbegin,tvend;
	int elapsed = 0;

	memset(pcapfile, 0, sizeof(pcapfile));
	memset(dumpname, 0, sizeof(dumpname));

	if(NULL == pcontrol)
	{
		return -1;
	}

	pcontrol->buffer_size = METER_MAX_PKT_BUFFER;
	pcontrol->pkt_buffer = (u_char*)malloc(pcontrol->buffer_size);
	if(!pcontrol->pkt_buffer)
	{
		return -1;
	}

	strncpy(pcapfile,_Global.pcap_file_name,sizeof(pcapfile)-1);
	psep = strrchr(pcapfile,'.');
	if(psep)
	{
		*psep = 0;
	}
	sprintf(dumpname, "%s-all_info.pcap", pcapfile);
	global_dumpfp = pcap_dump_open(_Global.pp_file,dumpname);	

	gettimeofday(&tvbegin,NULL);
	for(count=0;count<_Global.loop_max;count++)
	{
		if(_Global.interval >0 && count >0)
			usleep(_Global.interval);
		meter_broadcast_file_one(pcontrol);
	}
	gettimeofday(&tvend,NULL);

	tvend.tv_usec /= 1000;
	tvbegin.tv_usec /= 1000;
	elapsed = (tvend.tv_sec - tvbegin.tv_sec)*1000 + (tvend.tv_usec - tvbegin.tv_usec);

	printf ("\nLoop:%03d Total packets count:%d size:%llu Elapsed time:%dms\n",
		pcontrol->loop_count,pcontrol->total_npack,pcontrol->total_nsize,elapsed);
	free(pcontrol->pkt_buffer);
	return 0;
}


struct Pcap_Loop_Param
{
	pcap_dumper_t *dumpfile;
	pcap_dumper_t *responsefile;
	int total_packet;
	int filter_packet;
	int dual;
	u_char *pkt_buffer;
	int buffer_size;
};

static void filter_packet_cb(u_char *param, const struct pcap_pkthdr *header, const u_char *pkt_data)
{
	int res = 0,filter_flag = 0;
	struct Pcap_Loop_Param *plparam = (struct Pcap_Loop_Param*)param;
	Dbfw_EthernetFrame eth_frame;
	Meter_Packet_Info pkt_info;
	Meter_Broadcast_Id key;
	Meter_Broadcast_Rule_Value *rvalue = NULL;

	memset(&key,0,sizeof(key));
	memset(&eth_frame,0,sizeof(eth_frame));
	memset(&pkt_info,0,sizeof(pkt_info));
	eth_frame.frame_data = (u_char*)pkt_data;
	eth_frame.frame_size = header->len;
	plparam->total_packet++;
	res = Dbfw_Protocol_Parse(&eth_frame,&pkt_info,_Rule.server_rule);
	if(res != meter_proto_cs)
	{
		return;
	}

	filter_flag = 0;
	/*  ����� server_rule����ֱ�ӹ���server��client_rule�ͻ�ʧЧ  */
	if(dspr_hash_count(_Rule.server_rule))
	{
		if(_Global.ipport_flag == 0 || _Global.ipport_flag == 2)
		{
			if(pkt_info.ethernet.type == 0x0800)
			{
				key.ipaddr = pkt_info.ipv4_header.ip_srcaddr;
			}else{
				key.ipaddr = Dbfw_hash_xor_key16(pkt_info.ipv6_header.ip_srcaddr);
			}
		}
		if(_Global.ipport_flag == 0 || _Global.ipport_flag == 1)
		{
			key.port = pkt_info.tcp_header.source_port;
		}
		rvalue = (Meter_Broadcast_Rule_Value*)dspr_hash_find(
					_Rule.server_rule,&key,sizeof(Meter_Broadcast_Id));
		if(rvalue)
		{
			filter_flag = 1;
		}
		else
		{
		if(_Global.ipport_flag == 0 || _Global.ipport_flag == 2)
		{
			if(pkt_info.ethernet.type == 0x0800)
			{
				key.ipaddr = pkt_info.ipv4_header.ip_destaddr;
			}else{
				key.ipaddr = Dbfw_hash_xor_key16(pkt_info.ipv6_header.ip_destaddr);
			}
		}	
		if(_Global.ipport_flag == 0 || _Global.ipport_flag == 1)
		{
			key.port = pkt_info.tcp_header.dest_port;
		}
			rvalue = (Meter_Broadcast_Rule_Value*)dspr_hash_find(
						_Rule.server_rule,&key,sizeof(Meter_Broadcast_Id));
			if(rvalue)
			{
				filter_flag = 1;
			}
		}
	}
	else
	{
		if(dspr_hash_count(_Rule.client_rule) == 0)
		{
			filter_flag = 1;
		}
		else
		{
			if(_Global.ipport_flag == 0 || _Global.ipport_flag == 2)
			{
				if(pkt_info.ethernet.type == 0x0800)
				{
					key.ipaddr = pkt_info.ipv4_header.ip_srcaddr;
				}else{
					key.ipaddr = Dbfw_hash_xor_key16(pkt_info.ipv6_header.ip_srcaddr);
				}
			}
			if(_Global.ipport_flag == 0 || _Global.ipport_flag == 1)
			{
				key.port = pkt_info.tcp_header.source_port;
			}
			rvalue = (Meter_Broadcast_Rule_Value*)dspr_hash_find(
						_Rule.client_rule,&key,sizeof(Meter_Broadcast_Id));
			if(rvalue)
			{
				filter_flag = 1;
			}
			else
			{
				if(_Global.ipport_flag == 0 || _Global.ipport_flag == 2)
				{
				
					if(pkt_info.ethernet.type == 0x0800)
					{
						key.ipaddr = pkt_info.ipv4_header.ip_destaddr;
					}else{
						key.ipaddr = Dbfw_hash_xor_key16(pkt_info.ipv6_header.ip_destaddr);
					}
				}
				if(_Global.ipport_flag == 0 || _Global.ipport_flag == 1)
				{
					key.port = pkt_info.tcp_header.dest_port;
				}
				rvalue = (Meter_Broadcast_Rule_Value*)dspr_hash_find(
							_Rule.client_rule,&key,sizeof(Meter_Broadcast_Id));
				if(rvalue)
				{
					filter_flag = 1;
				}
			}
		}
	}

	if(filter_flag)
	{
		plparam->filter_packet++;
		if(plparam->dual == 0)
		{
			pcap_dump((u_char*)plparam->dumpfile, header, pkt_data);
			pcap_dump_flush(plparam->dumpfile);
		}
		else
		{
			if(mb_pkt_dct_request == pkt_info.direction)
			{
				pcap_dump((u_char*)plparam->dumpfile, header, pkt_data);
				pcap_dump_flush(plparam->dumpfile);
			}
			else if(mb_pkt_dct_response == pkt_info.direction)
			{
				pcap_dump((u_char*)plparam->responsefile, header, pkt_data);
				pcap_dump_flush(plparam->responsefile);
			}
		}
	}
}

int meter_process_filter_mode()
{
	char dumpname[1024],pcapfile[1024],*psep = NULL;
	struct Pcap_Loop_Param plparam;
	memset(&plparam,0,sizeof(plparam));

	plparam.dual = _Global.dual;
	memset(dumpname,0,sizeof(dumpname));
	memset(pcapfile,0,sizeof(pcapfile));
	strncpy(pcapfile,_Global.pcap_file_name,sizeof(pcapfile)-1);

	psep = strrchr(pcapfile,'.');
	if(psep)
	{
		*psep = 0;
	}

	if(plparam.dual == 0)
	{
		sprintf(dumpname,"%s-filter.pcap",pcapfile);
		plparam.dumpfile = pcap_dump_open(_Global.pp_file,dumpname);
	}
	else
	{
		sprintf(dumpname,"%s-request.pcap",pcapfile);
		plparam.dumpfile = pcap_dump_open(_Global.pp_file,dumpname);
		sprintf(dumpname,"%s-response.pcap",pcapfile);
		plparam.responsefile = pcap_dump_open(_Global.pp_file,dumpname);
	}
   	 pcap_loop(_Global.pp_file, 0, filter_packet_cb, (unsigned char *)&plparam);
	printf("\nMeter Filter: File:%s\n",dumpname);
	printf("Meter Filter: Total Packet:%d\n",plparam.total_packet);
	printf("Meter Filter: Filter Packet:%d\n",plparam.filter_packet);

	pcap_dump_close(plparam.dumpfile);
	if(plparam.dual)
	{
		pcap_dump_close(plparam.responsefile);
	}
	return 0;
}

static void modify_packet_cb(u_char *param, const struct pcap_pkthdr *header, const u_char *pkt_data)
{
	int res = 0;
	struct Pcap_Loop_Param *plparam = (struct Pcap_Loop_Param*)param;
	Dbfw_EthernetFrame eth_frame;
	Meter_Packet_Info pkt_info;
	Meter_Broadcast_Id key;
	Meter_Broadcast_Rule_Value *rvalue = NULL;

	memset(&eth_frame,0,sizeof(eth_frame));
	memset(&pkt_info,0,sizeof(pkt_info));
	eth_frame.frame_data = (u_char*)pkt_data;
	eth_frame.frame_size = header->len;
	plparam->total_packet++;
	res = Dbfw_Protocol_Parse(&eth_frame,&pkt_info,_Rule.server_rule);
	if(res != meter_proto_cs)
	{
		return;
	}
	memcpy(plparam->pkt_buffer,pkt_data,header->len);

	//修改服务器端地址
	if(mb_pkt_dct_request == pkt_info.direction)
	{
		if(pkt_info.ethernet.type == 0x0800)
		{
			key.ipaddr = pkt_info.ipv4_header.ip_destaddr;
		}else{
			key.ipaddr = Dbfw_hash_xor_key16(pkt_info.ipv6_header.ip_destaddr);
		}
		key.port = pkt_info.tcp_header.dest_port;
		rvalue = (Meter_Broadcast_Rule_Value*)dspr_hash_find(
					_Rule.server_rule,&key,sizeof(Meter_Broadcast_Id));
		if(rvalue)
		{
			if(rvalue->sim.ipaddr)
			{
				if(pkt_info.ethernet.type == 0x0800)
				{
					memcpy(plparam->pkt_buffer+pkt_info.ip_cursor+16,&rvalue->sim.ipaddr,sizeof(unsigned int));
				}else{
					memcpy(plparam->pkt_buffer+pkt_info.ip_cursor+24,&rvalue->sim_value.ipaddr,16);
				}
			}
			if(rvalue->sim.port)
			{
				memcpy(plparam->pkt_buffer+pkt_info.tcp_cursor+2,&rvalue->sim.port,sizeof(u_short));
			}
			plparam->filter_packet++;
		}
	}
	else if(mb_pkt_dct_response == pkt_info.direction)
	{
		if(pkt_info.ethernet.type == 0x0800)
		{
			key.ipaddr = pkt_info.ipv4_header.ip_srcaddr;
		}else{
			key.ipaddr = Dbfw_hash_xor_key16(pkt_info.ipv6_header.ip_srcaddr);
		}
		key.port = pkt_info.tcp_header.source_port;
		rvalue = (Meter_Broadcast_Rule_Value*)dspr_hash_find(
					_Rule.server_rule,&key,sizeof(Meter_Broadcast_Id));
		if(rvalue)
		{
			if(rvalue->sim.ipaddr)
			{
				if(pkt_info.ethernet.type == 0x0800)
				{
					memcpy(plparam->pkt_buffer+pkt_info.ip_cursor+12,&rvalue->sim.ipaddr,sizeof(unsigned int));
				}else{
					memcpy(plparam->pkt_buffer+pkt_info.ip_cursor+8,&rvalue->sim_value.ipaddr,16);
				}
			}
			if(rvalue->sim.port)
			{
				memcpy(plparam->pkt_buffer+pkt_info.tcp_cursor,&rvalue->sim.port,sizeof(u_short));
			}
			plparam->filter_packet++;
		}
	}

	//修改客户端地址
	if(mb_pkt_dct_request == pkt_info.direction)
	{
		if(pkt_info.ethernet.type == 0x0800)
		{
			key.ipaddr = pkt_info.ipv4_header.ip_srcaddr;
		}else{
			key.ipaddr = Dbfw_hash_xor_key16(pkt_info.ipv6_header.ip_srcaddr);
		}	
		key.port = pkt_info.tcp_header.source_port;
		rvalue = (Meter_Broadcast_Rule_Value*)dspr_hash_find(
					_Rule.client_rule,&key,sizeof(Meter_Broadcast_Id));
		if(rvalue)
		{
			if(rvalue->sim.ipaddr)
			{
				if(pkt_info.ethernet.type == 0x0800)
				{
					memcpy(plparam->pkt_buffer+pkt_info.ip_cursor+12,&rvalue->sim.ipaddr,sizeof(unsigned int));
				}else{
					memcpy(plparam->pkt_buffer+pkt_info.ip_cursor+8,&rvalue->sim_value.ipaddr,16);
				}
			}
			if(rvalue->sim.port)
			{
				memcpy(plparam->pkt_buffer+pkt_info.tcp_cursor,&rvalue->sim.port,sizeof(u_short));
			}
		}
	}
	else if(mb_pkt_dct_response == pkt_info.direction)
	{
		if(pkt_info.ethernet.type == 0x0800)
		{
			key.ipaddr = pkt_info.ipv4_header.ip_destaddr;
		}else{
			key.ipaddr = Dbfw_hash_xor_key16(pkt_info.ipv6_header.ip_destaddr);
		}
		key.port = pkt_info.tcp_header.dest_port;
		rvalue = (Meter_Broadcast_Rule_Value*)dspr_hash_find(
					_Rule.client_rule,&key,sizeof(Meter_Broadcast_Id));
		if(rvalue)
		{
			if(rvalue->sim.ipaddr)
			{
				if(pkt_info.ethernet.type == 0x0800)
				{
					memcpy(plparam->pkt_buffer+pkt_info.ip_cursor+16,&rvalue->sim.ipaddr,sizeof(unsigned int));
				}else{
					memcpy(plparam->pkt_buffer+pkt_info.ip_cursor+24,&rvalue->sim_value.ipaddr,16);
				}
			}
			if(rvalue->sim.port)
			{
				memcpy(plparam->pkt_buffer+pkt_info.tcp_cursor+2,&rvalue->sim.port,sizeof(u_short));
			}
		}
	}

	pcap_dump((u_char*)plparam->dumpfile, header, plparam->pkt_buffer);
	pcap_dump_flush(plparam->dumpfile);
}

int meter_process_modify_mode()
{
	char dumpname[1024],pcapfile[1024],*psep = NULL;
	struct Pcap_Loop_Param plparam;
	memset(&plparam,0,sizeof(plparam));

	memset(dumpname,0,sizeof(dumpname));
	memset(pcapfile,0,sizeof(pcapfile));
	strncpy(pcapfile,_Global.pcap_file_name,sizeof(pcapfile)-1);
	psep = strrchr(pcapfile,'.');
	if(psep)
	{
		*psep = 0;
	}
	sprintf(dumpname,"%s-modify.pcap",pcapfile);
	plparam.dumpfile = pcap_dump_open(_Global.pp_file,dumpname);

	plparam.buffer_size = 128*1024;
	plparam.pkt_buffer = (u_char*)malloc(plparam.buffer_size);
    pcap_loop(_Global.pp_file, 0, modify_packet_cb, (unsigned char *)&plparam);
	printf("\nMeter Modify: File:%s\n",dumpname);
	printf("Meter Modify: Total Packet:%d\n",plparam.total_packet);
	printf("Meter Modify: Modify Packet:%d\n",plparam.filter_packet);

	pcap_dump_close(plparam.dumpfile);
	if(plparam.dual)
	{
		pcap_dump_close(plparam.responsefile);
	}
	free(plparam.pkt_buffer);
	return 0;
}

static void stat_packet_cb(u_char *param, const struct pcap_pkthdr *header, const u_char *pkt_data)
{
//	char flagbuf[8];
	int res = 0;
//	int flag = 0;
//	unsigned int srcip = 0,dstip = 0;

	Dbfw_EthernetFrame eth_frame;
	Meter_Packet_Info pkt_info;
	Meter_Packet_Hdr pkt_hdr;

	param = NULL;
	memset(&eth_frame,0,sizeof(eth_frame));
	memset(&pkt_info,0,sizeof(pkt_info));
	eth_frame.frame_data = (u_char*)pkt_data;
	eth_frame.frame_size = header->len;
	res = Dbfw_Protocol_Parse(&eth_frame,&pkt_info,_Rule.server_rule);
	if(res <= 0)
	{
		return;
	}
	if(_Stat.total_packet == 0)
	{
		memcpy(&(_Stat.begin),&(header->ts),sizeof(struct timeval));
	}
	memcpy(&(_Stat.end),&(header->ts),sizeof(struct timeval));
	_Stat.total_packet++;
	_Stat.total_size+= header->len;
	if(res > METER_MAX_PROTO)
	{
		return;
	}
	_Stat.proto[res-1].total_packet++;
	_Stat.proto[res-1].total_size+= header->len;
	if(res == meter_proto_cs)
	{
		memset(&pkt_hdr,0,sizeof(pkt_hdr));
		pkt_hdr.sec = header->ts.tv_sec;
		pkt_hdr.usec = header->ts.tv_usec;
		pkt_hdr.caplen = header->caplen;
		pkt_hdr.len = header->len;
		session_register(_Sess_Hash,&pkt_hdr,&pkt_info);
		/*
		memset(flagbuf,0,sizeof(flagbuf));
		if(pkt_info.tcp_header.syn)
		{
			strcat(flagbuf,"S");
			flag = 1;
		}
		if(pkt_info.tcp_header.psh)
		{
			strcat(flagbuf,"P");
		}
		if(pkt_info.tcp_header.fin)
		{
			strcat(flagbuf,"F");
			flag = 1;
		}
		if(pkt_info.tcp_header.ack)
		{
			strcat(flagbuf,".");
		}

		if(flag)
		{
			char clientBuf[20],serverBuf[20];
			memset(clientBuf,0,sizeof(clientBuf));
			memset(serverBuf,0,sizeof(serverBuf));
			srcip = pkt_info.ipv4_header.ip_srcaddr;
			dstip = pkt_info.ipv4_header.ip_destaddr;
			srcip = DBFW_HTON32(srcip);
			dstip = DBFW_HTON32(dstip);
			meter_iptos(srcip,clientBuf);
			meter_iptos(dstip,serverBuf);
			if(pkt_info.direction == mb_pkt_dct_request)
			{
				printf("Meter Connect: %-8d %s:%-5d ---> %s:%-5d [%s]\n",
					_Stat.total_packet,
					clientBuf,pkt_info.tcp_header.source_port,
					serverBuf,pkt_info.tcp_header.dest_port,flagbuf);
			}
			else if(pkt_info.direction == mb_pkt_dct_response)
			{
				printf("Meter Connect: %-8d %s:%-5d <--- %s:%-5d [%s]\n",
					_Stat.total_packet,
					serverBuf,pkt_info.tcp_header.dest_port,
					clientBuf,pkt_info.tcp_header.source_port,flagbuf);
			}
		}
		*/
	}
	if(0 == (_Stat.total_packet % 100000))
	{
		printf("Meter Packet: Current Packet Count:%d\n",_Stat.total_packet);
	}
	if(param == NULL || param != NULL)
	return;
}

static char *_meter_proto_desc[] = {
	(char*)"Client/Server",
	(char*)"Ethernet",
	(char*)"Arp",
	(char*)"Ipv6",
	(char*)"Ip",
	(char*)"Icmp",
	(char*)"Udp",
	(char*)"Tcp",
	(char*)"Http",
	(char*)"Https",
	(char*)"Ssh",//11
	(char*)"Empty",
	(char*)"Empty",
	(char*)"Empty",
	(char*)"Empty",
	(char*)"Empty"
	};

int meter_process_stat_mode()
{
	int count = 0;
	struct tm *mytm = NULL;
	unsigned int elapsed = 0;
	float concurrency = 0.0;

	memset(&_Stat,0,sizeof(_Stat));
	printf("\nMeter Packet: Begin Stat ...\n");
    pcap_loop(_Global.pp_file, 0, stat_packet_cb,NULL);

	_Stat.end.tv_usec /= 1000;
	_Stat.begin.tv_usec /= 1000;
	elapsed = (_Stat.end.tv_sec - _Stat.begin.tv_sec)*1000 + (_Stat.end.tv_usec - _Stat.begin.tv_usec);

	printf("\nMeter Stat: Time Info:\n");
	mytm=localtime(&(_Stat.begin.tv_sec));
	printf("Meter Stat: Begin Time: %4d-%02d-%02d %02d:%02d:%02d.%03d\n",
		mytm->tm_year+1900,mytm->tm_mon+1,mytm->tm_mday,mytm->tm_hour,
		mytm->tm_min,mytm->tm_sec,(int)_Stat.begin.tv_usec);

	mytm=localtime(&(_Stat.end.tv_sec));
	printf("Meter Stat: Begin Time: %4d-%02d-%02d %02d:%02d:%02d.%03d\n",
		mytm->tm_year+1900,mytm->tm_mon+1,mytm->tm_mday,mytm->tm_hour,
		mytm->tm_min,mytm->tm_sec,(int)_Stat.end.tv_usec);

	elapsed /= 1000;
	printf("Meter Stat: Capture Elapsed Time: %-4u seconds\n",elapsed);

	printf("\nMeter Stat: Concurrency Info:\n");
	dspr_hash_enum(_Sess_Hash,session_time_stat_cb,NULL);
	printf("Meter Stat: Total Session: %d\n",dspr_hash_count(_Sess_Hash));
	_Stat.total_session_time /= 1000;
	printf("Meter Stat: Total Session Elapsed Time: %-4u seconds\n",_Stat.total_session_time);
	concurrency = (float)_Stat.total_session_time/(float)elapsed;
	printf("Meter Stat: Average Session Concurrency: %.1f per second\n",concurrency);

	printf("Meter Stat: Total Duplicate Session: %d\n",_Stat.duplicate_session);
	printf("Meter Stat: Total Duplicate Packet: %d\n",_Stat.duplicate_packet);
	printf("Meter Stat: Total Duplicate Size: %d\n",_Stat.duplicate_size);

	printf("\nMeter Stat: Report Protocol Info:\n");
	for(count=0;count<meter_proto_ssh;count++)
	{
		printf("Meter Stat: %15s  %-6u  %-6u\n",
			_meter_proto_desc[count],_Stat.proto[count].total_packet,_Stat.proto[count].total_size);
	}
	printf("Meter Stat: %15s  %-6u  %-6u\n",
		"Total",_Stat.total_packet,_Stat.total_size);

	printf("\nMeter Stat: Report Session Info:\n");
	session_stat(_Sess_Hash);
	server_stat();
	return 0;
}

static void split_close_cb(dspr_hash_node_t *node,void *param)
{
	Meter_Session_HashValue *mhvalue = (Meter_Session_HashValue*)dspr_hash_node_get_value(node);
	if(mhvalue->dumpfile)
	{
		pcap_dump_close(mhvalue->dumpfile);
		session_stat_cb(node,param);
	}
}

int meter_process_split_mode()
{
	char dumpname[1024],pcapfile[512];
	char *psep = NULL;
	int res = 0;
	struct pcap_pkthdr *header = NULL;
	const u_char *pkt_data = NULL;
	Dbfw_EthernetFrame eth_frame;
	Meter_Packet_Info pkt_info;

	Meter_Session_HashKey mhkey;
	Meter_Session_HashValue *mhvalue = NULL;

	struct stat_cb_param_s param;

	memset(pcapfile,0,sizeof(pcapfile));
	strncpy(pcapfile,_Global.pcap_file_name,sizeof(pcapfile)-1);

	psep = strrchr(pcapfile,'.');
	if(psep)
	{
		*psep = 0;
	}

	printf("\nMeter Split: Begin split pcap file...\n");
	fseek(_Global.fp_file,_Global.begin_offset,SEEK_SET);
	while((res = pcap_next_ex(_Global.pp_file, &header, &pkt_data)) >= 0)
	{
		memset(&eth_frame,0,sizeof(eth_frame));
		memset(&pkt_info,0,sizeof(pkt_info));
		eth_frame.frame_data = (u_char*)pkt_data;
		eth_frame.frame_size = header->len;
		res = Dbfw_Protocol_Parse(&eth_frame,&pkt_info,_Rule.server_rule);
		if(res != meter_proto_cs)
		{
			continue;
		}
		session_create_key(&pkt_info,&mhkey);
		mhvalue = (Meter_Session_HashValue*)dspr_hash_find(_Sess_Hash,&mhkey,sizeof(Meter_Session_HashKey));
		if(NULL == mhvalue)
		{
			mhvalue = (Meter_Session_HashValue*)malloc(sizeof(Meter_Session_HashValue));
			if(mhvalue)
			{
				memset(mhvalue,0,sizeof(Meter_Session_HashValue));
				memcpy(&(mhvalue->key),&mhkey,sizeof(Meter_Session_HashKey));
				memset(dumpname,0,sizeof(dumpname));
//				memset(clientBuf,0,sizeof(clientBuf));
//				memset(serverBuf,0,sizeof(serverBuf));
//				meter_iptos(mhkey.client_ip,clientBuf);
//				meter_iptos(mhkey.server_ip,serverBuf);
				sprintf(dumpname,"%s-%s.%d-%s.%d.pcap",pcapfile,
					mhkey.client_ip_str,mhkey.client_port,mhkey.server_ip_str,mhkey.server_port);
				mhvalue->dumpfile = pcap_dump_open(_Global.pp_file,dumpname);
				printf("Meter Split: new file '%s'\n",dumpname);
				dspr_hash_insert(_Sess_Hash,&(mhvalue->key),sizeof(Meter_Session_HashKey),mhvalue,0,0);
			}
		}

		if(NULL == mhvalue)
		{
			continue;
		}
		if(pkt_info.tcp_header.syn)
		{
			mhvalue->syn_flag = 1;
		}
		if(pkt_info.tcp_header.fin)
		{
			mhvalue->fin_flag = 1;
		}

		mhvalue->total_packet++;
		mhvalue->total_size += header->len;
		if(mhvalue->dumpfile)
		{
			pcap_dump((u_char*)mhvalue->dumpfile, header, pkt_data);
			pcap_dump_flush(mhvalue->dumpfile);
		}
	}
	printf("\nMeter Split: Report Session Info:\n");
	memset(&param,0,sizeof(stat_cb_param_s));
	dspr_hash_enum(_Sess_Hash,split_close_cb,&param);
	printf("Meter Split: Split pcap file success\n");
	return 0;
}

int meter_process_clean_mode()
{
	int res = 0;
	char dumpname[1024],pcapfile[1024],*psep = NULL;
	struct Pcap_Loop_Param plparam;
	struct pcap_pkthdr *header = NULL;
	const u_char *pkt_data = NULL;
	Dbfw_EthernetFrame eth_frame;
	Meter_Packet_Info pkt_info;
	Meter_Session_HashKey mhkey;
	Meter_Session_HashValue *mhvalue = NULL;
	int node_count = 0,synfin_count = 0;

	memset(&plparam,0,sizeof(plparam));
	memset(dumpname,0,sizeof(dumpname));
	memset(pcapfile,0,sizeof(pcapfile));
	strncpy(pcapfile,_Global.pcap_file_name,sizeof(pcapfile)-1);
	psep = strrchr(pcapfile,'.');
	if(psep)
	{
		*psep = 0;
	}

	sprintf(dumpname,"%s-clean.pcap",pcapfile);
	plparam.dumpfile = pcap_dump_open(_Global.pp_file,dumpname);


	memset(&_Stat,0,sizeof(_Stat));
	printf("\nMeter Packet: Begin Stat ...\n");
    pcap_loop(_Global.pp_file, 0, stat_packet_cb,NULL);

	fseek(_Global.fp_file,_Global.begin_offset,SEEK_SET);
	while((res = pcap_next_ex(_Global.pp_file, &header, &pkt_data)) >= 0)
	{
		memset(&eth_frame,0,sizeof(eth_frame));
		memset(&pkt_info,0,sizeof(pkt_info));
		eth_frame.frame_data = (u_char*)pkt_data;
		eth_frame.frame_size = header->len;
		res = Dbfw_Protocol_Parse(&eth_frame,&pkt_info,_Rule.server_rule);
		if(res != meter_proto_cs)
		{
			continue;
		}
		session_create_key(&pkt_info,&mhkey);
		mhvalue = (Meter_Session_HashValue*)dspr_hash_find(_Sess_Hash,&mhkey,sizeof(Meter_Session_HashKey));
		if(mhvalue == NULL)
		{
			continue;
		}
		node_count = 0;
		synfin_count = 0;
		while(mhvalue)
		{
			node_count++;
			if(mhvalue->syn_flag && mhvalue->fin_flag)
			{
				synfin_count++;
			}
			mhvalue = mhvalue->next;
		}
		if(node_count == synfin_count)
		{
			pcap_dump((u_char*)plparam.dumpfile, header, pkt_data);
			pcap_dump_flush(plparam.dumpfile);
		}
	}
	pcap_dump_close(plparam.dumpfile);
	return 0;
}

/*
static void rule_stat_cb(dspr_hash_node_t *node,void *param)
{
	Meter_Broadcast_Rule_Value *rvalue = (Meter_Broadcast_Rule_Value*)dspr_hash_node_get_value(node);
	char srcbuf[20],simbuf[20];
	unsigned int srcip = 0;

	param = NULL;
	memset(srcbuf,0,sizeof(srcbuf));
	memset(simbuf,0,sizeof(simbuf));

	srcip = rvalue->key.ipaddr;
	srcip = DBFW_HTON32(srcip);

	meter_iptos(srcip,srcbuf);
	meter_iptos(rvalue->sim.ipaddr,simbuf);
	printf("Meter Rule: Source Address %s:%d  Simulate Address %s:%d\n",
		srcbuf,rvalue->key.port,simbuf,rvalue->sim.port);

}
*/

static int discard_packet_insert(char *packet)
{
//	printf("discard_packet_insert %s\n",packet);
	Meter_Discard_HashKey *key = NULL;
	char *port = NULL,*sequence = NULL;
	unsigned int ipbottom = 0,iptop = 0;

	port = strchr(packet,':');
	sequence = strrchr(packet,'.');
	if(port == NULL || sequence == NULL)
		return -1;
	if(port > sequence)
		return -2;
	*port++ = 0;
	*sequence++ = 0;
	parse_single_ipaddr(packet,&ipbottom,&iptop);

	key = (Meter_Discard_HashKey*)malloc(sizeof(Meter_Discard_HashKey));
	if(key == NULL)
	{
		return -1;
	}
	memset(key,0,sizeof(Meter_Discard_HashKey));
	key->ipaddr = ipbottom;
	key->port = atoi(port);
	key->sequence = atoi(sequence);
//	hex_print("discard_packet_insert",(const unsigned char*)key,sizeof(Meter_Discard_HashKey));
	dspr_hash_insert(_Discard_Hash,key,sizeof(Meter_Discard_HashKey),key,0,0);
	return 0;
}

static int specified_discard_init()
{
	FILE * fp_inifile=NULL;
	char linebuf[1024];
	char *interval = NULL;

	if(_Global.discard_file_name == NULL)
	{
		return 0;
	}

	fp_inifile=fopen(_Global.discard_file_name,"r");
	if(!fp_inifile)
	{
		printf("Meter Error: open discard file failed. %s  %s",
		_Global.discard_file_name,strerror(errno));
		return -2;
	}

	_Discard_Hash = dspr_hash_new();
	dspr_hash_init(_Discard_Hash,(char*)"DiscardHash",10000,NULL,NULL,NULL);

	memset(linebuf,0,sizeof(linebuf));
	while(fgets(linebuf,sizeof(linebuf)-1,fp_inifile))
	{
		if(linebuf[0]=='#' || linebuf[0]=='\r' || linebuf[0]=='\n')
		{
			memset(linebuf,0,sizeof(linebuf));
			continue;
		}
		if(linebuf[0]=='[' && strchr(linebuf,']'))
		{
			memset(linebuf,0,sizeof(linebuf));
			continue;
		}
		interval = strchr(linebuf,'=');
		if(interval == NULL)
		{
			memset(linebuf,0,sizeof(linebuf));
			continue;
		}
		*interval = 0;
		interval++;
		if(strcmp(linebuf,"discard_packet") == 0)
		{
			discard_packet_insert(interval);
		}

		memset(linebuf,0,sizeof(linebuf));
	}
	fclose(fp_inifile);
	return 0;
}

static int meter_exit()
{
	if(_Global.pp_file)
		pcap_close(_Global.pp_file);
	if(_Global.pp_dev)
		pcap_close(_Global.pp_dev);
	if(_Sess_Hash)
		dspr_hash_destroy(&_Sess_Hash);
	if(_Server_Rslist){
		Rslist_Destroy(_Server_Rslist);
		free(_Server_Rslist);
	}
	return 0;
}

static char *_meter_mode_desc[] = {
	(char*)"Unknown",
	(char*)"Client/Server",
	(char*)"All Package",
	(char*)"Filter Package",
	(char*)"Split File",
	(char*)"Stat File",
	(char*)"Clean File",
	(char*)"Modify File",
	(char*)"",
	(char*)"",
	(char*)"",
	(char*)""
};

int main(int argc, char *argv[])
{
	char errbuf[PCAP_ERRBUF_SIZE];
	Rslist_Config config;
	uint8_t *start_addr = NULL;
	int pps_min = 1000000/METER_PPS_USLEEP;
	int sess_num = 0,concurrency_total = 0;
	int sess_max_old = 0;

	memset(&_Global,0,sizeof(Meter_Broadcast_Global));
	_Global.mode = meter_mode_cs;
	_Global.worker_max = 1;//默认线程�?
	_Global.loop_max = 1;
	_Global.interval = METER_DEF_INTERVAL;
	_Global.start_interval = METER_DEF_START_INTERVAL;
	_Global.syn_delay = 0;
	_Global.pkt_per_sec = METER_DEF_PPS;//默认每秒钟的包个�?
	_Global.pkt_per_interval = 0;
	_Global.savepkt_flag = 0;
	_Global.concurrency_max = METER_MAX_CONCURRENCY;
	_Global.max_memory = METER_DEFAULT_MAX_MEMORY*1048576;

	memset(&_Rule,0,sizeof(Meter_Broadcast_Rule));
	_Rule.client_rule = dspr_hash_new();
	dspr_hash_init(_Rule.client_rule,(char*)"ClientRule",4096,NULL,NULL,NULL);
	_Rule.server_rule = dspr_hash_new();
	dspr_hash_init(_Rule.server_rule,(char*)"ServerRule",4096,NULL,NULL,NULL);

	//解析参数
	argument_parse(argc,argv);
	_Global.interval *= 1000;
	_Global.start_interval *= 1000;
	if(_Global.pkt_per_sec > 0 && _Global.pkt_per_sec < pps_min)
		_Global.pkt_per_sec = pps_min;
	if(_Global.pkt_per_sec < 0)
		_Global.pkt_per_sec = 0;
	_Global.pkt_per_interval = _Global.pkt_per_sec/pps_min;
	if(meter_mode_all == _Global.mode)
	{
		_Global.worker_max = 1;
	}

	printf("Meter Info:  meter_broadcast version:%s  libpcap version:%s\n",VERSION,pcap_lib_version());
	printf("Meter Info:  Mode '%s'  Interface '%s'  Pcap_File '%s'\n",
			_meter_mode_desc[_Global.mode],_Global.interface_name,_Global.pcap_file_name);
	printf("Meter Info:  Worker Count %d  Loop Count %d  Interval %d msec  Package/Second %d Start Interval %d\n",
		_Global.worker_max,_Global.loop_max,_Global.interval,_Global.pkt_per_sec,_Global.start_interval);
	printf("Meter Info:  Random Discard: %d   Discard File:%s\n",
			_Global.ramdom_discard,_Global.discard_file_name?_Global.discard_file_name:"No");

	//dspr_hash_enum(_Rule.client_rule,rule_stat_cb,NULL);

	/* Open the pcap file */
	if ((_Global.pp_file = pcap_open_offline(_Global.pcap_file_name,errbuf)) == NULL)
	{
		fprintf(stderr,"\nMeter Error: Unable to open the pcap file:%s %s\n",_Global.pcap_file_name,errbuf);
		return 2;
	}

	//获取文件信息
	_Global.fp_file = pcap_file(_Global.pp_file);
	_Global.begin_offset = ftell(_Global.fp_file);
	fseek(_Global.fp_file,0,SEEK_END);
	_Global.file_size = ftell(_Global.fp_file);
	fseek(_Global.fp_file,_Global.begin_offset,SEEK_SET);
	if(_Global.file_size > (unsigned int)_Global.max_memory)
	{
		_Global.is_big_file = 1;
		_Global.worker_max = 1;
	}
	printf ("Meter Info: File Size %u  Big File? %s\n",_Global.file_size,_Global.is_big_file?"Yes":"No");

	_Sess_Hash = dspr_hash_new();
	dspr_hash_init(_Sess_Hash,(char*)"SessionHash",10000,NULL,NULL,NULL);

	memset(&config,0,sizeof(Rslist_Config));
	config.total_kbsize = 4096;
	config.max_slot = 1;
//	config.verbose = 1;
	config.user_data_size = sizeof(Meter_Server_Listen_Value);
	start_addr = (uint8_t*)malloc(config.total_kbsize*1024);

	memset(errbuf,0,sizeof(errbuf));
	_Server_Rslist = Rslist_Init(start_addr,&config,errbuf);
	if(_Server_Rslist == NULL)
		printf("Meter Error: Rslist_Init error:%s\n",errbuf);

	memset(&config,0,sizeof(Rslist_Config));
	config.total_kbsize = 2048;
	config.max_slot = 1;
//	config.verbose = 1;
	config.user_data_size = sizeof(Meter_Server_Ip_Value);
	start_addr = (uint8_t*)malloc(config.total_kbsize*1024);

	memset(errbuf,0,sizeof(errbuf));
	_ServerIp_Rslist = Rslist_Init(start_addr,&config,errbuf);
	if(_ServerIp_Rslist == NULL)
		printf("Meter Error: Rslist_Init error:%s\n",errbuf);

	//处理过滤模式
	if(meter_mode_filter == _Global.mode)
	{
		meter_process_filter_mode();
		meter_exit();
		printf ("\nMeter Info: Filter mode successfully quit\n");
		return 0;
	}
	//处理分拆模式
	else if(meter_mode_split == _Global.mode)
	{
		meter_process_split_mode();
		meter_exit();
		printf ("\nMeter Info: Split mode successfully quit\n");
		return 0;
	}
	//清理pcap文件模式
	else if(meter_mode_clean == _Global.mode)
	{
		meter_process_clean_mode();
		meter_exit();
		printf ("\nMeter Info: Clean mode successfully quit\n");
		return 0;
	}
	//修改pcap文件模式
	else if(meter_mode_modify == _Global.mode)
	{
		meter_process_modify_mode();
		meter_exit();
		printf ("\nMeter Info: Modify mode successfully quit\n");
		return 0;
	}
	//处理统计模式
	else if(meter_mode_stat == _Global.mode)
	{
		meter_process_stat_mode();
		meter_exit();
		printf ("\nMeter Info: Stat mode successfully quit\n");
		return 0;
	}
	if(_Global.savepkt_flag != 1)
	{
		/* 打开网卡设备*/
		if ((_Global.pp_dev = pcap_open_live(_Global.interface_name,		// name of the device
							 65536,	// portion of the packet to capture. It doesn't matter in this case
							 1,	// promiscuous mode (nonzero means promiscuous)
							 1000,			// read timeout
							 errbuf			// error buffer
							 )) == NULL)
		{
			fprintf(stderr,"\nMeter Error: Unable to open the adapter:%s\n",_Global.interface_name);
			meter_exit();
			return 2;
		}
	}
/*
	pcap_set_buffer_size(_Global.pp_dev,8192);
	int fd = pcap_get_selectable_fd(_Global.pp_dev);
	int optvalue=8192;
	int optlen = sizeof(optvalue);
	if(setsockopt(fd, SOL_SOCKET, SO_SNDBUF,(void*)&optvalue, optlen) == -1)
	{
		printf("Meter Error: set SO_SNDBUF failed %s\n",strerror(errno));
	}
	optvalue=8192;
	if(setsockopt(fd, SOL_SOCKET, SO_RCVBUF,(void*)&optvalue, optlen) == -1)
	{
		printf("Meter Error: set SO_RCVBUF failed %s\n",strerror(errno));
	}
	printf("Meter Info: setsockopt success\n");
*/

	specified_discard_init();

	if(0 == _Global.is_big_file)
	{
		//如果不是大文件，则启用Cache机制，把文件中的包读取到Cache，这样以后再操作速度就快了�?
		memset(&_Cache,0,sizeof(Meter_Broadcast_Cache));
		if(cache_init(&_Global,&_Cache) < 0)
		{
			meter_exit();
			printf ("Meter Error: Read pcap file failed!\n");
			return 1;
		}
		if(meter_mode_all == _Global.mode)
		{
			_Global.worker_max = 1;
			meter_broadcast_cache();
			goto meter_quit;
		}
		session_stat(_Sess_Hash);
		sess_num = dspr_hash_count(_Sess_Hash);
		if(sess_num == 0)
		{
			printf("Meter Error: not find session in file %s\n",_Global.pcap_file_name);
			goto meter_quit;
		}

		if(_Global.short_connect && (sess_num > 1))
		{
			printf("Meter Error: argument '--short-connect' only support 1 session in pcap file '%s'\n",
					_Global.pcap_file_name);
			printf("Meter Note: You can use '--mode split' to split pcap file,then run with '--short-connect'\n");
			goto meter_quit;
		}

		concurrency_total = _Global.worker_max * sess_num;
		if(concurrency_total > _Global.concurrency_max)
		{
			sess_max_old = _Global.worker_max;
			_Global.worker_max = _Global.concurrency_max/sess_num;
			_Global.worker_max = (_Global.worker_max == 0)?1:_Global.worker_max;
			printf("Meter Notice: total concurrency(%d = %d * %d) > meter concurrency(%d), adjust worker number %d to %d\n",
				concurrency_total,sess_max_old,sess_num,_Global.concurrency_max,sess_max_old,_Global.worker_max);
		}
		meter_broadcast_cache();
	}
	else
	{
		Meter_Broadcast_Cache_Control control;
		memset(&control,0,sizeof(Meter_Broadcast_Cache_Control));
		control.id = 1;
		control.loop_max = _Global.loop_max;
		random_discard_init(&control);
		meter_broadcast_file_loop(&control);
	}

meter_quit:
	meter_exit();
	printf ("\nMeter Info: Broadcast successfully quit\n");
	return 0;
}

static void usage(char *progname)
{
	printf("\nVersion:%s  %s  Build %s %s\n",
		VERSION,pcap_lib_version(),BUILD_DATE,BUILD_SVN);

	printf("\nUasge: %s [option] [interface] pcap_file\n",progname);
	printf("Option:\n");
	printf("\t--mode cs/all/filter/split/stat/clean/modify  mode(default:cs)\n");
	printf("\t--savepkt		in cs&all mode, save the packet without send it\n");
	printf("\t--worker count          worker count (default:1)\n");
	printf("\t--loop count            loop count (default:1)\n");
	printf("\t--pps num               packet percent second (default:%d)\n",METER_DEF_PPS);
	printf("\t--sequence sequence     start sequence\n");
	printf("\t--server ip:port        specify server ipaddr and port\n");
	printf("\t--client src_ip:port%ssim_ip:port  replace client ipaddr and port\n",METER_REPLACE_SEP);
	printf("\t--interval msec         interval (default:%d)\n",METER_DEF_INTERVAL);
	printf("\t--concurrency num       max concurrency (default:%d)\n",METER_MAX_CONCURRENCY);
	printf("\t--start-interval msec   start interval for worker(default:%d)\n",METER_DEF_START_INTERVAL);
	printf("\t--syn-delay msec        delay after syn(default:0)\n");
	printf("\t--dual                  dual link\n");
	printf("\t--short-connect         use short connect type broadcast\n");
	printf("\t--big-file mbsize       the big file flag of minimum boundary\n");
	printf("\t--specified-discard file  the file of discard packet\n");
	printf("\t--random-discard discard-rate  the rate of discard,permillage\n");
	printf("\t--verbose number        print packet info\n");

	printf("\nFor Example:\n");
	printf("./meter_broadcast --mode stat loadrunner.pcap\n");
	printf("./meter_broadcast --mode filter loadrunner.pcap\n");
	printf("./meter_broadcast --mode cs --worker 3 --loop 3 --savepkt loadrunner.pcap\n");
	printf("./meter_broadcast --mode filter --client 192.168.1.105:11694 --client 192.168.1.105:13985 bug149.pcap\n");
	printf("./meter_broadcast --mode split loadrunner.pcap\n");
	printf("./meter_broadcast --mode clean loadrunner.pcap\n");
	printf("./meter_broadcast --mode modify --server 192.168.1.24:1523=192.168.1.24:7777 loadrunner.pcap\n");
	printf("./meter_broadcast eth0 loadrunner.pcap\n");
	printf("./meter_broadcast --worker 2 --loop 10 eth3 loadrunner.pcap\n");
	printf("./meter_broadcast --worker 2 --loop 10 --client 192.168.1.55:47336=192.168.5.4:43215 --client 192.168.1.105:1433=192.168.3.105:1533 bug149-filter.pcap\n");

	printf("\nNote:\n");
	printf("with 'Message too long' error,run command on send machine and recv machine\n");
	printf("[root@localhost]#/sbin/ifconfig eth3 mtu 8192\n\n");

	exit(0);
}

static int argument_replace_rule(char *data,dspr_hash_t *phash)
{
	Meter_Broadcast_Rule_Value *rvalue = NULL,*ovalue = NULL;
	char buffer[256],*ppos = NULL,*pport = NULL;;
	unsigned int ipbottom = 0,iptop = 0,port = 0;
	_Global.ipport_flag =  0;

	rvalue = (Meter_Broadcast_Rule_Value*)malloc(sizeof(Meter_Broadcast_Rule_Value));
	if(NULL == rvalue)
	{
		return -1;
	}
	memset(rvalue,0,sizeof(Meter_Broadcast_Rule_Value));
	memset(buffer,0,sizeof(buffer));
	memcpy(buffer,data,sizeof(buffer)-1);

	/* ����� */
	if(strchr(buffer,':') == NULL && strchr(buffer,'.') == NULL)
		_Global.ipport_flag = 1;
	/* ���ip */
	if(strchr(buffer,':') == NULL && strchr(buffer,'.'))
		_Global.ipport_flag = 2;

	ppos = strstr(buffer,METER_REPLACE_SEP);
	if(ppos)
	{
		*ppos = 0;
		ppos += strlen(METER_REPLACE_SEP);
	}
	pport = strchr(buffer,':');
	if(pport)
	{
		*pport++ = 0;
		rvalue->key.port = atoi(pport);
		rvalue->key_value.port = atoi(pport);
	}
	if(_Global.ipport_flag == 1)
	{
		rvalue->key.port = atoi(data);
		rvalue->key_value.port = atoi(data);
	}

	if(strchr(buffer,'.') != NULL)
	{//ipv4
		parse_single_ipaddr(buffer,&ipbottom,&iptop);
		rvalue->key.ipaddr = ipbottom;
		memcpy(rvalue->key_value.ipaddr,buffer, 16);
	}
	else if(strchr(buffer,':') != NULL)
	{
		u_int64 dbserver_ip_int[2];
		Dbfw_common_ipv6_string_2_array((char *)buffer, (u_char *)dbserver_ip_int);
		rvalue->key.ipaddr = Dbfw_hash_xor_key16(dbserver_ip_int);
		memcpy(rvalue->key_value.ipaddr,dbserver_ip_int, 16);
	}

	if(ppos)
	{
		pport = strchr(ppos,':');
		if(pport)
		{
			*pport++ = 0;
			port = atoi(pport);
			rvalue->sim.port = DBFW_HTON16(port);
//			rvalue->sim_value.port = DBFW_HTON16(pport);
		}
		if(strchr(ppos, '.') != NULL)
		{
			parse_single_ipaddr(ppos,&ipbottom,&iptop);
			rvalue->sim.ipaddr = DBFW_HTON32(ipbottom);//sim 地址需要字节转�?
		}else{
			u_int64 dbserver_ip_int[2];
			Dbfw_common_ipv6_string_2_array((char *)ppos, (u_char *)dbserver_ip_int);
			rvalue->sim.ipaddr = Dbfw_hash_xor_key16(dbserver_ip_int);
			memcpy(rvalue->sim_value.ipaddr,dbserver_ip_int, 16);
		}
	}
	ovalue = (Meter_Broadcast_Rule_Value*)dspr_hash_find(
			phash,&(rvalue->key),sizeof(Meter_Broadcast_Id));
	if(NULL == ovalue)
	{
//		hex_print("Meter Info:",(unsigned char*)&(rvalue->key),sizeof(Meter_Broadcast_Id));
		dspr_hash_insert(phash,&(rvalue->key),sizeof(Meter_Broadcast_Id),rvalue,0,0);
	}
	else
	{
		printf("Meter Error: Repeat Ipaddr '%s'\n",data);
		free(rvalue);
		return -2;
	}

	return 0;
}

static int argument_parse(int argc,char *argv[])
{
	int arg_num = argc - 1,i;

	if(argc < 3)
	{
		usage(argv[0]);
		return 0;
	}
	_Global.pcap_file_name = argv[argc - 1];

	for(i = 1; i < arg_num; i++)
	{
		if(i == arg_num - 1)
		{
			if(meter_mode_cs == _Global.mode || meter_mode_all == _Global.mode)
			{
				if(0 == strcmp(argv[i],"--savepkt"))	
				{
					_Global.savepkt_flag = 1;
					break;
				}
				else
				{
					if(_Global.savepkt_flag == 0)
					{
						_Global.interface_name = argv[i];
						break;
					}
				}
			}
			else
			{
				_Global.savepkt_flag = 0;
			}
		}
		if(0 == strcmp(argv[i],"--mode"))
		{
			if(i >= arg_num-1){
				printf("Meter Error: argument '%s' error\n",argv[i]);
				usage(argv[0]);
				return -1;
			}
			i++;
			if(0 == strcmp(argv[i],"cs"))
			{
				_Global.mode = meter_mode_cs;
			}
			else if(0 == strcmp(argv[i],"all"))
			{
				_Global.mode = meter_mode_all;
			}
			else if(0 == strcmp(argv[i],"filter"))
			{
				_Global.mode = meter_mode_filter;
			}
			else if(0 == strcmp(argv[i],"split"))
			{
				_Global.mode = meter_mode_split;
			}
			else if(0 == strcmp(argv[i],"stat"))
			{
				_Global.mode = meter_mode_stat;
			}
			else if(0 == strcmp(argv[i],"clean"))
			{
				_Global.mode = meter_mode_clean;
			}
			else if(0 == strcmp(argv[i],"modify"))
			{
				_Global.mode = meter_mode_modify;
			}
		}
		else if(0 == strcmp(argv[i],"--worker"))
		{
			if(i >= arg_num - 1){
				printf("Meter Error: argument '%s' error\n",argv[i]);
				usage(argv[0]);
				return -1;
			}
			i++;
			_Global.worker_max = atoi(argv[i]);
			_Global.worker_max = (_Global.worker_max < 1)?1:_Global.worker_max;
			_Global.worker_max = (_Global.worker_max > 10000)?10000:_Global.worker_max;
		}
		else if(0 == strcmp(argv[i],"--loop"))
		{
			if(i >= arg_num-1){
				printf("Meter Error: argument '%s' error\n",argv[i]);
				usage(argv[0]);
				return -1;
			}
			i++;
			_Global.loop_max = atoi(argv[i]);
			_Global.loop_max = (_Global.loop_max < 1)?1:_Global.loop_max;
		}
		else if(0 == strcmp(argv[i],"--pps"))
		{
			if(i >= arg_num-1){
				printf("Meter Error: argument '%s' error\n",argv[i]);
				usage(argv[0]);
				return -1;
			}
			i++;
			_Global.pkt_per_sec = atoi(argv[i]);
		}
		else if(0 == strcmp(argv[i],"--server"))
		{
			if(i >= arg_num-1){
				printf("Meter Error: argument '%s' error\n",argv[i]);
				usage(argv[0]);
				return -1;
			}
			i++;
			argument_replace_rule(argv[i],_Rule.server_rule);
		}
		else if(0 == strcmp(argv[i],"--client"))
		{
			if(i >= arg_num-1){
				printf("Meter Error: argument '%s' error\n",argv[i]);
				usage(argv[0]);
				return -1;
			}
			i++;
			argument_replace_rule(argv[i],_Rule.client_rule);
		}
		else if(0 == strcmp(argv[i],"--sequence"))
		{
			if(i >= arg_num-1){
				printf("Meter Error: argument '%s' error\n",argv[i]);
				usage(argv[0]);
				return -1;
			}
			i++;
			_Global.sequence = strtoul(argv[i],NULL,10);
		}
		else if(0 == strcmp(argv[i],"--interval"))
		{
			if(i >= arg_num-1){
				printf("Meter Error: argument '%s' error\n",argv[i]);
				usage(argv[0]);
				return -1;
			}
			i++;
			_Global.interval = atoi(argv[i]);
		}
		else if(0 == strcmp(argv[i],"--concurrency"))
		{
			if(i >= arg_num-1){
				printf("Meter Error: argument '%s' error\n",argv[i]);
				usage(argv[0]);
				return -1;
			}
			i++;
			_Global.concurrency_max = atoi(argv[i]);
		}
		else if(0 == strcmp(argv[i],"--start-interval"))
		{
			if(i >= arg_num-1){
				printf("Meter Error: argument '%s' error\n",argv[i]);
				usage(argv[0]);
				return -1;
			}
			i++;
			_Global.start_interval = atoi(argv[i]);
		}
		else if(0 == strcmp(argv[i],"--syn-delay"))
		{
			if(i >= arg_num - 1){
				printf("Meter Error: argument '%s' error\n",argv[i]);
				usage(argv[0]);
				return -1;
			}
			i++;
			_Global.syn_delay = atoi(argv[i]) * 1000;
		}
		else if(0 == strcmp(argv[i],"--dual"))
		{
			_Global.dual = 1;
		}
		else if(0 == strcmp(argv[i],"--short-connect"))
		{
			_Global.short_connect = 1;
		}
		else if(0 == strcmp(argv[i],"--savepkt"))
		{
			_Global.savepkt_flag = 1;
		}
		else if(0 == strcmp(argv[i],"--big-file"))
		{
			if(i >= arg_num - 1){
				printf("Meter Error: argument '%s' error\n",argv[i]);
				usage(argv[0]);
				return -1;
			}
			i++;
			_Global.max_memory = atoi(argv[i]);
			if(_Global.max_memory > 1024 || _Global.max_memory < 1)
				_Global.max_memory = METER_DEFAULT_MAX_MEMORY;
			_Global.max_memory *= 1048576;
		}
		else if(0 == strcmp(argv[i],"--specified-discard"))
		{
			if(i >= arg_num - 1){
				printf("Meter Error: argument '%s' error\n",argv[i]);
				usage(argv[0]);
				return -1;
			}
			i++;
			_Global.discard_file_name = argv[i];
		}
		else if(0 == strcmp(argv[i],"--random-discard"))
		{
			int rate = 0;
			if(i >= arg_num - 1){
				printf("Meter Error: argument '%s' error\n",argv[i]);
				usage(argv[0]);
				return -1;
			}
			i++;
			rate = atoi(argv[i]);
			if(rate > 0 && rate < 1000)
				_Global.ramdom_discard = rate;
		}
		else if(0 == strcmp(argv[i],"--verbose"))
		{
			if(i >= arg_num-1){
				printf("Meter Error: argument '%s' error\n",argv[i]);
				usage(argv[0]);
				return -1;
			}
			i++;
			_Global.verbose = atoi(argv[i]);
		}
		else
		{
			printf("Meter Error: unknown argument '%s'\n",argv[i]);
			usage(argv[0]);
			return -1;
		}
	}

	return 0;
}

#ifdef __cplusplus
}
#endif
