
#ifndef METER_BROADCAST_H
#define METER_BROADCAST_H

#include <pcap.h>

#include "dspr_hash.h"

#ifdef __cplusplus
extern "C" {
#endif

#define METER_DEFAULT_MAX_MEMORY	(800) //占用最大内存：800M

#define METER_MAX_CONCURRENCY 3000

#define METER_MAX_PKT_BUFFER	40960

#define METER_PPS_USLEEP	10000  //10毫秒

#define METER_REPLACE_SEP	"="

#define METER_DEF_INTERVAL 200

#define METER_DEF_PPS  500

#define METER_DEF_START_INTERVAL 60

enum
{
	meter_mode_cs = 1,
	meter_mode_all,
	meter_mode_filter,
	meter_mode_split,
	meter_mode_stat,
	meter_mode_clean,
	meter_mode_modify
};

enum
{
	meter_client_notlogged = 0,
	meter_client_login,
	meter_client_logout
};

typedef struct 
{
	int mode;
	int is_big_file;
	char *interface_name;
	char *pcap_file_name;
	int worker_max;
	int loop_max;
	int interval;
	int pkt_per_sec;
	int pkt_per_interval;//每一个间隔的发包数
	int start_interval;
	int concurrency_max;//最大并发数
	unsigned int sequence;
	int dual;
	int short_connect;
	int syn_delay;
	int max_memory;
	char *discard_file_name;
	int ramdom_discard;//随机丢弃的万分比,如果是1，则1万个包包里随机丢弃1个包
	int verbose;

	pcap_t *pp_dev;
	pcap_t *pp_file;
	FILE *fp_file;	
	unsigned int file_size;
	int begin_offset;
	int worker_count;
	int savepkt_flag;
	int ipport_flag;
}Meter_Broadcast_Global;

typedef struct
{
	unsigned int ipaddr;
	unsigned int port;	
}Meter_Broadcast_Id;

typedef struct
{
	unsigned char ipaddr[16];
	unsigned int port;	
}Meter_Broadcast_Value;


typedef struct
{
	Meter_Broadcast_Id key;
	Meter_Broadcast_Value key_value;
    Meter_Broadcast_Id sim;
	Meter_Broadcast_Value sim_value;
}Meter_Broadcast_Rule_Value;


typedef struct 
{
	dspr_hash_t *client_rule;	
	dspr_hash_t *server_rule;
}Meter_Broadcast_Rule;

typedef struct
{
	unsigned int size;
	int begin_offset;
	u_char *data;
	unsigned int length;
	unsigned int packet_count;
}Meter_Broadcast_Cache;

typedef struct
{
	int id;
	int loop_max;
	int loop_count;
	unsigned int cursor;
	unsigned int curr_npack;
	unsigned int total_npack;
	unsigned long long int curr_nsize;
	unsigned long long int total_nsize;
	int client_state;
	u_char *pkt_buffer;
	int buffer_size;	
	dspr_hash_t *sess_hash;
	char random_discard[1000];
	int packet_count;
}Meter_Broadcast_Cache_Control;


typedef struct
{
	unsigned int sec;
	unsigned int usec;
	unsigned char syn;
	unsigned char fin;
	unsigned short caplen;
	unsigned int len;
}Meter_Packet_Hdr;


typedef struct
{
	int proto;
	unsigned int total_packet;
	unsigned int total_size;
}Meter_Proto_Stat;

#define METER_MAX_PROTO		16

typedef struct 
{
	struct timeval begin;
	struct timeval end;
	unsigned int total_session_time;//
	unsigned int total_packet;
	unsigned int total_size;
	int  duplicate_session;
	int  duplicate_packet;
	int  duplicate_size;
	Meter_Proto_Stat proto[METER_MAX_PROTO];
}Meter_Broadcast_Stat;

typedef struct
{
	unsigned int ipaddr;
	unsigned int port;
	unsigned int sequence;
}Meter_Discard_HashKey;

typedef struct
{
	unsigned int proto;     /*ip �汾*/
	unsigned int client_ip;
	unsigned int server_ip;
    unsigned char client_ip_str[16];
    unsigned char server_ip_str[16];
	unsigned short client_port;
	unsigned short server_port;
}Meter_Session_HashKey;

typedef struct Meter_Session_HashValue_s
{
	Meter_Session_HashKey key;
	char syn_flag;
	char fin_flag;
	char rst_flag;
	char duplicate_mirror;
	unsigned int request_packet;
	unsigned int request_size;
	unsigned int response_packet;
	unsigned int response_size;
	unsigned int total_packet;
	unsigned int total_size;
	pcap_dumper_t *dumpfile;

	unsigned int start_sequence;
	unsigned int start_acknowledge;

	unsigned int end_sequence;
	unsigned int end_acknowledge;

	unsigned int step_sequence;
	unsigned int step_acknowledge;	
	struct timeval start;
	struct timeval end;
	short int session_over;
	
	unsigned int ack_sequence;
	unsigned int ack_acknowledge;
	
	int packet_count;
	
	struct Meter_Session_HashValue_s *next;
	struct Meter_Session_HashValue_s *tail;
}Meter_Session_HashValue;

typedef struct
{
	unsigned int proto;
	unsigned int ipaddr;
	unsigned char ipstr[16];
	unsigned int port;
	unsigned int total_packet;
	unsigned int total_size;
	unsigned int client_number;
	const char   *serv_name;
}Meter_Server_Listen_Value;

typedef struct
{
	unsigned int port_number;
	unsigned int total_packet;
	unsigned int total_size;
	unsigned int client_number;
}Meter_Server_Ip_Value;

#ifdef __cplusplus
}
#endif

#endif
