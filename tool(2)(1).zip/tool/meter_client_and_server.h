#ifndef METER_CLIENT_AND_SERVER_H
#define METER_CLIENT_AND_SERVER_H

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <pcap.h>
#include <netinet/in.h>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <pthread.h>
#include <unistd.h>
#include <sys/types.h>
#include <errno.h>
#include <signal.h>
#include "dspr_hash.h"
#include "protocol_analysis.h"
#include "librslist.h"

/* 程序版本号*/
#define VERSION "1.0.1"
/* 程序创建时间 */
#define BUILD_DATE "2015-07-21 16:34:50"
/* 程序的svn号 */
#define BUILD_SVN "14737"

/* 默认最大worker数 (每个worker的逻辑都一样，都是用于按照会话数创建线程的)*/
#define DEFAULT_WORKER_MAX 1
/* 默认循环发pcap文件包次数 */
#define DEFAULT_LOOP_MAX 1
/* 默认间隔发包数(每发完这一值指定的包数后程序会sleep一段时间)*/
#define DEFAULT_PKT_PER_INTERVAL 5
/* 占用最大内存：800M */
#define METER_MAX_MEMORY	(800*1048576)  
/* 最大监听数 */
#define MAX_LISTEN_NUM 40
/* socket每次最大接收数据的长度 */
#define MC_MAX_PACKAGESIZE  (32*1024)+64
/* 每个发包间隔sleep时间 ，单位1/1000毫秒*/
#define PER_INTERVAL_SLEEP 10*1000
/* 每个线程启动后sleep时间 单位1/1000毫秒*/
#define PER_THREAD_SLEEP 100*1000
/* select超时时间单位:微秒(1/1000毫秒) */
#define SELECT_TIME_OUT 1000*1000

/*表示线程处理类型为非大文件类型*/
#define THREAD_HANDLER_CACHE 1
/* 表示线程处理类型为大文件类型 */
#define THREAD_HANDLER_BIG_FILE 2

/* 全局结构体 */
typedef struct 
{
	int big_file;                    /* 说明pcap文件是否为大文件(大于800M即为大文件) */
	int worker_max;            /* 最大worker数，worker是用来根据会话数创建相应数量线程的 */
	int loop_max;                /* 循环发pcap文件包次数 */
	int pkt_per_interval;      /* 每一个间隔的发包数*/
	char *pcap_file_name;   /* pcap文件名 */
	unsigned int file_size;     /* pcap文件大小 */
	int begin_offset;            /* pcap文件开始偏移量 */
	u_int total_package_count;   /* 总包数 */
	pcap_t *pp_file;             /* pcap文件指针，libcap函数专用*/
	FILE *fp_file;	              /* pcap文件指针，标准io指针*/
	in_addr_t server_ip;             /* 服务端ip */
	u_short server_port;     /* 服务端端口 */
}Meter_Global;

/* 缓存结构体 ，用于存放pcap文件中的包*/
typedef struct
{
	unsigned int size;                     /* cache大小*/
	int begin_offset;                      /* pcap文件开始偏移量*/
	u_char *data;                           /* 数据指针*/
	unsigned int length;                 /* 数据长度*/
	unsigned int packet_count;     /* 包数*/
}Meter_Cache;

/* 会话哈希表的哈希key结构体 */
typedef struct
{
	unsigned int client_ip;             /* 客户端ip */
	unsigned int server_ip;           /* 服务端ip */
	unsigned short client_port;    /* 客户端端口 */
	unsigned short server_port;  /* 服务端端口 */
}Meter_Sess_HashKey;

/* 会话哈希表哈希值结构体 */
typedef struct
{
	Meter_Sess_HashKey key;  /* 哈希key */
	unsigned int total_packet;     /* 总包数 */
	unsigned int total_size;          /* 所有包的大小 */
}Meter_Sess_HashValue;

/* 缓存访问控制结构体 */
typedef struct
{
	unsigned int cursor;              /* 遍历缓存的游标 */
	unsigned int curr_npack;      /* 当前包数 */
	unsigned int curr_nsize;       /* 当前所有包大小 */
}Meter_Cache_Control;

#endif

