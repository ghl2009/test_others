#include "meter_client_and_server.h"

/* 统计当前线程数 */
static int pthread_count = 0;
/* meter全局变量 */
static Meter_Global _Global;
/* 会话哈希表头指针 */
static dspr_hash_t *_Sess_Hash = NULL;
/* 会话顺序链表头指针 */
static Rslist_t *_Sess_Rslist = NULL;
/* 会话数量 */
static int _Sess_Num = 0;
/* 会话索引值 */
static int _Sess_Index = 0;
/* 统计当前总包数 */
static int _Global_Count_Pkt = 0;

/*文件缓存*/
static Meter_Cache _Cache;
/* 线程互斥量 */
pthread_mutex_t _Mutex;
/* 线程条件互斥量 */
pthread_mutex_t _Mutex_Cond;
/* 线程条件变量 */
pthread_cond_t   _Pthread_Cond;


/* 打印提示信息 */
static void usage(char *progname);
/* 解析命令行参数 */
static int argument_parse(int argc, char *argv[]);
/* 注册新会话 */
static Meter_Sess_HashValue *session_register(dspr_hash_t *sess_hash, const struct pcap_pkthdr *header, Meter_Packet_Info *pkt_info);
/* 初始化会话哈希表，将pcap文件中的各会话加入到会话哈希表中 */
static int session_hash_init();
/* 将pcap文件中的包保存到cache中*/
static int cache_init(Meter_Global *global, Meter_Cache *cache);
/* 遍历内存中的包数据 */
static int cache_get_next(Meter_Cache *pcache, Meter_Cache_Control *pctrl, struct pcap_pkthdr **header, const u_char **pkg_data);
/* 启动线程 */
static void create_session_thread(dspr_hash_node_t *node,void *param);
/* 构造第一个发送给服务端的会话包 */
static int create_session_pkt(Meter_Sess_HashKey *sess_hash_key, Meter_Packet_Info &pkt_info);
/* 线程体函数，当pcap文件小于800M时使用此函数 */
static void* thread_handler_cache(void *arg);
/* 线程体函数，当pcap文件大于800M时使用此函数 */
static void* thread_handler_big_file(void *arg);

int main(int argc, char* argv[])
{
	int i, j;
	char errbuf[PCAP_ERRBUF_SIZE];
	Rslist_Config rslist_config;
	uint8_t *rslist_start_addr = NULL;
	
	memset(&_Global, 0, sizeof(Meter_Global));

	/* 忽略SIGPIPE信号，防止异常情况下进程退出 */
	signal(SIGPIPE, SIG_IGN);

	/* 给全局结构变量赋默认值 */
	_Global.worker_max = DEFAULT_WORKER_MAX;
	_Global.loop_max = DEFAULT_LOOP_MAX;
	_Global.pkt_per_interval = DEFAULT_PKT_PER_INTERVAL;

	/* 初始化会话哈希表*/
	_Sess_Hash = dspr_hash_new();
	dspr_hash_init(_Sess_Hash,(char*)"SessionHash",10000,NULL,NULL,NULL);

	/* 初始化会话顺序表 */
	memset(&rslist_config,0,sizeof(Rslist_Config));
	rslist_config.total_kbsize = 4096;
	rslist_config.max_slot = 1;
	rslist_config.user_data_size = sizeof(Meter_Sess_HashKey);
	rslist_start_addr = (uint8_t*)malloc(rslist_config.total_kbsize*1024);

	memset(errbuf,0,sizeof(errbuf));
	_Sess_Rslist = Rslist_Init(rslist_start_addr,&rslist_config,errbuf);
	if(_Sess_Rslist == NULL)
	{
		printf("Meter Error: Rslist_Init error:%s\n",errbuf);
		return 0;
	}

	pthread_mutex_init(&_Mutex, NULL);
	pthread_mutex_init(&_Mutex_Cond, NULL);
	pthread_cond_init(&_Pthread_Cond, NULL);

	/* 解析命令行参数 */
	argument_parse(argc, argv);

	/* 打开pcap文件 */
	if ((_Global.pp_file = pcap_open_offline(_Global.pcap_file_name,errbuf)) == NULL)
	{
		printf("\nMeter Error: Unable to open the pcap file:%s %s\n",_Global.pcap_file_name,errbuf);
		return 0;
	}

	/* 获取pcap文件大小*/
	_Global.fp_file = pcap_file(_Global.pp_file);
	_Global.begin_offset = ftell(_Global.fp_file);
	fseek(_Global.fp_file,0,SEEK_END);
	_Global.file_size = ftell(_Global.fp_file);
	fseek(_Global.fp_file,_Global.begin_offset,SEEK_SET);
	if(_Global.file_size > METER_MAX_MEMORY)
	{
		_Global.big_file = 1;
	}
	printf ("Meter Info: File Size %u  Big File? %s\n",_Global.file_size,_Global.big_file?"Yes":"No");

	/* 初始化会话哈希表，将pcap文件中的各会话加入到会话哈希表中 */
	session_hash_init();
	printf("Meter Session: Total=%d\n",dspr_hash_count(_Sess_Hash));

	/* 如果不是大文件，则启用Cache机制，把文件中的包读取到Cache，这样以后再操作速度就快了*/
	if (0 == _Global.big_file)
	{
		cache_init(&_Global, &_Cache);
		
		for (i = 0; i < _Global.worker_max; i++)
		{
			for (j = 1; j <= _Sess_Num; j++)
			{
				Meter_Sess_HashKey *p_sess_hash_key = NULL;
				pthread_attr_t	attr;
				pthread_t t_id;
			
				p_sess_hash_key = (Meter_Sess_HashKey*)Rslist_Find(_Sess_Rslist, j);
				if (!p_sess_hash_key)
				{
					printf("rslist find failed\n");
					pthread_exit((void*)0);
				}

				_Sess_Index = j;

				pthread_attr_init(&attr);
				pthread_attr_setdetachstate(&attr, PTHREAD_CREATE_DETACHED);
				
				if (pthread_create(&t_id, &attr, thread_handler_cache, p_sess_hash_key) != 0) 
				{
					printf("create thread failed!\n");
				}

				pthread_mutex_lock(&_Mutex_Cond);
				pthread_cond_wait(&_Pthread_Cond, &_Mutex_Cond);
				pthread_mutex_unlock(&_Mutex_Cond);
			}
		}
	}
	else
	{
#if 0	
		dspr_hash_enum(_Sess_Hash, create_session_thread, (void*)THREAD_HANDLER_BIG_FILE);
#endif
		for (j = 1; j <= _Sess_Num; j++)
		{
			Meter_Sess_HashKey *p_sess_hash_key = NULL;
			pthread_attr_t	attr;
			pthread_t t_id;
		
			p_sess_hash_key = (Meter_Sess_HashKey*)Rslist_Find(_Sess_Rslist, j);
			if (!p_sess_hash_key)
			{
				printf("rslist find failed\n");
				pthread_exit((void*)0);
			}
		
			_Sess_Index = j;
		
			pthread_attr_init(&attr);
			pthread_attr_setdetachstate(&attr, PTHREAD_CREATE_DETACHED);
			
			if (pthread_create(&t_id, &attr, thread_handler_big_file, p_sess_hash_key) != 0) 
			{
				printf("create thread failed!\n");
			}
		
			pthread_mutex_lock(&_Mutex_Cond);
			pthread_cond_wait(&_Pthread_Cond, &_Mutex_Cond);
			pthread_mutex_unlock(&_Mutex_Cond);
		}
	}

	while (1)
	{
		sleep(1);
		if (!pthread_count)
		{
			break;
		}
	}
	
	return 0;
}

/* 打印提示信息 */
static void usage(char *progname)
{
	printf("\nVersion:%s  %s  Build %s %s\n",
		VERSION,pcap_lib_version(),BUILD_DATE,BUILD_SVN);
	
	printf("\nUasge: %s [option] [interface] pcap_file\n",progname);
	printf("Option:\n");
	printf("\t--server_ip         specify server listen ip\n");
	printf("\t--server_port         specify server listen port\n");
	printf("\t--worker count          worker count (default:%d)\n", DEFAULT_WORKER_MAX);
	printf("\t--loop count            loop count (default:%d)\n", DEFAULT_LOOP_MAX);
	//printf("\t--pps          interval  package number(default:%d)\n", DEFAULT_PKT_PER_INTERVAL);
	
	printf("\nFor Example:\n");
	printf("./meter_new_client --server_ip 192.168.9.121 --server_port 7788 --worker 3 --loop 5 loadrunner.pcap\n");
	printf("./meter_new_client --server_ip 192.168.9.121 --server_port 7788 loadrunner.pcap\n");
	printf("\nNote:\n");
	printf("with 'Message too long' error,run command on send machine and recv machine\n");
	printf("[root@localhost]#/sbin/ifconfig eth3 mtu 8192\n\n");
}

/* 解析命令行参数 */
static int argument_parse(int argc,char *argv[])
{
	int arg_num = argc - 1, i;

	if(argc < 3)
	{
		usage(argv[0]);
		exit(0);
	}
	
	_Global.pcap_file_name = argv[argc - 1];
	
	for(i = 1; i < arg_num; i++)
	{
		if(0 == strcmp(argv[i],"--server_ip"))
		{
			i++;
			_Global.server_ip = inet_addr(argv[i]);
		}

		if(0 == strcmp(argv[i],"--server_port"))
		{
			i++;
			_Global.server_port = htons(atoi(argv[i]));
		}
		
		if(0 == strcmp(argv[i],"--worker"))
		{
			i++;
			_Global.worker_max = atoi(argv[i]);
		}

		if(0 == strcmp(argv[i],"--loop"))
		{
			i++;
			_Global.loop_max= atoi(argv[i]);
		}

		if(0 == strcmp(argv[i],"--pps"))
		{
			i++;
			_Global.pkt_per_interval = atoi(argv[i]);
		}
	}

	return 0;
}

/* 注册新会话 */
static Meter_Sess_HashValue *session_register(dspr_hash_t *sess_hash,const struct pcap_pkthdr *header,Meter_Packet_Info *pkt_info)
{
	Meter_Sess_HashKey mhkey;
	Meter_Sess_HashValue *mhvalue1 = NULL;
	Meter_Sess_HashValue *mhvalue2 = NULL;

	mhkey.client_ip = pkt_info->ipv4_header.ip_destaddr;
	mhkey.client_port = pkt_info->tcp_header.dest_port;
	mhkey.server_ip = pkt_info->ipv4_header.ip_srcaddr;
	mhkey.server_port = pkt_info->tcp_header.source_port;
	mhvalue1 = (Meter_Sess_HashValue*)dspr_hash_find(sess_hash,&mhkey,sizeof(Meter_Sess_HashKey));
	
	mhkey.client_ip = pkt_info->ipv4_header.ip_srcaddr;
	mhkey.client_port = pkt_info->tcp_header.source_port;
	mhkey.server_ip = pkt_info->ipv4_header.ip_destaddr;
	mhkey.server_port = pkt_info->tcp_header.dest_port;	
	mhvalue2 = (Meter_Sess_HashValue*)dspr_hash_find(sess_hash,&mhkey,sizeof(Meter_Sess_HashKey));

	if(!mhvalue1 && !mhvalue2)
	{
		mhvalue2 = (Meter_Sess_HashValue*)malloc(sizeof(Meter_Sess_HashValue));
		if(mhvalue2)
		{
			memset(mhvalue2,0,sizeof(Meter_Sess_HashValue));
			memcpy(&(mhvalue2->key),&mhkey,sizeof(Meter_Sess_HashKey));

			mhvalue2->total_packet++;
			mhvalue2->total_size += header->len;

			dspr_hash_insert(sess_hash,&(mhvalue2->key),sizeof(Meter_Sess_HashKey),mhvalue2,0,0);

			_Sess_Num++;
			Rslist_Insert(_Sess_Rslist, _Sess_Num, &(mhvalue2->key));
		}

		return NULL;
	}

	if (mhvalue1)
	{
		mhvalue1->total_packet++;
		mhvalue1->total_size += header->len;
		return mhvalue1;
	}

	if (mhvalue2)
	{
		mhvalue2->total_packet++;
		mhvalue2->total_size += header->len;
		return mhvalue2;
	}
}

/* 初始化会话哈希表，将pcap文件中的各会话加入到会话哈希表中 */
static int session_hash_init()
{
	int res = 0;
	struct pcap_pkthdr *header = NULL;
	const u_char *pkt_data = NULL;
	Dbfw_EthernetFrame eth_frame;
	Meter_Packet_Info pkt_info;
	
	fseek(_Global.fp_file,_Global.begin_offset,SEEK_SET);
	while(pcap_next_ex(_Global.pp_file, &header, &pkt_data) >= 0)
	{
		/*解析网络包*/
		memset(&eth_frame,0,sizeof(eth_frame));
		memset(&pkt_info,0,sizeof(pkt_info));		
		eth_frame.frame_data = (u_char*)pkt_data;
		eth_frame.frame_size = header->len;
		res = Dbfw_Protocol_Parse(&eth_frame,&pkt_info,NULL);
		if(res != meter_proto_cs)
		{
			continue;
		}

		/*放入哈希表*/
		session_register(_Sess_Hash,header,&pkt_info);
	}
	return 0;
}

/* 将pcap文件中的包保存到cache中*/
static int cache_init(Meter_Global *global, Meter_Cache *cache)
{
	int res = 0, count = 0;
	struct pcap_pkthdr *header = NULL;
	const u_char *pkt_data = NULL;
	Dbfw_EthernetFrame eth_frame;
	Meter_Packet_Info pkt_info;
	
	cache->size = 0;
	cache->begin_offset = global->begin_offset;
	cache->data = (u_char*)realloc(cache->data, global->begin_offset);
	if(NULL == cache->data)
	{
		return -1;
	}
	cache->size += global->begin_offset;
	fseek(global->fp_file,0,SEEK_SET);
	fread(cache->data,1,global->begin_offset,global->fp_file);

	cache->length = global->begin_offset;
	fseek(global->fp_file,cache->begin_offset,SEEK_SET);
	while(pcap_next_ex(global->pp_file, &header, &pkt_data) >= 0)
	{
		/*解析网络包*/
		memset(&eth_frame,0,sizeof(eth_frame));
		memset(&pkt_info,0,sizeof(pkt_info));		
		eth_frame.frame_data = (u_char*)pkt_data;
		eth_frame.frame_size = header->len;
		res = Dbfw_Protocol_Parse(&eth_frame,&pkt_info,NULL);
		if(res != meter_proto_cs)
		{
			continue;
		}

		if (pkt_info.data_size == 0)
		{
			count++;
		}
		
		cache->data = (u_char*)realloc(cache->data, cache->size+sizeof(struct pcap_pkthdr)+header->caplen);
		if(NULL == cache->data)
		{
			return -1;
		}
		cache->size += sizeof(struct pcap_pkthdr)+header->caplen;

		/*放入Cache*/
		memcpy(cache->data+cache->length,header,sizeof(struct pcap_pkthdr));
		cache->length += sizeof(struct pcap_pkthdr);
		memcpy(cache->data+cache->length,pkt_data,header->caplen);
		cache->length += header->caplen;
		
		cache->packet_count++;
	}

	printf("Meter Packet: Total=%d(=0:%d, >0:%d)  Size=%d\n",cache->packet_count, count, cache->packet_count-count, cache->length);
	
	return 0;
}

/* 遍历内存中的包数据 */
static int cache_get_next(Meter_Cache *pcache, Meter_Cache_Control *pctrl, struct pcap_pkthdr **header, const u_char **pkg_data)
{
	if(pctrl->cursor >= pcache->length)
	{
		return -1;
	}
	*header = (struct pcap_pkthdr*)(pcache->data + pctrl->cursor);
	pctrl->cursor += sizeof(struct pcap_pkthdr);
	*pkg_data = pcache->data + pctrl->cursor;
	pctrl->cursor += (*header)->caplen;
	return 0;
}


/* 启动线程 */
static void create_session_thread(dspr_hash_node_t *node,void *param)
{
	pthread_attr_t	attr;
	pthread_t t_id;

	Meter_Sess_HashValue *mhvalue = (Meter_Sess_HashValue*)dspr_hash_node_get_value(node);

	pthread_attr_init(&attr);
	pthread_attr_setdetachstate(&attr, PTHREAD_CREATE_DETACHED);

	if (param == (void*)THREAD_HANDLER_CACHE)
	{
		if (pthread_create(&t_id, &attr, thread_handler_cache, &(mhvalue->key)) != 0) 
		{
			printf("create thread failed!\n");
		}
		/* 每创建一个线程sleep一会，防止同一时间连接数过多导致连接失败 */
		usleep(PER_THREAD_SLEEP);
	}
	else
	{
		if (pthread_create(&t_id, &attr, thread_handler_big_file, &(mhvalue->key)) != 0) 
		{
			printf("create thread failed!\n");
		}
		usleep(PER_THREAD_SLEEP);
	}
}

/* 构造第一个发送给服务端的会话包 */
static int create_session_pkt(Meter_Sess_HashKey *sess_hash_key, Meter_Packet_Info *pkt_info)
{
	int res, cursor = 0, sess_pkt_len = 0;
	struct pcap_pkthdr *header = NULL;
	const u_char *pkt_data = NULL;
	char pkt_buffer[MC_MAX_PACKAGESIZE];
	Dbfw_EthernetFrame eth_frame;
	Meter_Cache_Control pcontrol;

	pcontrol.cursor = _Cache.begin_offset;
	pcontrol.curr_npack = 0;

	if (!sess_hash_key || !pkt_info)
	{
		return sess_pkt_len;
	}

	while(0 == cache_get_next(&_Cache,&pcontrol,&header,&pkt_data))
	{
		memset(pkt_buffer,0,MC_MAX_PACKAGESIZE);
		memcpy(pkt_buffer,pkt_data,header->caplen);
		eth_frame.frame_data = (u_char*)pkt_buffer;
		eth_frame.frame_size = header->len;
		res = Dbfw_Protocol_Parse(&eth_frame,pkt_info,NULL);
		if(res != meter_proto_cs)
		{
			continue;
		}

		/* 将数据长度为0的包过滤掉 */
		if (pkt_info->data_size == 0)
		{
			continue;
		}
		if (pkt_info->direction == mb_pkt_dct_request)
		{
			cursor = pkt_info->data_size;
			pkt_info->data_size = pkt_info->data_size+sizeof(Meter_Sess_HashKey);
			sess_pkt_len = pkt_info->data_size;
			pkt_info->tcp_data = (u_char*)realloc(pkt_info->tcp_data, pkt_info->data_size);
			memcpy(pkt_info->tcp_data+cursor, sess_hash_key, sizeof(Meter_Sess_HashKey));
			break;
		}		
	}	

	return sess_pkt_len;
}

/* 线程体函数，当pcap文件小于800M时使用此函数 */
static void* thread_handler_cache(void *arg)
{
	int i, s_fd, res, select_ret = 0, send_ret = 0;
	fd_set rset;
	struct timeval select_tv;
	struct  sockaddr_in bind_addr;
	struct  sockaddr_in s_addr;
	const struct linger lingerie = {1, 1}; 
	const int on = 1;    
	struct pcap_pkthdr *header = NULL;
	const u_char *pkt_data = NULL;
	char buff[MC_MAX_PACKAGESIZE];
	char pkt_buffer[MC_MAX_PACKAGESIZE];
	unsigned int recv_len = 0;
	pthread_t cur_t_id;
	Dbfw_EthernetFrame eth_frame;
	Meter_Packet_Info sess_pkt_info;
	Meter_Packet_Info local_pkt_info;
	Meter_Cache_Control pcontrol;
	Meter_Sess_HashKey sess_hash_key = *(Meter_Sess_HashKey*)arg;


	FD_ZERO(&rset);
	FD_SET(s_fd, &rset);

	select_tv.tv_sec = 0;
	select_tv.tv_usec = SELECT_TIME_OUT;

	pthread_mutex_lock(&_Mutex);
	pthread_count++;
	pthread_mutex_unlock(&_Mutex);

	cur_t_id = pthread_self();

	memset(&pcontrol, 0, sizeof(Meter_Broadcast_Cache_Control));

	bind_addr.sin_family = AF_INET;
	bind_addr.sin_addr.s_addr= INADDR_ANY;
	bind_addr.sin_port = htons(0);
		
	s_addr.sin_family = AF_INET;
	s_addr.sin_addr.s_addr= _Global.server_ip;
	s_addr.sin_port = _Global.server_port;

	s_fd = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP);
	if (s_fd < 0)
	{
		printf("create socket failed!\n");
		pthread_mutex_lock(&_Mutex);
		pthread_count--;
		pthread_mutex_unlock(&_Mutex);
		pthread_exit((void*)0);
	}
	
	if (setsockopt(s_fd, SOL_SOCKET, SO_LINGER, (char *)&lingerie, sizeof(lingerie)) < 0)
	{
		printf("setsockopt  SO_LINGER failed!\n");
		pthread_mutex_lock(&_Mutex);
		pthread_count--;
		pthread_mutex_unlock(&_Mutex);
		pthread_exit((void*)0);
	}

	if (setsockopt(s_fd, SOL_SOCKET, SO_REUSEADDR, (char *)&on, sizeof(on)) < 0)
	{
		printf("setsockopt SO_REUSEADDR failed!\n");
		pthread_mutex_lock(&_Mutex);
		pthread_count--;
		pthread_mutex_unlock(&_Mutex);
		pthread_exit((void*)0);
	}

	if (bind(s_fd, (struct sockaddr *)&bind_addr, sizeof(struct sockaddr_in)) < 0)
	{
		printf("bind failed!\n");
		pthread_mutex_lock(&_Mutex);
		pthread_count--;
		pthread_mutex_unlock(&_Mutex);
		pthread_exit((void*)0);
	}

	while (1)
	{
		int ret;
		if ((ret = connect(s_fd, (struct sockaddr*)&s_addr, sizeof(s_addr))) < 0)
		{
			printf("connect failed!\n");
			printf("error:%s\n", strerror(errno));
		}

		if (ret == 0)
		{
			break;
		}
	}

	/* 每创建一个线程sleep一会，防止同一时间连接数过多导致连接失败 */
	usleep(PER_THREAD_SLEEP);

	pthread_cond_broadcast(&_Pthread_Cond);

	for (i = 0; i < _Global.loop_max; i++)
	{
		pcontrol.cursor = _Cache.begin_offset;
		pcontrol.curr_npack = 0;
		
		while(0 == cache_get_next(&_Cache,&pcontrol,&header,&pkt_data))
		{
			memset(buff, 0, MC_MAX_PACKAGESIZE);
			memset(pkt_buffer,0,MC_MAX_PACKAGESIZE);
			memcpy(pkt_buffer,pkt_data,header->caplen);
			eth_frame.frame_data = (u_char*)pkt_buffer;
			eth_frame.frame_size = header->len;
			res = Dbfw_Protocol_Parse(&eth_frame,&local_pkt_info,NULL);
			if(res != meter_proto_cs)
			{
				continue;
			}
		
			/* 将数据长度为0的包过滤掉 */
			if (local_pkt_info.data_size == 0)
			{
				continue;
			}
			
			/* 判断当前包是否属于本会话 */
			if ((sess_hash_key.client_ip == local_pkt_info.ipv4_header.ip_srcaddr &&
				sess_hash_key.client_port == local_pkt_info.tcp_header.source_port &&
				sess_hash_key.server_ip == local_pkt_info.ipv4_header.ip_destaddr &&
				sess_hash_key.server_port == local_pkt_info.tcp_header.dest_port) ||
				(sess_hash_key.client_ip == local_pkt_info.ipv4_header.ip_destaddr &&
				sess_hash_key.client_port == local_pkt_info.tcp_header.dest_port &&
				sess_hash_key.server_ip == local_pkt_info.ipv4_header.ip_srcaddr &&
				sess_hash_key.server_port == local_pkt_info.tcp_header.source_port))
			{
				pthread_mutex_lock(&_Mutex);
				_Global_Count_Pkt++;
				pthread_mutex_unlock(&_Mutex);
				printf("count_pkt=%d\n", _Global_Count_Pkt);
				
				if (local_pkt_info.direction == mb_pkt_dct_request)
				{
					send_ret = send(s_fd, local_pkt_info.tcp_data, local_pkt_info.data_size, 0);
					if (send_ret < 0)
					{
						if (errno == EAGAIN || errno == EWOULDBLOCK)
						{
							send(s_fd, local_pkt_info.tcp_data, local_pkt_info.data_size, 0);
						}
						else
						{
							/* 可能是服务端断开了连接 */
							printf("close connection\n");
							pthread_exit((void*)0);
						}
					}

					pcontrol.curr_npack++;
					
					pthread_mutex_lock(&_Mutex);
					_Global.total_package_count++;
					pthread_mutex_unlock(&_Mutex);
					
					printf("cur_worker:%ld  total_worker:%d  current package num:%d  ip_total_len:%d  send_len:%d\n", cur_t_id, 
						                                                                                                                          _Global.worker_max, 
						                                                                                                                          _Global.total_package_count, 
						                                                                                                                          local_pkt_info.ipv4_header.ip_total_length, 
						                                                                                                                          local_pkt_info.data_size);
				}
				else
				{
					FD_ZERO(&rset);
					FD_SET(s_fd, &rset);
					
					select_tv.tv_sec = 0;
					select_tv.tv_usec = SELECT_TIME_OUT;
					select_ret = select(s_fd + 1, &rset, NULL, NULL, &select_tv);
					if (select_ret < 0)
					{
						/* 可能是服务端断开了连接 */
						printf("close connection\n");
						pthread_exit((void*)0);
					}
					else if (select_ret > 0)
					{
						if (FD_ISSET(s_fd, &rset))
						{
							recv_len = recv(s_fd, buff, local_pkt_info.data_size, 0);
							if (recv_len <= 0)
							{
							   /* 可能是服务端断开了连接 */
							   printf("close connection\n");
							   pthread_mutex_lock(&_Mutex);
							   pthread_count--;
							   pthread_mutex_unlock(&_Mutex);
							   pthread_exit((void*)0);
							}
							
							pcontrol.curr_npack++;
							
							pthread_mutex_lock(&_Mutex);
							_Global.total_package_count++;
							pthread_mutex_unlock(&_Mutex);
							
							printf("cur_worker:%ld	total_worker:%d  current package num:%d   ip_total_len:%d  recv_len:%d\n", cur_t_id, 
																								  _Global.worker_max, 
																								  _Global.total_package_count, 
																								  local_pkt_info.ipv4_header.ip_total_length,
																								  recv_len);
						}
					}
					else /* 接收等待超时*/
					{
						printf("time out!!!\n");
						printf("cur_worker:%ld	total_worker:%d  current package num:%d   ip_total_len:%d\n", cur_t_id, 
																							  _Global.worker_max, 
																							  _Global.total_package_count, 
																							  local_pkt_info.ipv4_header.ip_total_length);
					}
				}
			}

			usleep(PER_INTERVAL_SLEEP);
		}
	}

	close(s_fd);
	pthread_mutex_lock(&_Mutex);
	pthread_count--;
	pthread_mutex_unlock(&_Mutex);
}

/* 线程体函数，当pcap文件大于800M时使用此函数 */
static void* thread_handler_big_file(void *arg)
{
	int i, s_fd, res, select_ret = 0, send_ret = 0;
	fd_set rset;
	struct timeval select_tv;
	struct	sockaddr_in bind_addr;
	struct	sockaddr_in s_addr;
	const struct linger lingerie = {1, 1}; 
	const int on = 1;	 
	struct pcap_pkthdr *header = NULL;
	const u_char *pkt_data = NULL;
	char buff[MC_MAX_PACKAGESIZE];
	char pkt_buffer[MC_MAX_PACKAGESIZE];
	unsigned int recv_len = 0;
	pthread_t cur_t_id;
	Dbfw_EthernetFrame eth_frame;
	Meter_Packet_Info sess_pkt_info;
	Meter_Packet_Info local_pkt_info;
	Meter_Cache_Control pcontrol;
	Meter_Sess_HashKey sess_hash_key = *(Meter_Sess_HashKey*)arg;


	FD_ZERO(&rset);
	FD_SET(s_fd, &rset);

	select_tv.tv_sec = 0;
	select_tv.tv_usec = SELECT_TIME_OUT;

	pthread_mutex_lock(&_Mutex);
	pthread_count++;
	pthread_mutex_unlock(&_Mutex);

	cur_t_id = pthread_self();

	memset(&pcontrol, 0, sizeof(Meter_Broadcast_Cache_Control));

	bind_addr.sin_family = AF_INET;
	bind_addr.sin_addr.s_addr= INADDR_ANY;
	bind_addr.sin_port = htons(0);
		
	s_addr.sin_family = AF_INET;
	s_addr.sin_addr.s_addr= _Global.server_ip;
	s_addr.sin_port = _Global.server_port;

	s_fd = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP);
	if (s_fd < 0)
	{
		printf("create socket failed!\n");
		pthread_mutex_lock(&_Mutex);
		pthread_count--;
		pthread_mutex_unlock(&_Mutex);
		pthread_exit((void*)0);
	}
	
	if (setsockopt(s_fd, SOL_SOCKET, SO_LINGER, (char *)&lingerie, sizeof(lingerie)) < 0)
	{
		printf("setsockopt	SO_LINGER failed!\n");
		pthread_mutex_lock(&_Mutex);
		pthread_count--;
		pthread_mutex_unlock(&_Mutex);
		pthread_exit((void*)0);
	}

	if (setsockopt(s_fd, SOL_SOCKET, SO_REUSEADDR, (char *)&on, sizeof(on)) < 0)
	{
		printf("setsockopt SO_REUSEADDR failed!\n");
		pthread_mutex_lock(&_Mutex);
		pthread_count--;
		pthread_mutex_unlock(&_Mutex);
		pthread_exit((void*)0);
	}

	if (bind(s_fd, (struct sockaddr *)&bind_addr, sizeof(struct sockaddr_in)) < 0)
	{
		printf("bind failed!\n");
		pthread_mutex_lock(&_Mutex);
		pthread_count--;
		pthread_mutex_unlock(&_Mutex);
		pthread_exit((void*)0);
	}

	while (1)
	{
		int ret;
		if ((ret = connect(s_fd, (struct sockaddr*)&s_addr, sizeof(s_addr))) < 0)
		{
			printf("connect failed!\n");
			printf("error:%s\n", strerror(errno));
		}

		if (ret == 0)
		{
			break;
		}
	}

	/* 每创建一个线程sleep一会，防止同一时间连接数过多导致连接失败 */
	usleep(PER_THREAD_SLEEP);

	pthread_cond_broadcast(&_Pthread_Cond);

	for (i = 0; i < _Global.loop_max; i++)
	{
		pcontrol.cursor = _Cache.begin_offset;
		pcontrol.curr_npack = 0;
		
		fseek(_Global.fp_file,_Global.begin_offset,SEEK_SET);
		while(pcap_next_ex(_Global.pp_file, &header, &pkt_data) >= 0)
		{
			memset(buff, 0, MC_MAX_PACKAGESIZE);
			memset(pkt_buffer,0,MC_MAX_PACKAGESIZE);
			memcpy(pkt_buffer,pkt_data,header->caplen);
			eth_frame.frame_data = (u_char*)pkt_buffer;
			eth_frame.frame_size = header->len;
			res = Dbfw_Protocol_Parse(&eth_frame,&local_pkt_info,NULL);
			if(res != meter_proto_cs)
			{
				continue;
			}
		
			/* 将数据长度为0的包过滤掉 */
			if (local_pkt_info.data_size == 0)
			{
				continue;
			}
			
			/* 判断当前包是否属于本会话 */
			if ((sess_hash_key.client_ip == local_pkt_info.ipv4_header.ip_srcaddr &&
				sess_hash_key.client_port == local_pkt_info.tcp_header.source_port &&
				sess_hash_key.server_ip == local_pkt_info.ipv4_header.ip_destaddr &&
				sess_hash_key.server_port == local_pkt_info.tcp_header.dest_port) ||
				(sess_hash_key.client_ip == local_pkt_info.ipv4_header.ip_destaddr &&
				sess_hash_key.client_port == local_pkt_info.tcp_header.dest_port &&
				sess_hash_key.server_ip == local_pkt_info.ipv4_header.ip_srcaddr &&
				sess_hash_key.server_port == local_pkt_info.tcp_header.source_port))
			{
				pthread_mutex_lock(&_Mutex);
				_Global_Count_Pkt++;
				pthread_mutex_unlock(&_Mutex);
				printf("count_pkt=%d\n", _Global_Count_Pkt);
				
				if (local_pkt_info.direction == mb_pkt_dct_request)
				{
					send_ret = send(s_fd, local_pkt_info.tcp_data, local_pkt_info.data_size, 0);
					if (send_ret < 0)
					{
						if (errno == EAGAIN || errno == EWOULDBLOCK)
						{
							send(s_fd, local_pkt_info.tcp_data, local_pkt_info.data_size, 0);
						}
						else
						{
							/* 可能是服务端断开了连接 */
							printf("close connection\n");
							pthread_exit((void*)0);
						}
					}

					pcontrol.curr_npack++;
					
					pthread_mutex_lock(&_Mutex);
					_Global.total_package_count++;
					pthread_mutex_unlock(&_Mutex);
					
					printf("cur_worker:%ld	total_worker:%d  current package num:%d  ip_total_len:%d  send_len:%d\n", cur_t_id, 
																																				  _Global.worker_max, 
																																				  _Global.total_package_count, 
																																				  local_pkt_info.ipv4_header.ip_total_length, 
																																				  local_pkt_info.data_size);
				}
				else
				{
					FD_ZERO(&rset);
					FD_SET(s_fd, &rset);
					
					select_tv.tv_sec = 0;
					select_tv.tv_usec = SELECT_TIME_OUT;
					select_ret = select(s_fd + 1, &rset, NULL, NULL, &select_tv);
					if (select_ret < 0)
					{
						/* 可能是服务端断开了连接 */
						printf("close connection\n");
						pthread_exit((void*)0);
					}
					else if (select_ret > 0)
					{
						if (FD_ISSET(s_fd, &rset))
						{
							recv_len = recv(s_fd, buff, local_pkt_info.data_size, 0);
							if (recv_len <= 0)
							{
							   /* 可能是服务端断开了连接 */
							   printf("close connection\n");
							   pthread_mutex_lock(&_Mutex);
							   pthread_count--;
							   pthread_mutex_unlock(&_Mutex);
							   pthread_exit((void*)0);
							}
							
							pcontrol.curr_npack++;
							
							pthread_mutex_lock(&_Mutex);
							_Global.total_package_count++;
							pthread_mutex_unlock(&_Mutex);
							
							printf("cur_worker:%ld	total_worker:%d  current package num:%d   ip_total_len:%d  recv_len:%d\n", cur_t_id, 
																								  _Global.worker_max, 
																								  _Global.total_package_count, 
																								  local_pkt_info.ipv4_header.ip_total_length,
																								  recv_len);
						}
					}
					else /* 接收等待超时*/
					{
						printf("time out!!!\n");
						printf("cur_worker:%ld	total_worker:%d  current package num:%d   ip_total_len:%d\n", cur_t_id, 
																							  _Global.worker_max, 
																							  _Global.total_package_count, 
																							  local_pkt_info.ipv4_header.ip_total_length);
					}
				}
			}

			usleep(PER_INTERVAL_SLEEP);
		}
	}

	close(s_fd);
	pthread_mutex_lock(&_Mutex);
	pthread_count--;
	pthread_mutex_unlock(&_Mutex);
}





