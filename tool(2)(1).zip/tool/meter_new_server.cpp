#include "meter_client_and_server.h"

/* meter全局变量 */
static Meter_Global _Global;
/* 会话哈希表头指针 */
static dspr_hash_t *_Sess_Hash = NULL;
/* 会话顺序链表头指针 */
static Rslist_t *_Sess_Rslist = NULL;
/* 会话数量 */
static int _Sess_Num = 0;
/* 会话索引值 */
static int _Sess_Index = 0;

/*文件缓存*/
static Meter_Cache _Cache;
/* 线程互斥量 */
pthread_mutex_t _Mutex;
/* 统计当前总包数 */
static int Global_Count_Pkt = 0;

/* 打印提示信息 */
static void usage(char *progname);
/* 解析命令行参数 */
static int argument_parse(int argc, char *argv[]);
/* 注册新会话 */
static Meter_Sess_HashValue *session_register(dspr_hash_t *sess_hash, const struct pcap_pkthdr *header, Meter_Packet_Info *pkt_info);
/* 初始化会话哈希表，将pcap文件中的各会话加入到会话哈希表中 */
static int session_hash_init();
/* 将pcap文件中的包保存到cache中*/
static int cache_init(Meter_Global *global, Meter_Cache *cache);
/* 遍历内存中的包数据 */
static int cache_get_next(Meter_Cache *pcache, Meter_Cache_Control *pctrl, struct pcap_pkthdr **header, const u_char **pkg_data);
/* 解析帧数据 */
static int parse_ethdata(char *eth_data, Meter_Packet_Info *pkt_info);
/* 获取第一次接收到的会话包数据长度 */
static int get_session_pkt_len();
/* 统计会话包数 */
static int get_session_pkt_count(Meter_Sess_HashKey sess_hash_key);
/* 线程体函数，当pcap文件小于800M时使用此函数 */
static void* thread_handler_cache(void *arg);
/* 线程体函数，当pcap文件大于800M时使用此函数 */
static void* thread_handler_big_file(void *arg);

int main(int argc, char *argv[])
{
	char errbuf[PCAP_ERRBUF_SIZE];
	int addr_len = 0;
	int s_fd; 
	int a_fd;
	struct  sockaddr_in s_addr;
	const struct linger lingerie = {1, 1};
	const int on = 1; 
	pthread_attr_t	attr; 
	pthread_t t_id;  
	Rslist_Config rslist_config;
	uint8_t *rslist_start_addr = NULL;

	memset(&_Global, 0, sizeof(Meter_Global));

	/* 忽略SIGPIPE信号，防止异常情况下进程退出 */
	signal(SIGPIPE, SIG_IGN);

	/* 初始化会话哈希表*/
	_Sess_Hash = dspr_hash_new();
	dspr_hash_init(_Sess_Hash,(char*)"SessionHash",10000,NULL,NULL,NULL);

	/* 初始化会话顺序表 */
	memset(&rslist_config,0,sizeof(Rslist_Config));
	rslist_config.total_kbsize = 4096;
	rslist_config.max_slot = 1;
	rslist_config.user_data_size = sizeof(Meter_Sess_HashKey);
	rslist_start_addr = (uint8_t*)malloc(rslist_config.total_kbsize*1024);

	memset(errbuf,0,sizeof(errbuf));
	_Sess_Rslist = Rslist_Init(rslist_start_addr,&rslist_config,errbuf);
	if(_Sess_Rslist == NULL)
	{
		printf("Meter Error: Rslist_Init error:%s\n",errbuf);
		return 0;
	}
	
	pthread_mutex_init(&_Mutex, NULL);

	/* 解析命令行参数 */
	argument_parse(argc, argv);

	/* 打开pcap文件 */
	if ((_Global.pp_file = pcap_open_offline(_Global.pcap_file_name,errbuf)) == NULL)
	{
		printf("\nMeter Error: Unable to open the pcap file:%s %s\n",_Global.pcap_file_name,errbuf);
		return 0;
	}

	/* 获取pcap文件大小*/
	_Global.fp_file = pcap_file(_Global.pp_file);
	_Global.begin_offset = ftell(_Global.fp_file);
	fseek(_Global.fp_file,0,SEEK_END);
	_Global.file_size = ftell(_Global.fp_file);
	fseek(_Global.fp_file,_Global.begin_offset,SEEK_SET);
	if(_Global.file_size > METER_MAX_MEMORY)
	{
		_Global.big_file = 1;
	}
	printf ("Meter Info: File Size %u  Big File? %s\n",_Global.file_size,_Global.big_file?"Yes":"No");

	/* 初始化会话哈希表，将pcap文件中的各会话加入到会话哈希表中 */
	session_hash_init();

	/* 如果不是大文件，则启用Cache机制，把文件中的包读取到Cache，这样以后再操作速度就快了*/
	if (0 == _Global.big_file)
	{
		cache_init(&_Global, &_Cache);
	}

	s_addr.sin_family = AF_INET;
	s_addr.sin_addr.s_addr = INADDR_ANY;
	s_addr.sin_port = _Global.server_port;

	s_fd = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP);
	if (s_fd < 0)
	{
		printf("create socket failed!\n");
		return 0;
	}

	if (setsockopt(s_fd, SOL_SOCKET, SO_LINGER, (char *)&lingerie, sizeof(lingerie)) < 0)
	{
		printf("setsockopt  SO_LINGER failed!\n");
		return 0;
	}
	
	if (setsockopt(s_fd, SOL_SOCKET, SO_REUSEADDR, (char *)&on, sizeof(on)) < 0)
	{
		printf("setsockopt SO_REUSEADDR failed!\n");
		return 0;
	}
	
	if(bind(s_fd, (struct sockaddr *)&s_addr, sizeof(struct sockaddr_in)) < 0)
	{
		printf("bind failed!\n");
		return 0;
	}
	
	listen(s_fd, MAX_LISTEN_NUM);
	while (1)
	{
		addr_len = sizeof(struct sockaddr_in);
		a_fd = accept(s_fd, (struct sockaddr *)&s_addr, (socklen_t *)&addr_len); 
		pthread_attr_init(&attr);
		pthread_attr_setdetachstate(&attr, PTHREAD_CREATE_DETACHED);

		if (0 == _Global.big_file)
		{
			if (pthread_create(&t_id, &attr, thread_handler_cache, &a_fd) != 0) 
			{
				printf("create thread failed!\n");
			}
		}
		else
		{
			if (pthread_create(&t_id, &attr, thread_handler_big_file, &a_fd) != 0) 
			{
				printf("create thread failed!\n");
			}
		}
	}
	return 0;
}

/* 打印提示信息 */
static void usage(char *progname)
{
	printf("\nVersion:%s  %s  Build %s %s\n",
		VERSION,pcap_lib_version(),BUILD_DATE,BUILD_SVN);
	
	printf("\nUasge: %s [option] pcap_file\n",progname);
	printf("Option:\n");
	printf("\t--port         specify server listen port\n");
	
	printf("\nFor Example:\n");
	printf("./meter_new_server --port 7788 loadrunner.pcap\n");
}

/* 解析命令行参数 */
static int argument_parse(int argc,char *argv[])
{
	int arg_num = argc - 1, i;

	if(argc < 3)
	{
		usage(argv[0]);
		exit(0);
	}
	
	_Global.pcap_file_name = argv[argc - 1];
	
	for(i = 1; i < arg_num; i++)
	{
		if(0 == strcmp(argv[i],"--port"))
		{
			i++;
			_Global.server_port = htons(atoi(argv[i]));
			break;
		}
	}

	return 0;
}

/* 注册新会话 */
static Meter_Sess_HashValue *session_register(dspr_hash_t *sess_hash,const struct pcap_pkthdr *header,Meter_Packet_Info *pkt_info)
{
	Meter_Sess_HashKey mhkey;
	Meter_Sess_HashValue *mhvalue1 = NULL;
	Meter_Sess_HashValue *mhvalue2 = NULL;

	mhkey.client_ip = pkt_info->ipv4_header.ip_destaddr;
	mhkey.client_port = pkt_info->tcp_header.dest_port;
	mhkey.server_ip = pkt_info->ipv4_header.ip_srcaddr;
	mhkey.server_port = pkt_info->tcp_header.source_port;
	mhvalue1 = (Meter_Sess_HashValue*)dspr_hash_find(sess_hash,&mhkey,sizeof(Meter_Sess_HashKey));

	mhkey.client_ip = pkt_info->ipv4_header.ip_srcaddr;
	mhkey.client_port = pkt_info->tcp_header.source_port;
	mhkey.server_ip = pkt_info->ipv4_header.ip_destaddr;
	mhkey.server_port = pkt_info->tcp_header.dest_port;	
	mhvalue2 = (Meter_Sess_HashValue*)dspr_hash_find(sess_hash,&mhkey,sizeof(Meter_Sess_HashKey));

	if(!mhvalue1 && !mhvalue2)
	{
		mhvalue2 = (Meter_Sess_HashValue*)malloc(sizeof(Meter_Sess_HashValue));
		if(mhvalue2)
		{
			memset(mhvalue2,0,sizeof(Meter_Sess_HashValue));
			memcpy(&(mhvalue2->key),&mhkey,sizeof(Meter_Sess_HashKey));

			mhvalue2->total_packet++;
			mhvalue2->total_size += header->len;

			dspr_hash_insert(sess_hash,&(mhvalue2->key),sizeof(Meter_Sess_HashKey),mhvalue2,0,0);

			_Sess_Num++;
			Rslist_Insert(_Sess_Rslist, _Sess_Num, &(mhvalue2->key));
		}

		return NULL;
	}

	if (mhvalue1)
	{
		mhvalue1->total_packet++;
		mhvalue1->total_size += header->len;
		return mhvalue1;
	}

	if (mhvalue2)
	{
		mhvalue2->total_packet++;
		mhvalue2->total_size += header->len;
		return mhvalue2;
	}
}

/* 初始化会话哈希表，将pcap文件中的各会话加入到会话哈希表中 */
static int session_hash_init()
{
	int res = 0;
	struct pcap_pkthdr *header = NULL;
	const u_char *pkt_data = NULL;
	Dbfw_EthernetFrame eth_frame;
	Meter_Packet_Info pkt_info;
	
	fseek(_Global.fp_file,_Global.begin_offset,SEEK_SET);
	while(pcap_next_ex(_Global.pp_file, &header, &pkt_data) >= 0)
	{
		/*解析网络包*/
		memset(&eth_frame,0,sizeof(eth_frame));
		memset(&pkt_info,0,sizeof(pkt_info));		
		eth_frame.frame_data = (u_char*)pkt_data;
		eth_frame.frame_size = header->len;
		res = Dbfw_Protocol_Parse(&eth_frame,&pkt_info,NULL);
		if(res != meter_proto_cs)
		{
			continue;
		}

		/*放入哈希表*/
		session_register(_Sess_Hash,header,&pkt_info);
	}
	return 0;
}

/* 将pcap文件中的包保存到cache中*/
static int cache_init(Meter_Global *global, Meter_Cache *cache)
{
	int res = 0, count = 0;
	struct pcap_pkthdr *header = NULL;
	const u_char *pkt_data = NULL;
	Dbfw_EthernetFrame eth_frame;
	Meter_Packet_Info pkt_info;
	
	cache->size = 0;
	cache->begin_offset = global->begin_offset;
	cache->data = (u_char*)realloc(cache->data, global->begin_offset);
	if(NULL == cache->data)
	{
		return -1;
	}
	cache->size += global->begin_offset;
	fseek(global->fp_file,0,SEEK_SET);
	fread(cache->data,1,global->begin_offset,global->fp_file);

	cache->length = global->begin_offset;
	fseek(global->fp_file,cache->begin_offset,SEEK_SET);
	while(pcap_next_ex(global->pp_file, &header, &pkt_data) >= 0)
	{
		//解析网络包
		memset(&eth_frame,0,sizeof(eth_frame));
		memset(&pkt_info,0,sizeof(pkt_info));		
		eth_frame.frame_data = (u_char*)pkt_data;
		eth_frame.frame_size = header->len;
		res = Dbfw_Protocol_Parse(&eth_frame,&pkt_info,NULL);
		if(res != meter_proto_cs)
		{
			continue;
		}

		if (pkt_info.data_size == 0)
		{
			count++;
		}
		
		cache->data = (u_char*)realloc(cache->data, cache->size+sizeof(struct pcap_pkthdr)+header->caplen);
		if(NULL == cache->data)
		{
			return -1;
		}
		cache->size += sizeof(struct pcap_pkthdr)+header->caplen;

		//放入Cache
		memcpy(cache->data+cache->length,header,sizeof(struct pcap_pkthdr));
		cache->length += sizeof(struct pcap_pkthdr);
		memcpy(cache->data+cache->length,pkt_data,header->caplen);
		cache->length += header->caplen;
		
		cache->packet_count++;
	}

	printf("Meter Packet: Total=%d(=0:%d, >0:%d)  Size=%d\n",cache->packet_count, count, cache->packet_count-count, cache->length);
	printf("Meter Session: Total=%d\n",dspr_hash_count(_Sess_Hash));
	return 0;
}

/* 遍历内存中的包数据 */
static int cache_get_next(Meter_Cache *pcache, Meter_Cache_Control *pctrl, struct pcap_pkthdr **header, const u_char **pkg_data)
{
	if(pctrl->cursor >= pcache->length)
	{
		return -1;
	}
	*header = (struct pcap_pkthdr*)(pcache->data + pctrl->cursor);
	pctrl->cursor += sizeof(struct pcap_pkthdr);
	*pkg_data = pcache->data + pctrl->cursor;
	pctrl->cursor += (*header)->caplen;
	return 0;
}

/* 解析帧数据 */
static int parse_ethdata(char *eth_data, Meter_Packet_Info *pkt_info)
{
	unsigned int ethdata_cursor = 0;
	unsigned short eth_type;
	
	if (!eth_data || !pkt_info)
	{
		return -1;
	}

        memcpy(&(pkt_info->ethernet),(u_char*)eth_data,sizeof(PROTO_ETHERNET));
        ethdata_cursor += sizeof(PROTO_ETHERNET);
        eth_type = htons((pkt_info->ethernet).type);
        /* 检查ethernet.type */
        while(eth_type==0x8100)
        {
            /* 
                Type: 802.1Q Virtual LAN (0x8100),后面跟着2字节的VLan信息和2字节的type信息 
                这里假设type信息就是0x8000
            */
            ethdata_cursor += 2;   
            memcpy(&eth_type,(u_char*)eth_data+ethdata_cursor,sizeof(u_short));
            eth_type = htons(eth_type);
            ethdata_cursor += 2; 
            /* 
                重要的防守逻辑：
                理论上，可能会出现多次VLand，但不应该出现大量的VLan，因此这里设置一个防守逻辑：如果超过5次的VLan(20字节)则认为是不正确的TCPIP包 
            */
            if(ethdata_cursor>(14+20))
            {
                continue;
            }
        }
        /* 解析IPV4头部数据 */
        memcpy(&(pkt_info->ipv4_header),(u_char*)eth_data+ethdata_cursor,sizeof(PROTO_IPV4_HEADER));        
        ethdata_cursor += sizeof(PROTO_IPV4_HEADER);
		
        /* 取得TCP的端口 */
        memcpy(&(pkt_info->tcp_header),(u_char*)eth_data+ethdata_cursor,sizeof(PROTO_TCP_HDR));
}

/* 获取第一次接收到的会话包数据长度 */
static int get_session_pkt_len()
{
	int res;
	struct pcap_pkthdr *header = NULL;
	const u_char *pkt_data = NULL;
	char pkt_buffer[MC_MAX_PACKAGESIZE];
	Dbfw_EthernetFrame eth_frame;
	Meter_Packet_Info local_pkt_info;
	Meter_Cache_Control pcontrol;

	memset(&pcontrol, 0, sizeof(Meter_Broadcast_Cache_Control));

	pcontrol.cursor = _Cache.begin_offset;
	while(0 == cache_get_next(&_Cache,&pcontrol,&header,&pkt_data))
	{
		memset(pkt_buffer,0,MC_MAX_PACKAGESIZE);
		memcpy(pkt_buffer,pkt_data,header->caplen);
		eth_frame.frame_data = (u_char*)pkt_buffer;
		eth_frame.frame_size = header->len;
		res = Dbfw_Protocol_Parse(&eth_frame,&local_pkt_info,NULL);
		if(res != meter_proto_cs)
		{
			continue;
		}
	
		/* 将数据长度为0的包过滤掉 */
		if (local_pkt_info.data_size == 0)
		{
			continue;
		}
		if (local_pkt_info.direction == mb_pkt_dct_request)
		{
			break;
		}		
	}	

	return local_pkt_info.data_size + sizeof(Meter_Sess_HashKey);
}

/* 统计会话包数 */
static int get_session_pkt_count(Meter_Sess_HashKey sess_hash_key)
{
	int res, select_ret = 0, count_pkt = 0;
	struct pcap_pkthdr *header = NULL;
	const u_char *pkt_data = NULL;
	char pkt_buffer[MC_MAX_PACKAGESIZE];
	Dbfw_EthernetFrame eth_frame;
	Meter_Packet_Info local_pkt_info;
	Meter_Cache_Control pcontrol;

	memset(&pcontrol, 0, sizeof(Meter_Broadcast_Cache_Control));

	pcontrol.cursor = _Cache.begin_offset;

	while(0 == cache_get_next(&_Cache,&pcontrol,&header,&pkt_data))
	{
		memset(pkt_buffer,0,MC_MAX_PACKAGESIZE);
		memcpy(pkt_buffer,pkt_data,header->caplen);
		eth_frame.frame_data = (u_char*)pkt_buffer;
		eth_frame.frame_size = header->len;
		res = Dbfw_Protocol_Parse(&eth_frame,&local_pkt_info,NULL);
		if(res != meter_proto_cs)
		{
			continue;
		}

		/* 将数据长度为0的包过滤掉 */
		if (local_pkt_info.data_size == 0)
		{
			continue;
		}
		/* 判断当前包是否属于本会话 */
		if ((sess_hash_key.client_ip == local_pkt_info.ipv4_header.ip_srcaddr &&
			sess_hash_key.client_port == local_pkt_info.tcp_header.source_port &&
			sess_hash_key.server_ip == local_pkt_info.ipv4_header.ip_destaddr &&
			sess_hash_key.server_port == local_pkt_info.tcp_header.dest_port) ||
			(sess_hash_key.client_ip == local_pkt_info.ipv4_header.ip_destaddr &&
			sess_hash_key.client_port == local_pkt_info.tcp_header.dest_port &&
			sess_hash_key.server_ip == local_pkt_info.ipv4_header.ip_srcaddr &&
			sess_hash_key.server_port == local_pkt_info.tcp_header.source_port))
		{
			count_pkt++;
		}
	}

	return count_pkt;
}

/* 线程体函数，当pcap文件小于800M时使用此函数 */
static void* thread_handler_cache(void *arg)
{
	int res, select_ret = 0, send_ret = 0;
	int s_fd = *(int*)arg;
	fd_set rset;
	struct timeval select_tv;
	struct pcap_pkthdr *header = NULL;
	const u_char *pkt_data = NULL;
	char buff[MC_MAX_PACKAGESIZE];
	char pkt_buffer[MC_MAX_PACKAGESIZE];
	unsigned int recv_len = 0;
	pthread_t cur_t_id;
	Dbfw_EthernetFrame eth_frame;
	Meter_Sess_HashKey sess_hash_key;
	Meter_Sess_HashKey *p_sess_hash_key = NULL;
	Meter_Packet_Info local_pkt_info;
	Meter_Cache_Control pcontrol;

	FD_ZERO(&rset);
	FD_SET(s_fd, &rset);

	select_tv.tv_sec = 0;
	select_tv.tv_usec = SELECT_TIME_OUT;

	memset(&pcontrol, 0, sizeof(Meter_Broadcast_Cache_Control));
	
	/* 如果会话索引数等于会话数则将索引数归零 */
	if (_Sess_Index == _Sess_Num)
	{
		_Sess_Index = 0;
	}
	
	pthread_mutex_lock(&_Mutex);
	_Sess_Index++;
	pthread_mutex_unlock(&_Mutex);

	cur_t_id = pthread_self();

	p_sess_hash_key = (Meter_Sess_HashKey*)Rslist_Find(_Sess_Rslist, _Sess_Index);
	if (!p_sess_hash_key)
	{
		printf("rslist find failed\n");
		pthread_exit((void*)0);
	}

	sess_hash_key.client_ip = p_sess_hash_key->client_ip;
	sess_hash_key.client_port = p_sess_hash_key->client_port;
	sess_hash_key.server_ip = p_sess_hash_key->server_ip;
	sess_hash_key.server_port = p_sess_hash_key->server_port;

	while (1)
	{
		pcontrol.cursor = _Cache.begin_offset;
		
		while(0 == cache_get_next(&_Cache,&pcontrol,&header,&pkt_data))
		{
			memset(buff, 0, MC_MAX_PACKAGESIZE);
			memset(pkt_buffer,0,MC_MAX_PACKAGESIZE);
			memcpy(pkt_buffer,pkt_data,header->caplen);
			eth_frame.frame_data = (u_char*)pkt_buffer;
			eth_frame.frame_size = header->len;
			res = Dbfw_Protocol_Parse(&eth_frame,&local_pkt_info,NULL);
			if(res != meter_proto_cs)
			{
				continue;
			}
		
			/* 将数据长度为0的包过滤掉 */
			if (local_pkt_info.data_size == 0)
			{
				continue;
			}
		
			/* 判断当前包是否属于本会话 */
			if ((sess_hash_key.client_ip == local_pkt_info.ipv4_header.ip_srcaddr &&
				sess_hash_key.client_port == local_pkt_info.tcp_header.source_port &&
				sess_hash_key.server_ip == local_pkt_info.ipv4_header.ip_destaddr &&
				sess_hash_key.server_port == local_pkt_info.tcp_header.dest_port) ||
				(sess_hash_key.client_ip == local_pkt_info.ipv4_header.ip_destaddr &&
				sess_hash_key.client_port == local_pkt_info.tcp_header.dest_port &&
				sess_hash_key.server_ip == local_pkt_info.ipv4_header.ip_srcaddr &&
				sess_hash_key.server_port == local_pkt_info.tcp_header.source_port))
			{
				pthread_mutex_lock(&_Mutex);
				Global_Count_Pkt++;
				pthread_mutex_unlock(&_Mutex);
			
				if (local_pkt_info.direction == mb_pkt_dct_request)
				{
					FD_ZERO(&rset);
					FD_SET(s_fd, &rset);
					
					select_tv.tv_sec = 0;
					select_tv.tv_usec = SELECT_TIME_OUT;
					select_ret = select(s_fd + 1, &rset, NULL, NULL, &select_tv);
					if (select_ret < 0)
					{
						/* 可能是客户端断开了连接 */
						printf("close connection\n");
						pthread_exit((void*)0);
					}
					else if (select_ret > 0)
					{
						if (FD_ISSET(s_fd, &rset))
						{
							recv_len = recv(s_fd, buff, local_pkt_info.data_size, 0);
							if (recv_len <= 0)
							{
							   /* 可能是客户端断开了连接 */
							   printf("close connection\n");
							   pthread_exit((void*)0);
							}

							pthread_mutex_lock(&_Mutex);
							_Global.total_package_count++;
							pthread_mutex_unlock(&_Mutex);
							
							printf("cur_worker:%ld  current package num:%d	ip_total_len:%d  recv_len:%d\n", cur_t_id, _Global.total_package_count, local_pkt_info.ipv4_header.ip_total_length, recv_len);
						}
					}
					else /* 接收等待超时*/
					{
						printf("time out!!!\n");
						printf("cur_worker:%ld  current package num:%d	ip_total_len:%d \n", cur_t_id, _Global.total_package_count, local_pkt_info.ipv4_header.ip_total_length);
					}
				}
				else
				{
					send_ret = send(s_fd, local_pkt_info.tcp_data, local_pkt_info.data_size, 0);
					if (send_ret < 0)
					{
						if (errno == EAGAIN || errno == EWOULDBLOCK)
						{
							send(s_fd, local_pkt_info.tcp_data, local_pkt_info.data_size, 0);
						}
						else
						{
							/* 可能是客户端断开了连接 */
							printf("close connection\n");
							pthread_exit((void*)0);
						}
					}

					pthread_mutex_lock(&_Mutex);
					_Global.total_package_count++;
					pthread_mutex_unlock(&_Mutex);
					
					printf("cur_worker:%ld  current package num:%d	ip_total_len:%d  send_len:%d\n", cur_t_id, _Global.total_package_count, local_pkt_info.ipv4_header.ip_total_length, local_pkt_info.data_size);
				}
			}
		
			usleep(PER_INTERVAL_SLEEP);
		}
	}
}

/* 线程体函数，当pcap文件大于800M时使用此函数 */
static void* thread_handler_big_file(void *arg)
{
	int res, select_ret = 0, send_ret = 0;
	int s_fd = *(int*)arg;
	fd_set rset;
	struct timeval select_tv;
	struct pcap_pkthdr *header = NULL;
	const u_char *pkt_data = NULL;
	char buff[MC_MAX_PACKAGESIZE];
	char pkt_buffer[MC_MAX_PACKAGESIZE];
	unsigned int recv_len = 0;
	pthread_t cur_t_id;
	Dbfw_EthernetFrame eth_frame;
	Meter_Sess_HashKey sess_hash_key;
	Meter_Sess_HashKey *p_sess_hash_key = NULL;
	Meter_Packet_Info local_pkt_info;
	Meter_Cache_Control pcontrol;

	FD_ZERO(&rset);
	FD_SET(s_fd, &rset);

	select_tv.tv_sec = 0;
	select_tv.tv_usec = SELECT_TIME_OUT;

	memset(&pcontrol, 0, sizeof(Meter_Broadcast_Cache_Control));
	
	/* 如果会话索引数等于会话数则将索引数归零 */
	if (_Sess_Index == _Sess_Num)
	{
		_Sess_Index = 0;
	}
	
	pthread_mutex_lock(&_Mutex);
	_Sess_Index++;
	pthread_mutex_unlock(&_Mutex);

	cur_t_id = pthread_self();

	p_sess_hash_key = (Meter_Sess_HashKey*)Rslist_Find(_Sess_Rslist, _Sess_Index);
	if (!p_sess_hash_key)
	{
		printf("rslist find failed\n");
		pthread_exit((void*)0);
	}

	sess_hash_key.client_ip = p_sess_hash_key->client_ip;
	sess_hash_key.client_port = p_sess_hash_key->client_port;
	sess_hash_key.server_ip = p_sess_hash_key->server_ip;
	sess_hash_key.server_port = p_sess_hash_key->server_port;

	while (1)
	{
		pcontrol.cursor = _Cache.begin_offset;
		
		fseek(_Global.fp_file,_Global.begin_offset,SEEK_SET);
		while(pcap_next_ex(_Global.pp_file, &header, &pkt_data) >= 0)
		{
			memset(buff, 0, MC_MAX_PACKAGESIZE);
			memset(pkt_buffer,0,MC_MAX_PACKAGESIZE);
			memcpy(pkt_buffer,pkt_data,header->caplen);
			eth_frame.frame_data = (u_char*)pkt_buffer;
			eth_frame.frame_size = header->len;
			res = Dbfw_Protocol_Parse(&eth_frame,&local_pkt_info,NULL);
			if(res != meter_proto_cs)
			{
				continue;
			}
		
			/* 将数据长度为0的包过滤掉 */
			if (local_pkt_info.data_size == 0)
			{
				continue;
			}
		
			/* 判断当前包是否属于本会话 */
			if ((sess_hash_key.client_ip == local_pkt_info.ipv4_header.ip_srcaddr &&
				sess_hash_key.client_port == local_pkt_info.tcp_header.source_port &&
				sess_hash_key.server_ip == local_pkt_info.ipv4_header.ip_destaddr &&
				sess_hash_key.server_port == local_pkt_info.tcp_header.dest_port) ||
				(sess_hash_key.client_ip == local_pkt_info.ipv4_header.ip_destaddr &&
				sess_hash_key.client_port == local_pkt_info.tcp_header.dest_port &&
				sess_hash_key.server_ip == local_pkt_info.ipv4_header.ip_srcaddr &&
				sess_hash_key.server_port == local_pkt_info.tcp_header.source_port))
			{
				pthread_mutex_lock(&_Mutex);
				Global_Count_Pkt++;
				pthread_mutex_unlock(&_Mutex);
			
				if (local_pkt_info.direction == mb_pkt_dct_request)
				{
					FD_ZERO(&rset);
					FD_SET(s_fd, &rset);
					
					select_tv.tv_sec = 0;
					select_tv.tv_usec = SELECT_TIME_OUT;
					select_ret = select(s_fd + 1, &rset, NULL, NULL, &select_tv);
					if (select_ret < 0)
					{
						/* 可能是客户端断开了连接 */
						printf("close connection\n");
						pthread_exit((void*)0);
					}
					else if (select_ret > 0)
					{
						if (FD_ISSET(s_fd, &rset))
						{
							recv_len = recv(s_fd, buff, local_pkt_info.data_size, 0);
							if (recv_len <= 0)
							{
							   /* 可能是客户端断开了连接 */
							   printf("close connection\n");
							   pthread_exit((void*)0);
							}

							pthread_mutex_lock(&_Mutex);
							_Global.total_package_count++;
							pthread_mutex_unlock(&_Mutex);
							
							printf("cur_worker:%ld	current package num:%d	ip_total_len:%d  recv_len:%d\n", cur_t_id, _Global.total_package_count, local_pkt_info.ipv4_header.ip_total_length, recv_len);
						}
					}
					else /* 接收等待超时*/
					{
						printf("time out!!!\n");
						printf("cur_worker:%ld	current package num:%d	ip_total_len:%d \n", cur_t_id, _Global.total_package_count, local_pkt_info.ipv4_header.ip_total_length);
					}
				}
				else
				{
					send_ret = send(s_fd, local_pkt_info.tcp_data, local_pkt_info.data_size, 0);
					if (send_ret < 0)
					{
						if (errno == EAGAIN || errno == EWOULDBLOCK)
						{
							send(s_fd, local_pkt_info.tcp_data, local_pkt_info.data_size, 0);
						}
						else
						{
							/* 可能是客户端断开了连接 */
							printf("close connection\n");
							pthread_exit((void*)0);
						}
					}

					pthread_mutex_lock(&_Mutex);
					_Global.total_package_count++;
					pthread_mutex_unlock(&_Mutex);
					
					printf("cur_worker:%ld	current package num:%d	ip_total_len:%d  send_len:%d\n", cur_t_id, _Global.total_package_count, local_pkt_info.ipv4_header.ip_total_length, local_pkt_info.data_size);
				}
			}
		
			usleep(PER_INTERVAL_SLEEP);
		}
	}
}



