#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <errno.h>
#include <time.h>
#include <sys/time.h>
#include <unistd.h>
#include <pthread.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <linux/socket.h>
#include <netinet/in.h>
#include <netdb.h>
#include <linux/if.h>
#include <linux/if_ether.h>
#include <arpa/inet.h>
#include <linux/ip.h>
//#include <linux/tcp.h>
#include <netinet/tcp.h>

#include <pcap.h>

#include "librslist.h"

#include "config.h"
#include "meter_broadcast.h"
#include "meter_utils.h"
#include "protocol_analysis.h"

#ifdef __cplusplus
extern "C" {
#endif

#ifdef METER_PPS_USLEEP
#undef METER_PPS_USLEEP
#define METER_PPS_USLEEP       100000  //100
#endif

//全局变量
static Meter_Broadcast_Global _Global;

//打包规则
static Meter_Broadcast_Rule _Rule;

static dspr_hash_t *_Sess_Hash = NULL;
static Rslist_t *_Server_Rslist = NULL;
static Rslist_t *_ServerIp_Rslist = NULL;

//局部函数
static int argument_parse(int argc,char *argv[]);

void milliseconds_sleep(long mSec){
	struct timeval tv;
	tv.tv_sec=mSec/1000000;
	tv.tv_usec=mSec%1000000;
	int err;
	do{
		err=select(0,NULL,NULL,NULL,&tv);
	}while(err<0 && errno==EINTR);
}

static int meter_broadcast_file_one(Meter_Broadcast_Cache_Control *pcontrol)
{
	int res = 0,first_packet= 1;
	struct pcap_pkthdr *header = NULL;
	struct timeval lasttime,last_sendtime,curr_time;
	const u_char *pkt_data = NULL;
	long sleep_time = 0,waste_time=0,intval_time=0,sleep_waste=0,real_sleeptime; //measured as microseconds

	pcontrol->curr_npack = 0;
	pcontrol->curr_nsize = 0;
	fseek(_Global.fp_file,_Global.begin_offset,SEEK_SET);
	memset(&lasttime,0,sizeof(struct timeval));
	memset(&last_sendtime,0,sizeof(struct timeval));
	memset(&curr_time,0,sizeof(struct timeval));
	gettimeofday(&last_sendtime,NULL);
	intval_time = _Global.worker_max * 1000;
	while((res = pcap_next_ex(_Global.pp_file, &header, &pkt_data)) >= 0)
	{
		if(first_packet)
		{
			first_packet = 0;
			lasttime.tv_sec = header->ts.tv_sec;
			lasttime.tv_usec = header->ts.tv_usec;
		}
		memset(pcontrol->pkt_buffer,0,pcontrol->buffer_size);
		memcpy(pcontrol->pkt_buffer,pkt_data,header->caplen);
		
		if(_Global.worker_max > 0)
		{
			sleep_time = (header->ts.tv_sec - lasttime.tv_sec)*1000000 + (header->ts.tv_usec - lasttime.tv_usec);
			if(sleep_time > intval_time)
			{
				gettimeofday(&curr_time,NULL);
				waste_time = (curr_time.tv_sec - last_sendtime.tv_sec)*1000000 + (curr_time.tv_usec - last_sendtime.tv_usec);
				sleep_time = sleep_time - waste_time*_Global.worker_max - sleep_waste*_Global.worker_max;
				if(sleep_time > intval_time)
				{
					lasttime.tv_sec = header->ts.tv_sec; 
					lasttime.tv_usec = header->ts.tv_usec;
					last_sendtime.tv_sec = curr_time.tv_sec;
					last_sendtime.tv_usec = curr_time.tv_usec;
					sleep_time = sleep_time/_Global.worker_max;
					milliseconds_sleep(sleep_time);

					gettimeofday(&curr_time,NULL);
					real_sleeptime = (curr_time.tv_sec - last_sendtime.tv_sec)*1000000 + (curr_time.tv_usec - last_sendtime.tv_usec);
					sleep_waste = real_sleeptime - sleep_time;
					last_sendtime.tv_sec = curr_time.tv_sec;
					last_sendtime.tv_usec = curr_time.tv_usec;
				}
			}
		}

		if(pcap_sendpacket(_Global.pp_dev,pcontrol->pkt_buffer,header->len) != 0)
		{
			fprintf(stderr,"Meter Error: Sending the packet: %s\n", pcap_geterr(_Global.pp_dev));
			continue;
		}

		if(_Global.worker_max == 0)
		{
			if(_Global.pkt_per_interval > 0 && (pcontrol->curr_npack % _Global.pkt_per_interval == 0))
			{
				usleep(METER_PPS_USLEEP);
			}
		}
		pcontrol->curr_npack++;
		pcontrol->curr_nsize += header->len;
	}
	pcontrol->loop_count++;
	pcontrol->total_npack += pcontrol->curr_npack;
	pcontrol->total_nsize += pcontrol->curr_nsize;	
	printf ("Loop:%03u Send packets count:%u size:%llu\n", pcontrol->loop_count,pcontrol->curr_npack,pcontrol->curr_nsize);
	return 0;
}

static int meter_broadcast_file_loop(Meter_Broadcast_Cache_Control *pcontrol)
{
	int count=0;
	struct timeval tvbegin,tvend;
	int elapsed = 0;

	if(NULL == pcontrol)
	{
		return -1;
	}

	pcontrol->buffer_size = METER_MAX_PKT_BUFFER;
	pcontrol->pkt_buffer = (u_char*)malloc(pcontrol->buffer_size);
	if(!pcontrol->pkt_buffer)
	{
		return -1;
	}

	gettimeofday(&tvbegin,NULL);
	for(count=0;count<_Global.loop_max;count++)
	{
		if(_Global.interval >0 && count >0)
			usleep(_Global.interval);
		meter_broadcast_file_one(pcontrol);
	}
	gettimeofday(&tvend,NULL);
	
	tvend.tv_usec /= 1000;
	tvbegin.tv_usec /= 1000;
	elapsed = (tvend.tv_sec - tvbegin.tv_sec)*1000 + (tvend.tv_usec - tvbegin.tv_usec);
	
	printf ("Loop:%03d Total packets count:%d size:%llu Elapsed time:%d\n",
		pcontrol->loop_count,pcontrol->total_npack,pcontrol->total_nsize,elapsed);
	free(pcontrol->pkt_buffer);
	return 0;
}

struct Pcap_Loop_Param
{
	pcap_dumper_t *dumpfile;
	pcap_dumper_t *responsefile;
	int total_packet;
	int filter_packet;
	int dual;
	u_char *pkt_buffer;
	int buffer_size;
};

static int meter_exit()
{
	if(_Global.pp_file)
		pcap_close(_Global.pp_file);
	if(_Global.pp_dev)
		pcap_close(_Global.pp_dev);
	if(_Sess_Hash)
		dspr_hash_destroy(&_Sess_Hash);
	if(_Server_Rslist){
		Rslist_Destroy(_Server_Rslist);
		free(_Server_Rslist);
	}
	return 0;
}

int main(int argc, char *argv[])
{
	char errbuf[PCAP_ERRBUF_SIZE];
	Rslist_Config config;
	uint8_t *start_addr = NULL;
	int pps_min = 1000000/METER_PPS_USLEEP;

	memset(&_Global,0,sizeof(Meter_Broadcast_Global));
	_Global.loop_max = 1;
	_Global.worker_max = 1;
	_Global.interval = METER_DEF_INTERVAL;
	_Global.syn_delay = 0;
	_Global.pkt_per_sec = METER_DEF_PPS;//默认每秒钟的包个数
	_Global.pkt_per_interval = 0;
	_Global.concurrency_max = METER_MAX_CONCURRENCY;
	
	memset(&_Rule,0,sizeof(Meter_Broadcast_Rule));
	_Rule.client_rule = dspr_hash_new();
	dspr_hash_init(_Rule.client_rule,(char*)"ClientRule",4096,NULL,NULL,NULL);
	_Rule.server_rule = dspr_hash_new();
	dspr_hash_init(_Rule.server_rule,(char*)"ServerRule",4096,NULL,NULL,NULL);
	
	argument_parse(argc,argv);
	_Global.interval *= 1000;
	if(_Global.pkt_per_sec > 0 && _Global.pkt_per_sec < pps_min)
		_Global.pkt_per_sec = pps_min;
	if(_Global.pkt_per_sec < 0)
		_Global.pkt_per_sec = 0;
	_Global.pkt_per_interval = _Global.pkt_per_sec/pps_min;
	
	printf("Meter Info:  meter_broadcast version:%s  libpcap version:%s\n",VERSION,pcap_lib_version());
	printf("Meter Info:  Mode 'Replay'  Interface '%s'  Pcap_File '%s'\n", _Global.interface_name,_Global.pcap_file_name);
	printf("Meter Info:  Speed num %d  Loop Count %d  Interval %d msec  Package/Second %d \n",
			_Global.worker_max,_Global.loop_max,_Global.interval,_Global.pkt_per_sec);

	//dspr_hash_enum(_Rule.client_rule,rule_stat_cb,NULL);
	
	/* Open the pcap file */
	if ((_Global.pp_file = pcap_open_offline(_Global.pcap_file_name,errbuf)) == NULL)
	{
		fprintf(stderr,"\nMeter Error: Unable to open the pcap file:%s %s\n",_Global.pcap_file_name,errbuf);
		return 2;
	}
	
	//获取文件信息
	_Global.fp_file = pcap_file(_Global.pp_file);
	_Global.begin_offset = ftell(_Global.fp_file);
	fseek(_Global.fp_file,0,SEEK_END);
	_Global.file_size = ftell(_Global.fp_file);
	fseek(_Global.fp_file,_Global.begin_offset,SEEK_SET);

	_Sess_Hash = dspr_hash_new();
	dspr_hash_init(_Sess_Hash,(char*)"SessionHash",10000,NULL,NULL,NULL);

	memset(&config,0,sizeof(Rslist_Config));
	config.total_kbsize = 4096;
	config.max_slot = 1;
//	config.verbose = 1;
	config.user_data_size = sizeof(Meter_Server_Listen_Value);
	start_addr = (uint8_t*)malloc(config.total_kbsize*1024);

	memset(errbuf,0,sizeof(errbuf));
	_Server_Rslist = Rslist_Init(start_addr,&config,errbuf);
	if(_Server_Rslist == NULL)
		printf("Meter Error: Rslist_Init error:%s\n",errbuf);

	memset(&config,0,sizeof(Rslist_Config));
	config.total_kbsize = 2048;
	config.max_slot = 1;
//	config.verbose = 1;
	config.user_data_size = sizeof(Meter_Server_Ip_Value);
	start_addr = (uint8_t*)malloc(config.total_kbsize*1024);

	memset(errbuf,0,sizeof(errbuf));
	_ServerIp_Rslist = Rslist_Init(start_addr,&config,errbuf);
	if(_ServerIp_Rslist == NULL)
		printf("Meter Error: Rslist_Init error:%s\n",errbuf);
	
	/* 打开网卡设备*/
	if ((_Global.pp_dev = pcap_open_live(_Global.interface_name,		// name of the device
						 65536,	// portion of the packet to capture. It doesn't matter in this case 
						 1,	// promiscuous mode (nonzero means promiscuous)
						 1000,			// read timeout
						 errbuf			// error buffer
						 )) == NULL)
	{
		fprintf(stderr,"\nMeter Error: Unable to open the adapter:%s\n",_Global.interface_name);
		meter_exit();
		return 2;
	}

    Meter_Broadcast_Cache_Control control;
    memset(&control,0,sizeof(Meter_Broadcast_Cache_Control));
    control.id = 1;
    control.loop_max = _Global.loop_max;
    meter_broadcast_file_loop(&control);

	meter_exit();
	printf ("\nMeter Info: Broadcast successfully quit\n");
	return 0;
}

static void usage(char *progname)
{
	printf("\nVersion:%s  %s  Build %s %s\n",
		VERSION,pcap_lib_version(),BUILD_DATE,BUILD_SVN);
	
	printf("\nUasge: %s [option] [interface] pcap_file\n",progname);
	printf("Option:\n");
	printf("\t--loop count            loop count (default:1)\n");
	printf("\t--speed num             multi num speed of the original pcap file (conflict with pps) (default:1)\n");
	printf("\t--pps num               packet percent second (default:%d)\n",METER_DEF_PPS);
	printf("\t--interval msec         interval (default:%d)\n",METER_DEF_INTERVAL);
	
	printf("\nFor Example:\n");
	printf("./meter_broadcast eth0 loadrunner.pcap\n");
	printf("./meter_broadcast --loop 10 eth3 loadrunner.pcap\n");
	
	printf("\nNote:\n");
	printf("with 'Message too long' error,run command on send machine and recv machine\n");
	printf("[root@localhost]#/sbin/ifconfig eth3 mtu 8192\n\n");

	exit(0);
}

static int argument_replace_rule(char *data,dspr_hash_t *phash)
{
	Meter_Broadcast_Rule_Value *rvalue = NULL,*ovalue = NULL;
	char buffer[256],*ppos = NULL,*pport = NULL;;
	unsigned int ipbottom = 0,iptop = 0,port = 0;
	
	rvalue = (Meter_Broadcast_Rule_Value*)malloc(sizeof(Meter_Broadcast_Rule_Value));
	if(NULL == rvalue)
	{
		return -1;
	}
	memset(rvalue,0,sizeof(rvalue));
	
	memset(buffer,0,sizeof(buffer));
	memcpy(buffer,data,sizeof(buffer)-1);
	ppos = strstr(buffer,METER_REPLACE_SEP);
	if(ppos)
	{
		*ppos = 0;
		ppos += strlen(METER_REPLACE_SEP);
	}
	pport = strchr(buffer,':');
	if(pport)
	{
		*pport++ = 0;
		rvalue->key.port = atoi(pport);
	}
	parse_single_ipaddr(buffer,&ipbottom,&iptop);
	rvalue->key.ipaddr = ipbottom;

	if(ppos)
	{
		pport = strchr(ppos,':');
		if(pport)
		{
			*pport++ = 0;
			port = atoi(pport);
			rvalue->sim.port = DBFW_HTON16(port);
		}
		parse_single_ipaddr(ppos,&ipbottom,&iptop);
		rvalue->sim.ipaddr = DBFW_HTON32(ipbottom);//sim 地址需要字节转换
	}
	ovalue = (Meter_Broadcast_Rule_Value*)dspr_hash_find(
			phash,&(rvalue->key),sizeof(Meter_Broadcast_Id));
	if(NULL == ovalue)
	{
//		hex_print("Meter Info:",(unsigned char*)&(rvalue->key),sizeof(Meter_Broadcast_Id));
		dspr_hash_insert(phash,&(rvalue->key),sizeof(Meter_Broadcast_Id),rvalue,0,0);
	}
	else
	{
		printf("Meter Error: Repeat Ipaddr '%s'\n",data);
		free(rvalue);
		return -2;
	}

	return 0;
}

static int argument_parse(int argc,char *argv[])
{
	int arg_num = argc - 1,i;

	if(argc < 3)
	{
		usage(argv[0]);
		return 0;
	}
	_Global.pcap_file_name = argv[argc - 1];
	
	for(i = 1; i < arg_num; i++)
	{
		if(i == arg_num - 1){
			_Global.interface_name = argv[i];
			break;
		}
		if(0 == strcmp(argv[i],"--speed"))
		{
			if(i >= arg_num - 1){
				printf("Meter Error: argument '%s' error\n",argv[i]);
				usage(argv[0]);
				return -1;
			}
			i++;
			_Global.worker_max = atoi(argv[i]);
		}
		else if(0 == strcmp(argv[i],"--loop"))
		{
			if(i >= arg_num-1){
				printf("Meter Error: argument '%s' error\n",argv[i]);
				usage(argv[0]);
				return -1;
			}
			i++;
			_Global.loop_max = atoi(argv[i]);
			_Global.loop_max = (_Global.loop_max < 1)?1:_Global.loop_max;
		}
		else if(0 == strcmp(argv[i],"--pps"))
		{
			if(i >= arg_num-1){
				printf("Meter Error: argument '%s' error\n",argv[i]);
				usage(argv[0]);
				return -1;
			}
			i++;
			_Global.pkt_per_sec = atoi(argv[i]);
		}
		else if(0 == strcmp(argv[i],"--server"))
		{
			if(i >= arg_num-1){
				printf("Meter Error: argument '%s' error\n",argv[i]);
				usage(argv[0]);
				return -1;
			}
			i++;
			argument_replace_rule(argv[i],_Rule.server_rule);
		}
		else if(0 == strcmp(argv[i],"--client"))
		{
			if(i >= arg_num-1){
				printf("Meter Error: argument '%s' error\n",argv[i]);
				usage(argv[0]);
				return -1;
			}
			i++;
			argument_replace_rule(argv[i],_Rule.client_rule);
		}
		else if(0 == strcmp(argv[i],"--sequence"))
		{
			if(i >= arg_num-1){
				printf("Meter Error: argument '%s' error\n",argv[i]);
				usage(argv[0]);
				return -1;
			}
			i++;
			_Global.sequence = strtoul(argv[i],NULL,10);
		}
		else if(0 == strcmp(argv[i],"--interval"))
		{
			if(i >= arg_num-1){
				printf("Meter Error: argument '%s' error\n",argv[i]);
				usage(argv[0]);
				return -1;
			}
			i++;
			_Global.interval = atoi(argv[i]);			
		}
		else if(0 == strcmp(argv[i],"--concurrency"))
		{
			if(i >= arg_num-1){
				printf("Meter Error: argument '%s' error\n",argv[i]);
				usage(argv[0]);
				return -1;
			}
			i++;
			_Global.concurrency_max = atoi(argv[i]);			
		}
		else if(0 == strcmp(argv[i],"--start-interval"))
		{
			if(i >= arg_num-1){
				printf("Meter Error: argument '%s' error\n",argv[i]);
				usage(argv[0]);
				return -1;
			}
			i++;
			_Global.start_interval = atoi(argv[i]);			
		}
		else if(0 == strcmp(argv[i],"--syn-delay"))
		{
			if(i >= arg_num - 1){
				printf("Meter Error: argument '%s' error\n",argv[i]);
				usage(argv[0]);
				return -1;
			}
			i++;
			_Global.syn_delay = atoi(argv[i]) * 1000;
		}
		else if(0 == strcmp(argv[i],"--dual"))
		{
			_Global.dual = 1;
		}
		else if(0 == strcmp(argv[i],"--short-connect"))
		{
			_Global.short_connect = 1;
		}
		else if(0 == strcmp(argv[i],"--specified-discard"))
		{
			if(i >= arg_num - 1){
				printf("Meter Error: argument '%s' error\n",argv[i]);
				usage(argv[0]);
				return -1;
			}
			i++;
			_Global.discard_file_name = argv[i];
		}
		else if(0 == strcmp(argv[i],"--random-discard"))
		{
			int rate = 0;
			if(i >= arg_num - 1){
				printf("Meter Error: argument '%s' error\n",argv[i]);
				usage(argv[0]);
				return -1;
			}
			i++;
			rate = atoi(argv[i]);
			if(rate > 0 && rate < 1000)
				_Global.ramdom_discard = rate;
		}
		else if(0 == strcmp(argv[i],"--verbose"))
		{
			if(i >= arg_num-1){
				printf("Meter Error: argument '%s' error\n",argv[i]);
				usage(argv[0]);
				return -1;
			}
			i++;
			_Global.verbose = atoi(argv[i]);			
		}
		else
		{
			printf("Meter Error: unknown argument '%s'\n",argv[i]);
			usage(argv[0]);
			return -1;			
		}
	}

	return 0;
}

#ifdef __cplusplus
}
#endif
