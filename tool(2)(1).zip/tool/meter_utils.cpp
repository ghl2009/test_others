#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <time.h>
#include <ctype.h>

#ifdef WIN32

#else
#include <sys/time.h>
#include <unistd.h>
#endif

#include "meter_utils.h"

#ifdef __cplusplus
extern "C" {
#endif

void hex_print(const char * info,const unsigned char *buf,int len)
{
	int i,len_info,line =1;
	char bufHex[100],bufChar[100];
	int byteOfGBK;// specify that the current char is which byte of a gb2312 code
	
	printf(info);
	// append "\n" if necessary
	len_info=strlen(info);
	if( len_info>0 && info[len_info-1]!='\n' ) printf("\n");
	if( len_info==0) printf("\n");
	// print the hex 
	strcpy(bufHex,"");
	strcpy(bufChar,"");
	byteOfGBK=0;
	for(i=0;i<len;i++) {
		unsigned char c=*(buf+i),byte1_gbk = 0;
		// which part of a gb2312 charactor that the current byte is 
		switch(byteOfGBK) {
		case 0:
		case 2:
			if(c>=0xa1 && c<=0xf7) byteOfGBK=1;
				else byteOfGBK=0;
			byte1_gbk=c;
			break;
		case 1:
			if(c>=0xa1 && c<=0xfe) byteOfGBK=2;
				else byteOfGBK=0;
			break;
		}
		if((i%16==0) && i>0) {
			// print current line and prepair the next one
			printf("%03d %s\t%s  \n",line++,bufHex,bufChar);
			strcpy(bufHex,"");
			strcpy(bufChar,"");
			// copy the tail char of last line to the head of next line
			if(byteOfGBK==2) sprintf(bufChar,"%c",byte1_gbk);
		}
		sprintf(bufHex,"%s%02X ",bufHex,c);
		sprintf(bufChar,"%s%c",bufChar,(iscntrl(c) ? '.':c));
	}
	printf("%03d %-48s\t%s\n",line,bufHex,bufChar);
}

int parse_single_ipaddr(char *pipaddr,unsigned int *pbottom,unsigned int *ptop)
{
	int i,nor_flag = 0,range_flag = 0;
	unsigned int bottom = 0,top = 0,tmp_bottom,tmp_top;
	char *pbegin = NULL,*pos = NULL,*pos1 = NULL;
	
	if(!pipaddr)
		return -1;

	pbegin = pipaddr;
	if(*pbegin == '~'){
		pbegin++;
		nor_flag = 1;
		range_flag = 1;
	}
	for(i=0;i<4;i++){
		if(i<3){
			pos = strchr(pbegin,'.');
			if(!pos)return -1;
			*pos=0;
		}
		if(!strcmp(pbegin,"*")){
			tmp_bottom = 0;
			tmp_top = 255;
			range_flag = 1;
		}else if((pos1 = strchr(pbegin,'-')) != NULL){
			*pos1 = 0;
			tmp_bottom = atoi(pbegin);
			tmp_top = atoi(pos1 + 1);
			if(tmp_top<=tmp_bottom)
				tmp_top = tmp_bottom;
			else
				range_flag = 1;
		}else{
			tmp_bottom = atoi(pbegin);
			tmp_top = atoi(pbegin);
		}
		bottom |= tmp_bottom<<(3-i)*8;
		top |= tmp_top<<(3-i)*8;
		pbegin = pos+1;
	}
//	if(!range_flag)
//		top = 0;
	if(!nor_flag){
		*pbottom = bottom;
		*ptop = top;
	}else{
		*pbottom = top+1;
		*ptop = bottom - 1;
	}
	return 0;
}

#ifdef WIN32

#else
unsigned int meter_thread_create(meter_thread_t func,void *param)
{
    pthread_t threadHandle;   //声明线程
    pthread_attr_t attr;      //声明线程属性
    pthread_attr_init(&attr); //初始化线程属性
    pthread_attr_setscope(&attr,PTHREAD_SCOPE_SYSTEM); //设置绑定属性，为绑定
    pthread_attr_setdetachstate(&attr,PTHREAD_CREATE_DETACHED);//设置分离属性为分离
    if(pthread_create(&threadHandle,&attr,func,param)==0)
    {
       return (unsigned int)threadHandle;
    }
    return 0;
}
#endif

int meter_iptos(unsigned long ipaddr,char *output)
{
	unsigned char *p;
	p = (unsigned char *)&ipaddr;
	sprintf(output,"%d.%d.%d.%d",p[0], p[1], p[2], p[3]);
	return 0;
}

#ifdef __cplusplus
}
#endif
