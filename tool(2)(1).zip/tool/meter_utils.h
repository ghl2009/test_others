
#ifndef METER_UTILS_H
#define METER_UTILS_H

#if defined WIN32
#include <windows.h>
#include <process.h>
#define RET_THREAD void
#define NULL_THREAD
typedef void(__cdecl *meter_thread_t)(void *);

#else
#include <unistd.h>
#include <pthread.h>
#define RET_THREAD void*
#define NULL_THREAD NULL
typedef void*(*meter_thread_t)(void *);
#endif

#ifdef __cplusplus
extern "C" {
#endif

unsigned int meter_thread_create(meter_thread_t func,void *param);

int parse_single_ipaddr(char *pipaddr,unsigned int *pbottom,unsigned int *ptop);
void hex_print(const char * info,const unsigned char *buf,int len);

int meter_iptos(unsigned long ipaddr,char *output);

#ifdef __cplusplus
}
#endif

#endif
