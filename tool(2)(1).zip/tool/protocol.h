/********************************************************************
** protocol.h
**
** purpose: 
**      定义DBFW旁路方式支持的各种通讯协议包的结构
** author:  yanghaifeng@schina.cn
** Copyright (C) 2012 SChina (www.schina.cn) 
**	
*********************************************************************/

/*
    目前在DBFW中捕获的通讯包其基本的格式如下:
    首先是Ethernet包
        长度：定长14Byte
        内容：目的主机的MAC地址
             源主机的MAC地址
             协议类型：0x0800 - IP协议，目前只支持这种协议
    IP包头：
        
*/
#ifndef _DBFW_PROTOCOL_H_
#define _DBFW_PROTOCOL_H_
#include <netinet/in.h>
#include "dbfw_global.h"
//#include "oranethelp.h"

#define ETHERNET_TYPE_IP    0x0800      /* 协议类型:0x0800 - IP协议，目前只支持这种协议 */

/*
    支持的IP协议子协议类型定义
*/  
#define DBFW_IPPROTO_RESERVED    0           /* 无用 */
#define DBFW_IPPROTO_ICMP        1           /* ICMP协议 */
#define DBFW_IPPROTO_IGMP        2           /* IGMP */
#define DBFW_IPPROTO_GGP         3           /* GGP */
#define DBFW_IPPROTO_IP          4           /* IP */
#define DBFW_IPPROTO_ST          5           /* ST */
#define DBFW_IPPROTO_TCP         6           /* TCP */
#define DBFW_IPPROTO_UCL         7           /* UCL */
#define DBFW_IPPROTO_EGP         8           /* EGP */
#define DBFW_IPPROTO_IGP         9           /* IGP */
#define DBFW_IPPROTO_UDP         17          /* UDP */

#pragma pack(1)

union sockaddr_in_all{
	struct sockaddr_in in;
	struct sockaddr_in6 in6;
};
union in_addr_all{
	struct in_addr  in;
	struct in6_addr  in6;
};


typedef struct proto_ethernet
{
    u_char  mac_dest[6];    /* 目标主机的MAC地址 */
    u_char  mac_src[6];     /* 源主机的MAC地址 */
    u_short type;           /* 协议类型:0x0800 - IP协议，目前只支持这种协议 */
}PROTO_ETHERNET;

/*
    IPV4协议包头结构
    在此结构外的数据作为Options ― 允许 IP 支持各种选项，如安全性,需要通过ip_header_len来进行偏移找到数据部分
*/
typedef struct proto_ipv4_header
{
    u_char  ip_header_len:4;  /* 4位IP包头长度,指数据报协议头长度，具有 32 位字长。指向数据起点。正确协议头最小值为 5 
                                (in 32-bit words) normally=5 (Means 20 Bytes may be 24 also) 
                              */
    u_char  ip_version:4;  /* 4-bit IPv4 version(0100) */
    u_char  ip_tos;           /* IP type of service */
    u_short ip_total_length;  /* Total length;指定整个 IP 数据包的字节长度，包括数据和协议头。其最大值为 65,535 字节。
                                 典型的主机可以接收 576 字节的数据报 
                              */
    u_short ip_id;            /* Identification;包含一个整数，用于识别当前数据报。该字段由发送端分配帮助接收端集中数据报分片 */
    u_char  ip_frag_offset:5;   /* Fragment offset field;13 位字段，指出与源数据报的起始端相关的分片数据位置，支持目标 IP 适当重建源数据报 */
    u_char  ip_more_fragment:1; /*  */
    u_char  ip_dont_fragment:1;
    u_char  ip_reserved_zero:1;
    u_char  ip_frag_offset1;    /* fragment offset */
    u_char  ip_ttl;           /* Time to live;是一种计数器，在丢弃数据报的每个点值依次减 1 直至减少为 0。这样确保数据包无止境的环路过程 */
    u_char  ip_protocol;      /* Protocol(TCP,UDP etc);参考“支持的IP协议子协议类型定义” */
    u_short ip_checksum;      /* IP checksum;帮助确保 IP 协议头的完整性。由于某些协议头字段的改变，如生存期（Time to Live），这就需要对每个点重新计算和检验。Internet 协议头需要进行处理 */
    u_int   ip_srcaddr;       /* Source address;源IP地址 */
    u_int   ip_destaddr;      /* dest address;目的IP地址 */
}PROTO_IPV4_HEADER;

typedef struct proto_ipv6_header
{
		u_int vtc_flow;
//    u_char  ip_version:4;   /* 4-bit IPv6 version(0110) */
//    u_char  ip_traffic:8;   /* 8-bit优先级*/
//    u_char  ip_label:20;    /* 20-bit流标识 */
    u_short ip_length;      /* 16-bit报文长度 */
    u_char  ip_next_header; /* 8-bit下一个头部 */
    u_char  ip_limits;      /* 8-bit跳数限制 */
    u_char  ip_srcaddr[16]; /*128-bit源ip地址*/
    u_char  ip_destaddr[16];    /* 128-bit dest address;目的IP地址 */
}PROTO_IPV6_HEADER;
/**
 * IPv6 payload
 */
typedef struct ipv6_tcp_payload {
	u_short src_port;     /** tcp src port */
	u_short dst_port;     /** tcp dst port  */
	u_int  seq;        	/**< tcp sequence */
	u_int  ack;   		/**< tcp ack number */
	u_short  flag; 		/**< ip flags. syn, syn+ack, ack */
}IPV6_TCP_PAYLOAD;

typedef struct ipv6_common_payload {
	u_char next_header;     /** ipv6 next header info type */
	u_char lengt_mode_8;     /** ipv6 this type info length  */
}IPV6_COMM_PAYLOAD;


/*
    TCP协议包头结构
    文档上说：
        一个ethernet帧的最小长度为64Byte，其中包括4Byte的ethernet帧校验和，而一个ethernet帧的结构如下：
        ethernet首部(14Byte:2*MAC+2Byte)  +  IP包头  + TCP包头 + 数据  + ethernet尾部(4Byte)
        这样,IP包+TCP包头+数据的最小长度为46字节，如果不足，需要补足任意字节。
        但是在实际的测试中发现存在ACK包的IP包+TCP包头+数据长度只有40Byte的情况，并且没有任何的补足字节
*/
typedef struct proto_tcp_header
{
    u_short source_port;            /* source port */
    u_short dest_port;              /* destination port */
    u_int   sequence;               /* sequence number - 32 bits;
                                       通常指定分配到当前信息中的数据首字节的序号。在连接建立阶段，该字段用于设别传输中的初始序列号
                                       序号字段——占 4 字节。TCP 连接中传送的数据流中的每一个字节都编上一个序号。
                                       序号字段的值则指的是本报文段所发送的数据的第一个字节的序号
                                    */
    u_int   acknowledge;            /* acknowledgement number - 32 bits 
                                       包含数据包发送端期望接收的数据下一字节的序列号。一旦连接成功，该值会一直被发送
                                       确认号字段——占 4 字节，是期望收到对方的下一个报文段的数据的第一个字节的序号
                                    */
    /* 8位分别表示：ns,reserved_part1,header_len */
    u_char  ns:1;                   /* Nonce Sum Flag Added in RFC 3540. */
    u_char  reserved_part1:3;       /* according to rfc */
    u_char  header_len:4;           /*The number of 32-bit words in the TCP header. 
                                      This indicates where the data begins. 
                                      The length of the TCP header is always a multiple 
                                      of 32 bits.
                                    */
    /* 8位分别表示不同的含义 */
    u_char  fin:1;                /* Finish Flag;No more data from sender 
                                       终止比特 FIN (FINal) —— 用来释放一个连接。
                                       当FIN=1 时，表明此报文段的发送端的数据已发送完毕，并要求释放运输连接
                                    */
    u_char  syn:1;                /* Synchronise Flag;Synchronize sequence numbers 
                                       同步比特 SYN —— 同步比特 SYN 置为 1，就表示这是一个连接请求或连接接受报文
                                    */
    u_char  rst:1;                /* Reset Flag;Reset the connection 
                                       复位比特 RST (ReSeT) —— 当 RST=1 时，表明 TCP 连接中出现严重差错（如由于主机崩溃或其他原因），
                                       必须释放连接，通知一下对方
                                    */
    u_char  psh:1;                /* Push Flag;Push function 
                                       推送比特 PSH (PuSH) - 接收 TCP 收到推送比特置1的报文段，
                                       就尽快地交付给接收应用进程，而不再等到整个缓存都填满了后再向上交付
                                    */
    u_char  ack:1;                /* Acknowledgement Flag;Acknowledgment field significant 
                                       只有当 ACK=1 时确认号(acknowledge)字段才有效。当 ACK=0 时，确认号无效
                                    */
    u_char  urg:1;                /* Urgent Flag;Urgent pointer field significant */
    u_char  ecn:1;                /* ECN-Echo Flag */
    u_char  cwr:1;                /* Congestion Window Reduced Flag */
        
        ////////////////////////////////
        
    u_short window;                     /* window 
                                           窗口字段 —— 占 2 字节。窗口字段用来控制对方发送的数据量，单位为字节。
                                           TCP 连接的一端根据设置的缓存空间大小确定自己的接收窗口大小，然后通知对方以确定对方的发送窗口的上限
                                        */
    u_short checksum;                   /* checksum 
                                           检验和 —— 占 2 字节。检验和字段检验的范围包括首部和数据和伪段头
                                           （不是TCP里的信息，但是计算校验和的时候也计算了的内容：IP地址，TCP数据段长度，协议类型）
                                        */
    u_short urgent_pointer;             /* urgent pointer 
                                           紧急指针字段 —— 占 16 bit。紧急指针指出在本报文段中的紧急数据的位置
                                        */
}PROTO_TCP_HDR;

/*
    ICMP包头结构
*/
typedef struct proto_icmp_header
{
    u_char  type;           /* ICMP Error type;错误消息或信息消息。错误消息可能是不可获得目标文件，数据包太大，超时，参数
                              问题等。可能的信息消息有：Echo Request、Echo Reply、Group Membership Query、Group 
                              Membership Report、Group Membership Reduction
                            */
    u_char  code;           /* Type sub code;每种消息类型具有多种不同代码。不可获得目标文件正式这样一个例子，即其中可能
                              的消息是：目标文件没有路由，禁止与目标文件的通信，非邻居，不可获得地址，不可获得端
                              口。具体细节请参照相关标准 
                           */
    u_short checksum;       /* 计算校验和时，Checksum 字段设置为 0 */
    u_short id;             /* 帮助匹配 Requests/Replies 的标识符，值可能为 0 */
    u_short seq;            /* 帮助匹配 Requests/Replies 的序列号，值可能为 0 */
    u_int   addr_mask;      /* 32 位掩码地址 */
}PROTO_ICMP_HDR;

typedef struct Dbfw_EthernetParseResult
{
    PROTO_ETHERNET      ethernet;
    PROTO_IPV4_HEADER   ipv4_header;
    PROTO_IPV6_HEADER   ipv6_header;
    PROTO_TCP_HDR       tcp_header;
    u_char  vlan_size;
    u_char  *parse_data;
    u_int   data_size;
    u_int   total_size; /*总包大小*/
    u_char  direction;
    u_char  eth_type;
    u_int   header_size;
#ifdef HAVE_CHERRY
    u_int   parseresult_id;
    u_char  have_packheader;
#endif
}Dbfw_EthernetParseResult;

typedef struct Dbfw_EthernetFrame
{
    u_char* frame_data;             /* NPC捕获到的Ethernet Frame数据 */
    u_int   frame_size;             /* frame的尺寸 */
    u_int   cursor;                 /* frame解析的当前游标，初始为0 */
    /* 辅助字段： */
    u_int   max_frame_size;         /* 当前分配的frame_data的内存尺寸，默认为10K字节10*1024 */
    u_char* ip_fragment_data;
    u_int   ip_fragment_size;
    u_int   ip_fragment_cursor;
    u_int   max_ip_fragment_size;
    u_short ip_id;
}Dbfw_EthernetFrame;

/*
    保存最近来一个方向的3个通讯包的信息
    用于进行旁路模式下，判断通讯包是否丢包的检查
*/
typedef struct Dbfw_EthernetPacketBuffer
{
    u_int64 pknum;                  /* 捕获到的通讯包计数,第一个通讯包捕获到时，值为1，达到最大值ULLONG_MAX后归0 */
    u_int   sequence[3];
    u_int   acknowledge[3];
    u_int   data_size[3];
    u_char  out_of_order[3];        /* 是否丢包的标记 0-没有丢包 1-有丢包 */
    u_int64 pksize_total;           /* 合计处理的字节 */
    u_int64 last_pack_timestamp;    /* 最后一次收到包的时间戳(us) */
    /* 2015-09-12增加 */
    u_int   last_ordered_secquence;     /* 最有一个有序通讯包的secquence值 */
    u_int   last_ordered_acknowledge;   /* 最有一个有序通讯包的acknowledge值 */
    u_int   last_ordered_datasize;      /* 最有一个有序通讯包的datasize(不包含TCP包头) */
    u_int   calc_next_secquence;        /* 计算得到的与当前同向的下一个有序包的预期secquence值，公式：当前包的sec+datasize*/
    //u_int   calc_next_acknowledge;      /* 计算得到的与当前同向的下一个有序包的预期acknowledge值，无法确定,随着反方向的通讯包而变化,因此暂无用途 */
    u_int   calc_next_secquence_other;    /* 计算得到的与当前反向的下一个有序包的预期secquence值，公式：当前包的acknowledge */
    u_int   calc_next_acknowledge_other;  /* 计算得到的与当前反向的下一个有序包的预期acknowledge值，公式：当前包的sec+datasize */
}Dbfw_EthernetPacketBuffer;

#pragma pack()

/***********************************************************************
**
** NAME
**      Npp_ParseEthernetFrame
**
** DESCRIPTION
**      解析Ethernet帧数据
**      
** PARAM
**      parse_result:输出参数
** RETURN
**      >0:free session id
**      65535:no session for free
**      -1:error
**      
************************************************************************
*/
int Npp_ParseEthernetFrame(Dbfw_EthernetFrame* ethernet_frame,Dbfw_EthernetParseResult *parse_result);

#endif  /* _PROTOCOL_H_ */
