#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <time.h>
//#include <sys/time.h>
//#include <unistd.h>
#include <ctype.h>

#include "meter_broadcast.h"
#include "protocol_analysis.h"

typedef struct
{
    unsigned int port;
    const char *dft_serv;
} serv_port_info;

serv_port_info default_server_port_table[] =
{
    {1521, "Oracle"},
    {1433, "SQL Server"},
    {3306, "MySQL"},
	{5000, "DB2"},
    {5432, "PostgreSQL"},
    {0, NULL} /* Keep this as the last */
};

#ifdef __cplusplus
extern "C" {
#endif

const char * get_default_port_serv(unsigned int port)
{
    int i = 0;
    while (default_server_port_table[i].port)
    {
        if (port == default_server_port_table[i].port)
            break;
        i++;
    }
    return default_server_port_table[i].dft_serv;
}

int get_packet_direction(unsigned int src_port, unsigned int dst_port)
{
    if (get_default_port_serv(src_port))
        return mb_pkt_dct_response;
    if (get_default_port_serv(dst_port))
        return mb_pkt_dct_request;

    //这里做简单的方向判断，服务器的端口一般比较小
    if(src_port > dst_port)
        return mb_pkt_dct_request;

    return mb_pkt_dct_response;
}

static int Dbfw_Tcp_Protocol_Parse(Dbfw_EthernetFrame *eth_frame,Meter_Packet_Info *pkt_info,dspr_hash_t *server_rule)
{
	Meter_Broadcast_Id key;	
	unsigned short src_port = 0,dst_port = 0;
	
	pkt_info->tcp_cursor = eth_frame->cursor;
    memcpy(&pkt_info->tcp_header,eth_frame->frame_data+eth_frame->cursor,sizeof(PROTO_TCP_HDR));
    pkt_info->tcp_header.source_port = DBFW_HTON16(pkt_info->tcp_header.source_port);
    pkt_info->tcp_header.dest_port = DBFW_HTON16(pkt_info->tcp_header.dest_port);
    pkt_info->tcp_header.sequence = DBFW_HTON32(pkt_info->tcp_header.sequence);
    pkt_info->tcp_header.acknowledge = DBFW_HTON32(pkt_info->tcp_header.acknowledge);
    pkt_info->tcp_header.window = DBFW_HTON16(pkt_info->tcp_header.window);
    pkt_info->tcp_header.checksum = DBFW_HTON16(pkt_info->tcp_header.checksum);
    pkt_info->tcp_header.urgent_pointer = DBFW_HTON16(pkt_info->tcp_header.urgent_pointer);
    
    eth_frame->cursor += pkt_info->tcp_header.header_len*sizeof(u_int);
	
	pkt_info->data_size = eth_frame->frame_size - eth_frame->cursor;
	//如果是三次握手，则数据长度为0
	if(pkt_info->tcp_header.syn)
	{
		pkt_info->data_size = 0;
	}
	else if(!pkt_info->tcp_header.psh && !pkt_info->tcp_header.syn && pkt_info->tcp_header.ack)
	{
		pkt_info->data_size = 0;		
	}

	if (pkt_info->data_size)
	{
		/* 有数据 */
		pkt_info->tcp_data = eth_frame->frame_data+eth_frame->cursor;
	}

	src_port = pkt_info->tcp_header.source_port;
	dst_port = pkt_info->tcp_header.dest_port;
	//过滤掉http
	if(src_port == 80 || dst_port == 80)
	{
		return meter_proto_http;
	}
	//过滤掉https
	if(src_port == 443 || dst_port == 443)
	{
		return meter_proto_https;
	}
	//过滤掉ssh
	if(src_port == 22 || dst_port == 22)
	{
		return meter_proto_ssh;
	}
	
    pkt_info->direction = get_packet_direction(src_port, dst_port);
    
    //2015-10-20
    //在绝大部分情况下，meter跑的都不是代理模式下抓的包，而是现场的包，因此这里去掉这一部分的判断逻辑
    //如果真的需要跑代理模式下抓的包，那么使用 --server 参数就可以了。
	//DBFW代理组的端口
	/*	
	if(dst_port >= 10000 && dst_port < 10020)
	{
		pkt_info->direction = mb_pkt_dct_request;		
	}
	else if(src_port >= 10000 && src_port < 10020)
	{
		pkt_info->direction = mb_pkt_dct_response;		
	}
	*/

	if(pkt_info->ethernet.type == 0x0800)
	{
		key.ipaddr = pkt_info->ipv4_header.ip_destaddr;
	}else{
		key.ipaddr = Dbfw_hash_xor_key16(pkt_info->ipv6_header.ip_destaddr);
	}
	key.port = pkt_info->tcp_header.dest_port;
	if(dspr_hash_find(server_rule,&key,sizeof(Meter_Broadcast_Id)))
	{
		pkt_info->direction = mb_pkt_dct_request;		
	}
	else
	{
		
		if(pkt_info->ethernet.type == 0x0800)
		{
			key.ipaddr = pkt_info->ipv4_header.ip_srcaddr;
		}else{
			key.ipaddr = Dbfw_hash_xor_key16(pkt_info->ipv6_header.ip_srcaddr);
		}
		key.port = pkt_info->tcp_header.source_port;
		if(dspr_hash_find(server_rule,&key,sizeof(Meter_Broadcast_Id)))
		{
			pkt_info->direction = mb_pkt_dct_response;		
		}
	}

    return meter_proto_cs;
}

int Dbfw_Protocol_Parse(Dbfw_EthernetFrame *eth_frame,Meter_Packet_Info *pkt_info,dspr_hash_t *server_rule)
{
    u_short type_2 = 0;
	u_char ip_protocol = 0;
	
	if(!eth_frame || !pkt_info)
	{
		return -1;
	}

    if(eth_frame->frame_size==0)
    {
        return -1;
    }
    
    pkt_info->vlan_size = 0;
	
//	hex_print("Dbfw_Protocol_Parse",(const unsigned char*)pkt_data,length);

    /* 解析Frame头部数据 */
    memcpy(&pkt_info->ethernet,eth_frame->frame_data,sizeof(PROTO_ETHERNET));
    pkt_info->ethernet.type = DBFW_HTON16(pkt_info->ethernet.type);
    eth_frame->cursor = sizeof(PROTO_ETHERNET);
    if(eth_frame->cursor >= eth_frame->frame_size)
    {
        return -1;
    }

    /* 检查ethernet.type */
    while(pkt_info->ethernet.type==0x8100)
    {
        /* 
            Type: 802.1Q Virtual LAN (0x8100),后面跟着2字节的VLan信息和2字节的type信息 
            这里假设type信息就是0x8000
        */
        /* 先跳过2字节的VLan信息 */
        eth_frame->cursor += sizeof(u_short);
        memcpy(&type_2,eth_frame->frame_data+eth_frame->cursor,sizeof(u_short));
        eth_frame->cursor += sizeof(u_short);
        pkt_info->ethernet.type = DBFW_HTON16(type_2);
        pkt_info->vlan_size += sizeof(u_short) + sizeof(u_short);
        /* 
            重要的防守逻辑：
            理论上，可能会出现多次VLand，但不应该出现大量的VLan，因此这里设置一个防守逻辑：如果超过5次的VLan(20字节)则认为是不正确的TCPIP包 
        */
        if(pkt_info->vlan_size>20)
        {
            return -252;
        }
    }
    
    switch(pkt_info->ethernet.type)
    {
		case 0x0806:
			return meter_proto_arp;
			break;
//		case 0x86dd:
//			return meter_proto_ipv6;
//			break;
	}
	if(pkt_info->ethernet.type != 0x0800 && pkt_info->ethernet.type != 0x86dd )
	{
		return meter_proto_eth;
	}

	pkt_info->ip_cursor = eth_frame->cursor;
	if(pkt_info->ethernet.type == 0x0800)
	{
	    /* 解析IPV4头部数据 */
	    memcpy(&pkt_info->ipv4_header , eth_frame->frame_data+eth_frame->cursor,sizeof(PROTO_IPV4_HEADER));
	    pkt_info->ipv4_header.ip_total_length = DBFW_HTON16(pkt_info->ipv4_header.ip_total_length);
	    pkt_info->ipv4_header.ip_id = DBFW_HTON16(pkt_info->ipv4_header.ip_id);
	    pkt_info->ipv4_header.ip_checksum = DBFW_HTON16(pkt_info->ipv4_header.ip_checksum);
	    pkt_info->ipv4_header.ip_srcaddr = DBFW_HTON32(pkt_info->ipv4_header.ip_srcaddr);
	    pkt_info->ipv4_header.ip_destaddr = DBFW_HTON32(pkt_info->ipv4_header.ip_destaddr);
		ip_protocol = pkt_info->ipv4_header.ip_protocol;
	    eth_frame->cursor += pkt_info->ipv4_header.ip_header_len*sizeof(u_int);
	    if(eth_frame->cursor >= eth_frame->frame_size)
	    {
	        return -1;
	    }
	    
	    /* 解析IPV4头部数据 */
	    if(pkt_info->ipv4_header.ip_version>0x41)
	    {
	        /* 不是IPV4协议 */
	        return meter_proto_ipv6;
	    }
	}else{
		//ipv6
		memcpy(&pkt_info->ipv6_header , eth_frame->frame_data+eth_frame->cursor,sizeof(PROTO_IPV6_HEADER));
	    pkt_info->ipv6_header.ip_length = DBFW_HTON16(pkt_info->ipv6_header.ip_length);
		ip_protocol = pkt_info->ipv6_header.ip_next_header;
	    eth_frame->cursor += sizeof(PROTO_IPV6_HEADER);
	    if(eth_frame->cursor >= eth_frame->frame_size)
	    {
	        return -1;
	    }
	    
//	    /* 解析IPV4头部数据 */
//	    if(pkt_info->ipv4_header.ip_version>0x41)
//	    {
//	        /* 不是IPV4协议 */
//	        return meter_proto_ipv6;
//	    }
	}
	
    
    switch(ip_protocol)
    {
        case 0x06:
            return Dbfw_Tcp_Protocol_Parse(eth_frame,pkt_info,server_rule);
    	    break;
        case 0x11:
			return meter_proto_udp;
        case 0x01:
			return meter_proto_icmp;
        default:
            /* 不支持的协议 */
            return meter_proto_ip;
            break;
    }
	return -1;
}

#ifdef __cplusplus
}
#endif
