
#ifndef DBFW_PROTOCOL_PROCESS_H
#define DBFW_PROTOCOL_PROCESS_H

#include "meter_broadcast.h"

#include "dbfw_global.h"
#include "protocol.h"
#include "dbfw_common.h"

#ifdef __cplusplus
extern "C" {
#endif

//数据方向
enum{
	mb_pkt_dct_request = 1,
	mb_pkt_dct_response
};

enum{
	meter_proto_cs = 1,
	meter_proto_eth,	
	meter_proto_arp,
	meter_proto_ipv6,
	meter_proto_ip,
	meter_proto_icmp,
	meter_proto_udp,
	meter_proto_tcp,
	meter_proto_http,
	meter_proto_https,
	meter_proto_ssh
};

#pragma pack(1)

typedef struct
{
    PROTO_ETHERNET      ethernet;
    PROTO_IPV4_HEADER   ipv4_header;
    PROTO_IPV6_HEADER   ipv6_header;
    PROTO_TCP_HDR       tcp_header;
    u_char  direction;
    u_char  vlan_size;
    u_char  ip_cursor;
    u_char  tcp_cursor;
    u_char  *tcp_data;
    int data_size;
}Meter_Packet_Info;

#pragma pack()

/*
    return the service name if the port is a default port of it
        otherwise NULL.
*/
const char * get_default_port_serv(unsigned int port);

/*
    return mb_pkt_dct_request if this is a request packet
           otherwise mb_pkt_dct_response 
*/
int get_packet_direction(unsigned int src_port, unsigned int dst_port);

//返回值： <0 失败 == 0 无意义  >0 协议
int Dbfw_Protocol_Parse(Dbfw_EthernetFrame *eth_frame,Meter_Packet_Info *pkt_info,dspr_hash_t *server_rule);

#ifdef __cplusplus
}
#endif

#endif
