/********************************************************************
** protocol_parser.cpp
**
** purpose: 
**      旁路通讯包协议解析程序
** author:  yanghaifeng@schina.cn
** Copyright (C) 2012 SChina (www.schina.cn) 
**	
*********************************************************************/
#ifndef WIN32
#include <sys/shm.h>
#include <pthread.h>
#include "dbfw_ipc.h"
#include <arpa/inet.h>
#endif
#include "dbfw_global.h"
#include "dbfw_limits.h"
#include "npp_dump.h"
#include "protocol.h"
#include "npc_interface.h"
#include "oranethelp.h"
#include "npp_errorno.h"
#include "dbfw_smem.h"
#include "smem_log.h"


#ifdef SOURCECODE
#undef SOURCECODE
#endif
#define SOURCECODE 51
/***********************************************************************
**
** NAME
**      Npp_DecodeTCPHeader
**
** DESCRIPTION
**      解析TCP包头数据
**      
** PARAM
**      parse_result:输出参数
** RETURN
**      >0:parse ok,解析的数据长度，一般等于frame_size
**      =0:frame_data数据不足
**      -1:error
**      
************************************************************************
*/
int Npp_DecodeTCPPacket(Dbfw_EthernetFrame* ethernet_frame,Dbfw_EthernetParseResult *parse_result)
{
    u_int total_size = 0;
	u_short ip_length = 0;

	if(parse_result->ethernet.type ==0x86dd)
	{
		ip_length = sizeof(PROTO_IPV6_HEADER) + parse_result->ipv6_header.ip_length;
	}else{
		ip_length = parse_result->ipv4_header.ip_total_length;
	}
	
    if(parse_result->eth_type == 2)		
		total_size = sizeof(u_int) + parse_result->header_size + ip_length;
	else
	{
		total_size = sizeof(PROTO_ETHERNET) + parse_result->vlan_size + parse_result->header_size + ip_length;
        if(total_size<ethernet_frame->frame_size 
            && ethernet_frame->frame_size>64 
            && ip_length == 0)
        {
            total_size  = ethernet_frame->frame_size ;
            
          //OraNet_DumpSql("Npp_DecodeTCPPacket, ip_total_length is 0 change to frame size %u\n",total_size);
        }
    }

	if(ethernet_frame->frame_size < (ethernet_frame->cursor+sizeof(PROTO_TCP_HDR)))
	{
		/* 越界检查结果失败 */
		return -1;
	}
    z_memcpy(&parse_result->tcp_header,ethernet_frame->frame_data+ethernet_frame->cursor,sizeof(PROTO_TCP_HDR), __FILE__, __LINE__, Smem_LogError_Format);
    //printf("parse_result->tcp_header.source_port = %u\n",parse_result->tcp_header.source_port);
    parse_result->tcp_header.source_port = DBFW_HTON16(parse_result->tcp_header.source_port);
    parse_result->tcp_header.dest_port = DBFW_HTON16(parse_result->tcp_header.dest_port);
    /* 测试目的 */
//     if(parse_result->tcp_header.source_port != 1521)
//     {
//         parse_result->tcp_header.source_port = 3333;
//     }
//     if(parse_result->tcp_header.dest_port != 1521)
//     {
//         parse_result->tcp_header.dest_port = 3333;
//     }
    /* 测试目的 结束 */
    parse_result->tcp_header.sequence = DBFW_HTON32(parse_result->tcp_header.sequence);
    parse_result->tcp_header.acknowledge = DBFW_HTON32(parse_result->tcp_header.acknowledge);
    parse_result->tcp_header.window = DBFW_HTON16(parse_result->tcp_header.window);
    parse_result->tcp_header.checksum = DBFW_HTON16(parse_result->tcp_header.checksum);
    parse_result->tcp_header.urgent_pointer = DBFW_HTON16(parse_result->tcp_header.urgent_pointer);
    ethernet_frame->cursor = ethernet_frame->cursor + parse_result->tcp_header.header_len*sizeof(u_int);
    if(ethernet_frame->cursor > ethernet_frame->frame_size)
    {
		/* 越界检查结果失败 */
        return -2;
    }
    parse_result->data_size = 0;
    if(ethernet_frame->cursor < total_size)
    {
        /* 有数据 */
        parse_result->data_size = total_size - ethernet_frame->cursor;
		if(ethernet_frame->frame_size < (ethernet_frame->cursor+parse_result->data_size))
		{
			/* 越界检查结果失败 */
			parse_result->data_size = 0;
			return -3;
		}
        parse_result->parse_data = (u_char*)ZMalloc(parse_result->data_size);
        //parse_result->parse_data = (u_char*)ZMalloc(parse_result->data_size);
        //memset(parse_result->parse_data,0x00,parse_result->data_size);
        z_memcpy(parse_result->parse_data,ethernet_frame->frame_data+ethernet_frame->cursor,parse_result->data_size, __FILE__, __LINE__, Smem_LogError_Format);
    }

    if(total_size<ethernet_frame->frame_size)
    {
        /* 数据不足 */
        if(ethernet_frame->frame_size>64)
        {
            if(total_size<64)
            {
                /* 是Ethernet补足数据 */
                //printf("total_size=%u    capbuf_header.data_size=%u  \n",total_size,ethernet_frame->frame_size);
				/* 修复环形缓冲区数据被覆盖引起的内存泄露 */
				if(parse_result->data_size>0)
				{
					ZFree(parse_result->parse_data);
				}
                parse_result->data_size = 0;
                return ethernet_frame->frame_size;
            }
            else
            {
                /* 数据不正常，帧数据的尺寸大于实际的IP包数据，需要将剩余的数据另行处理 */
                return total_size;
            }
        }                
    }
    else if(total_size>ethernet_frame->frame_size)
    {
        /* 计算的实际的IP包数据尺寸大于帧数据的尺寸 */
        return NPP_ERROR_NETPARSER_FRAMESIZEERROR - NPP_ERRNO_START;
    }
    return total_size;
}

/***********************************************************************
**
** NAME
**      Npp_ParseEthernetFrame
**
** DESCRIPTION
**      解析Ethernet帧数据
**      
** PARAM
**      parse_result:输出参数
** RETURN
**      >0:parse ok,解析的数据长度，一般等于frame_size
**      =0:frame_data数据不足
**      -1:error
**      
************************************************************************
*/
int Npp_ParseEthernetFrame(Dbfw_EthernetFrame* ethernet_frame,Dbfw_EthernetParseResult *parse_result)
{
    //PROTO_ETHERNET      ethernet;
    //PROTO_IPV4_HEADER   ipv4_header;
    //PROTO_TCP_HDR       tcp_header;
    //u_int cursor = 0;
    // TODO:有待确认total_size是否还有其他作用
//    u_int total_size = 0;
    u_int data_size = 0;
    u_short type_2 = 0;
    int ret = 0;
	int loop = 0;
    u_int loopback = 0;
    u_char gre_present = 0;
	u_short ip_length;
	IPV6_COMM_PAYLOAD ipv6_payload;
	u_char ip_protocol=0;
    if(ethernet_frame->frame_size==0)
    {
        return 0;
    }
	parse_result->header_size = 0;
	parse_result->eth_type = 0;
	do {
		parse_result->vlan_size = 0;
		/* 解析Frame头部数据 */
		if(ethernet_frame->frame_size < (ethernet_frame->cursor+sizeof(PROTO_ETHERNET)))
		{
			/* 越界检查结果失败 */
			return 0;
		}
		z_memcpy(&loopback,ethernet_frame->frame_data+ethernet_frame->cursor,sizeof(u_int), __FILE__, __LINE__, Smem_LogError_Format);

        loopback = ntohl(loopback);
        if(loopback != 0x02)
        {
			z_memcpy(&parse_result->ethernet,ethernet_frame->frame_data+ethernet_frame->cursor,sizeof(PROTO_ETHERNET), __FILE__, __LINE__, Smem_LogError_Format);
			parse_result->ethernet.type = DBFW_HTON16(parse_result->ethernet.type);
			ethernet_frame->cursor = ethernet_frame->cursor + sizeof(PROTO_ETHERNET);
//			total_size = sizeof(PROTO_ETHERNET);
			if(ethernet_frame->cursor>=ethernet_frame->frame_size)
			{
				return 0;
			}
			/* 检查ethernet.type */
			while(parse_result->ethernet.type==0x8926)
			{
				/*    
				 **Type: VN TAG (0x8926),后面跟着4字节的Vntag信息和2字节的type信息 
				 *       这里假设type信息就是0x8000
				 **/
				/* 先跳过4字节 */
				ethernet_frame->cursor = ethernet_frame->cursor + sizeof(u_int);
				if(ethernet_frame->frame_size < (ethernet_frame->cursor+sizeof(u_int)))
				{
					/* 越界检查结果失败 */
					return 0;
				}
				z_memcpy(&type_2,ethernet_frame->frame_data+ethernet_frame->cursor,sizeof(u_short), __FILE__, __LINE__, Smem_LogError_Format);
				ethernet_frame->cursor = ethernet_frame->cursor + sizeof(u_short);
				parse_result->ethernet.type = DBFW_HTON16(type_2);
//				total_size = total_size + sizeof(u_short) + sizeof(u_short);
				parse_result->vlan_size = parse_result->vlan_size + sizeof(u_int) + sizeof(u_short);
				/* 
				   重要的防守逻辑：
				   理论上，可能会出现多次VLand，但不应该出现大量的VLan，因此这里设置一个防守逻辑：如果超过5次的VLan(20字节)则认为是不正确的TCPIP包 
				   */
				if(parse_result->vlan_size>20)
				{
					return NPP_ERROR_NETPARSER_NOTIPV4 - NPP_ERRNO_START;
				}
			}
			while(parse_result->ethernet.type==0x8100)
			{
				/* 
				Type: 802.1Q Virtual LAN (0x8100),后面跟着2字节的VLan信息和2字节的type信息 
				这里假设type信息就是0x8000
				*/
				/* 先跳过2字节的VLan信息 */
				ethernet_frame->cursor = ethernet_frame->cursor + sizeof(u_short);
				if(ethernet_frame->frame_size < (ethernet_frame->cursor+sizeof(u_short)))
				{
					/* 越界检查结果失败 */
					return 0;
				}
				z_memcpy(&type_2,ethernet_frame->frame_data+ethernet_frame->cursor,sizeof(u_short), __FILE__, __LINE__, Smem_LogError_Format);
				ethernet_frame->cursor = ethernet_frame->cursor + sizeof(u_short);
				parse_result->ethernet.type = DBFW_HTON16(type_2);
//				total_size = total_size + sizeof(u_short) + sizeof(u_short);
				parse_result->vlan_size = parse_result->vlan_size + sizeof(u_short) + sizeof(u_short);
				/* 
				   重要的防守逻辑：
				   理论上，可能会出现多次VLand，但不应该出现大量的VLan，因此这里设置一个防守逻辑：如果超过5次的VLan(20字节)则认为是不正确的TCPIP包 
				   */
				if(parse_result->vlan_size>20)
				{
					return NPP_ERROR_NETPARSER_NOTIPV4 - NPP_ERRNO_START;
				}
			}
        }
        else
        {
		    ethernet_frame->cursor = ethernet_frame->cursor + sizeof(u_int);
//		    total_size = sizeof(u_int);
		    parse_result->eth_type = loopback;
        }
		/* 解析IPV4头部数据 */
		if(ethernet_frame->frame_size < (ethernet_frame->cursor+sizeof(PROTO_IPV4_HEADER)))
		{
			/* 越界检查结果失败 */
			return 0;
		}
		if(parse_result->ethernet.type == 0x86dd)
		{
			z_memcpy(&parse_result->ipv6_header , ethernet_frame->frame_data+ethernet_frame->cursor , sizeof(PROTO_IPV6_HEADER), __FILE__, __LINE__, Smem_LogError_Format);
			parse_result->ipv6_header.ip_length = DBFW_HTON16(parse_result->ipv6_header.ip_length);
			ethernet_frame->cursor = ethernet_frame->cursor + sizeof(PROTO_IPV6_HEADER);
			ip_length = parse_result->ipv6_header.ip_length;
			ip_protocol = parse_result->ipv6_header.ip_next_header;
		}else{
			z_memcpy(&parse_result->ipv4_header , ethernet_frame->frame_data+ethernet_frame->cursor , sizeof(PROTO_IPV4_HEADER), __FILE__, __LINE__, Smem_LogError_Format);
			parse_result->ipv4_header.ip_total_length = DBFW_HTON16(parse_result->ipv4_header.ip_total_length);
			parse_result->ipv4_header.ip_id = DBFW_HTON16(parse_result->ipv4_header.ip_id);
			parse_result->ipv4_header.ip_checksum = DBFW_HTON16(parse_result->ipv4_header.ip_checksum);
			parse_result->ipv4_header.ip_srcaddr = DBFW_HTON32(parse_result->ipv4_header.ip_srcaddr);
			parse_result->ipv4_header.ip_destaddr = DBFW_HTON32(parse_result->ipv4_header.ip_destaddr);
			ethernet_frame->cursor = ethernet_frame->cursor + parse_result->ipv4_header.ip_header_len*sizeof(u_int);
			ip_length = parse_result->ipv4_header.ip_total_length;
			ip_protocol = parse_result->ipv4_header.ip_protocol;

			if(parse_result->ipv4_header.ip_version>0x41)
			{
				/* 不是IPV4协议,可能是由于tis区数据不正确造成的 */
				return NPP_ERROR_NETPARSER_NOTIPV4 - NPP_ERRNO_START;
			}
		}
		//printf("ip_id = %d, len = %u\n",parse_result->ipv4_header.ip_id ,parse_result->ipv4_header.ip_total_length);
//		total_size = total_size + parse_result->ipv4_header.ip_total_length;
		if(ethernet_frame->cursor >= ethernet_frame->frame_size)
		{
			/* 越界检查 */
			return 0;
		}
		
		/* 由于存在RMAgent抓的包被网卡聚合导致超过1W字节，所以不再校验ip长度 */
//		if(ip_length>DBFW_MAX_IP_TOTAL_LENGTH)
//		{
//			/* 可能是由于tis区数据不正确造成的 */
//			return NPP_ERROR_NETPARSER_IPTOTALLENGTH - NPP_ERRNO_START;
//		}
		if(parse_result->ethernet.type == 0x86dd)
		{
			/* 不考虑ipv6的格式里嵌入了gre的情况 */
			while(ip_length > 0){
				if(ip_protocol == 0x06)
				{
					break;
				}else{		
					if(ethernet_frame->cursor + sizeof(IPV6_COMM_PAYLOAD)>= ethernet_frame->frame_size)
					{
						/* 越界检查 */
						return 0;
					}
					z_memcpy(&ipv6_payload, (IPV6_COMM_PAYLOAD *)(ethernet_frame->frame_data+ethernet_frame->cursor) , sizeof(IPV6_COMM_PAYLOAD), __FILE__, __LINE__, Smem_LogError_Format);
					ip_protocol = ipv6_payload.next_header;
					ip_length = ip_length - (ipv6_payload.lengt_mode_8+1)*8;
					ethernet_frame->cursor = ethernet_frame->cursor + (ipv6_payload.lengt_mode_8+1)*8;										
				}
			}
			break;
		}else{
			if(parse_result->ipv4_header.ip_protocol == 0x2f) //GRE protocol
			{
				loop ++;
				if(parse_result->ipv4_header.ip_frag_offset1 != 0 
				    && ethernet_frame->ip_fragment_size > 0
				    && ethernet_frame->ip_id == parse_result->ipv4_header.ip_id
				    && loop == 1)
				{
	                u_int tmp_size = 0;
	                u_char *tmp_data = NULL;
	                tmp_size = ethernet_frame->ip_fragment_size + ethernet_frame->frame_size - ethernet_frame->cursor;
				    if(parse_result->ipv4_header.ip_more_fragment == 1 )
				    {
				        if(ethernet_frame->max_ip_fragment_size < tmp_size)
	    			    {
	                        tmp_data = (u_char*)ZMalloc(tmp_size);
	                        z_memcpy(tmp_data,ethernet_frame->ip_fragment_data,ethernet_frame->ip_fragment_size, __FILE__, __LINE__, Smem_LogError_Format);
	    			         ZFree(ethernet_frame->ip_fragment_data);
	    			         ethernet_frame->max_ip_fragment_size = tmp_size;
	    			         ethernet_frame->ip_fragment_data = tmp_data;
	    			    }
	    			    if ( ethernet_frame->ip_fragment_data !=  NULL)
	    			    {
	                        z_memcpy(ethernet_frame->ip_fragment_data + ethernet_frame->ip_fragment_size
	                            ,ethernet_frame->frame_data + ethernet_frame->cursor,ethernet_frame->frame_size - ethernet_frame->cursor 
	                            , __FILE__, __LINE__, Smem_LogError_Format);
	    			        ethernet_frame->ip_fragment_size = tmp_size;
	                        ethernet_frame->ip_id = parse_result->ipv4_header.ip_id;
	                        return NPP_ERROR_NETPARSER_GREFREAGMENT - NPP_ERRNO_START;
	        		    }
	                }
	                else
	                {
	    			    tmp_data = (u_char*)ZMalloc(tmp_size);
	                    z_memcpy(tmp_data,ethernet_frame->ip_fragment_data,ethernet_frame->ip_fragment_size, __FILE__, __LINE__, Smem_LogError_Format);
	                    z_memcpy(tmp_data + ethernet_frame->ip_fragment_size ,ethernet_frame->frame_data + ethernet_frame->cursor
	                        ,ethernet_frame->frame_size - ethernet_frame->cursor, __FILE__, __LINE__, Smem_LogError_Format);
	    			    ethernet_frame->ip_fragment_size = 0;
	    			    ethernet_frame->ip_id = 0;
	                    ethernet_frame->max_frame_size = tmp_size;
	                    ZFree(ethernet_frame->frame_data);
	                    ethernet_frame->frame_size = tmp_size;
	                    ethernet_frame->frame_data = tmp_data;
	                    ethernet_frame->cursor = 0;
	                    continue;
	                }
				}
				else 
				{
	    			if(parse_result->ipv4_header.ip_more_fragment == 1 && loop == 1)
	    			{
	    			    if(ethernet_frame->max_ip_fragment_size < ethernet_frame->frame_size)
	    			    {
	    			         ZFree(ethernet_frame->ip_fragment_data);
	    			         ethernet_frame->max_ip_fragment_size = ethernet_frame->frame_size;
	    			         ethernet_frame->ip_fragment_size = 0;
	    			         ethernet_frame->ip_fragment_data = (u_char*)ZMalloc(ethernet_frame->max_ip_fragment_size);
	    			    }
	    			    if ( ethernet_frame->ip_fragment_data !=  NULL)
	    			    {
	                        z_memcpy(ethernet_frame->ip_fragment_data,ethernet_frame->frame_data,ethernet_frame->frame_size, __FILE__, __LINE__, Smem_LogError_Format);
	    			        ethernet_frame->ip_fragment_size = ethernet_frame->frame_size;
	                        ethernet_frame->ip_id = parse_result->ipv4_header.ip_id;
	                        return NPP_ERROR_NETPARSER_GREFREAGMENT - NPP_ERRNO_START;
	    			    }
	    			}
				} 
				if(ethernet_frame->cursor >= ethernet_frame->frame_size)
				{
					/* 越界检查 */
					return 0;
				}
				gre_present = ethernet_frame->frame_data[ethernet_frame->cursor];
				/* 跳过GRE基础包头信息 */
				ethernet_frame->cursor = ethernet_frame->cursor + 4;
				/* 跳过GRE可选包头信息，Checksum +offset */
				if(((gre_present & 0x80) != 0)||((gre_present & 0x40) != 0))
				{
				    ethernet_frame->cursor = ethernet_frame->cursor + 4;
				}
				/* 跳过GRE可选包头信息，key */
				if(((gre_present & 0x20) != 0))
				{
				    ethernet_frame->cursor = ethernet_frame->cursor + 4;
				}
				/* 跳过GRE可选包头信息，sequence */
				if(((gre_present & 0x10) != 0))
				{
				    ethernet_frame->cursor = ethernet_frame->cursor + 4;
				}
				/* 跳过GRE可选包头信息，Routing */
				if(((gre_present & 0x40) != 0))
				{
				    ethernet_frame->cursor = ethernet_frame->cursor + 4;
				}
				if(ethernet_frame->cursor >= ethernet_frame->frame_size)
				{
					/* 越界检查 */
					return 0;
				}
				parse_result->header_size = ethernet_frame->cursor;
			}
			else
				break;
		}
	} while (loop < 3);
    switch (ip_protocol)
    {
        case DBFW_IPPROTO_TCP:
            ret = Npp_DecodeTCPPacket(ethernet_frame,parse_result);
    	    break;
        default:
            /* 不支持的协议 */
            ret = NPP_ERROR_NETPARSER_UNSUPPORT_PROTO - NPP_ERRNO_START;
            break;
    }
    return ret;
}
