#!/bin/sh
chown root ./dbnetstat
chmod u+s ./dbnetstat