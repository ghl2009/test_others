#!/bin/sh
chown root ./meter_broadcast
chmod u+s ./meter_broadcast