
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <unistd.h>
#include <time.h>
#include <sys/time.h>

int main(int argc,char *argv[])
{
	int ii=0,count = 1000;
	pid_t pid;
	struct timeval tvbegin,tvend;
	int elapsed = 0;

	if(argc == 2)
	{
		if(strcmp(argv[1],"-h") == 0)
		{
			printf("usage:%s [fork_number]\n",argv[0]);
			return 0;
		}
		else
		{
			count = atoi(argv[1]);
		}
	}
	
	gettimeofday(&tvbegin,NULL);
	for(ii=0;ii<count;ii++)
	{
		if((pid=fork())==0)
		{
			exit(0);
		}
	}
	gettimeofday(&tvend,NULL);

	tvend.tv_usec /= 1000;
	tvbegin.tv_usec /= 1000;
	elapsed = (tvend.tv_sec - tvbegin.tv_sec)*1000 + (tvend.tv_usec - tvbegin.tv_usec);

	printf("fork count:%d elapsed time:%d\n",count,elapsed);
	
	return 0;
}
