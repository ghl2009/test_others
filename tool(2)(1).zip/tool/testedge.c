
#include <stdio.h>

int main()
{
	int count =0;
	unsigned seq = 0xffffff00;
	unsigned char *pseq = (unsigned char*)&seq;
	for(count=0;count<100;count++)
	{
		printf("===>%u %x %x %x %x\n",
			seq,*pseq,*(pseq+1),*(pseq+2),*(pseq+3));
		seq+=7;
	}
	
	return 0;
}

